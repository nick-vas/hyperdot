**Entry (`hyperdot.ps1`):** The script parses parameters and dot-sources `lib/*.ps1`. It calls `Get-ProjectInfo` (Detect.ps1) to resolve the project, solution, Godot version and runners. For `test`, it clears `-Results` (keeping `hyperdot.log`), starts the run log and history, then runs `Invoke-Setup` (Godot download or `GODOT_BIN`), `Invoke-Build` (GUT addon, `dotnet build` if there is a solution, `godot --import`), and `Invoke-Tests`.

**Detection (Detect.ps1):** The project is the shallowest `project.godot` under the current folder. Without `-Runners`, `validate` and `architecture` always run. `dotnet` is added when the solution references a test SDK or gdUnit4. `godottest`, `gut`, `flows`, `smoke`, `juice`, `playthrough`, `l10n`, `data`, `textsize` and `layout` are added from their file or config markers. `gdunit4` is never auto-detected. Unknown names fail with `invalid-arguments`.

**Godot per runner (Runners.ps1, `Invoke-TestRunner`):**
- `dotnet` and `gdunit4`: `dotnet test` with a generated `godot.runsettings`.
- `godottest`: `godot --headless --path <project> <scene> --run-tests --quit-on-finish`.
- `gut`: `-s addons/gut/gut_cmdln.gd -gexit`, with JUnit output.
- `validate` and `flows`: `-s tools/validate.gd` or `tools/flows.gd`.
- `smoke`: `--quit-after <Frames>`.
- The other runners call their own `Invoke-*` functions, which I did not read.

**Outputs:** Each runner writes to `test-results/<runner>/` (JUnit or TRX, plus its log). Retries keep `<runner>.attempt<N>/`. Report.ps1 writes `summary.json` and `summary.md`, and `coverage/` appears with `-Coverage`. `hyperdot.log` and a line in `.godot/hyperdot-history.jsonl` are also written. With `-Json`, stdout includes `runnerResults`, `failureDelta`, `flaky` and `quarantined`. Any failed runner stops the run with `tests-failed`.
