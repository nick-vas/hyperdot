- **Files to read:** `AGENTS.md`, `ci/godot/lib/Common.ps1` (for `Stop-GodotCi`, `Set-JsonField`, and the `$script:JsonDoc` pattern), and `ci/godot/lib/Runners.ps1` (for how existing runners are invoked and what they return).
- **Strict mode and errors:** Set `Set-StrictMode -Version 3.0` and `$ErrorActionPreference = 'Stop'`. Report failures with `Stop-GodotCi "message" 'stable-code'`, reusing an existing code where one fits.
- **Return shape:** Return a single structured object (`[pscustomobject]`) built from the runner's exit code, output, and duration. Wrap any possibly-empty collections in `@(...)`. Do not call `Write-Output`, and keep logs on `Write-Host`/`Write-CiLog`.
- **Naming:** Use a Verb-Noun function name that does not clash with a built-in alias and matches the naming in `Runners.ps1`. Check that it is unique across `ci/godot` (`Test-LibNames.ps1` enforces this).
- **Verification:** Run `pwsh tests/Test-LibNames.ps1` and, if I add a new error code, add it to `docs/json.md`. Then give the code only, within the 320-word limit.

I have not answered the request yet, as you asked. Say go and I'll read the files and return the function.
