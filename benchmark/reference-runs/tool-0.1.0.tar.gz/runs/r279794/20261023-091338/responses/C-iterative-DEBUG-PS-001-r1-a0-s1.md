1. **A Godot process deadlocks or an `await` never resumes.** Guard: `Invoke-Logged` (`ci/godot/lib/Common.ps1:184`) stops the process tree after `Get-ProcessTimeout` (default 1800 s, set by `HYPERDOT_TIMEOUT`) and returns 124. Mitigation: set `HYPERDOT_TIMEOUT` lower in CI so a hang fails in minutes.

2. **The test framework's session or compile step stalls.** Guard: `New-RunSettings` (`ci/godot/lib/Runners.ps1:28`) sets `CompileProcessTimeout` to 180000 ms and `TestSessionTimeout` to 1800000 ms. Mitigation: lower `TestSessionTimeout` below the outer limit so the framework reports the stall itself instead of the kit killing the process.

3. **Crash retries multiply the wait.** An import or export that crashes is run again up to twice. At 1800 s per run that is up to 90 minutes, which exceeds the 45-minute `timeout-minutes` in `.github/workflows/self-test.yml`, the only backstop. Mitigation: cap the per-run limit so three attempts fit within 45 minutes.

4. **A child process keeps the output pipes open after the parent exits**, such as a build server. Guard: the read loop exits once `HasExited` is true, checked on each 1 s poll (`Common.ps1:216`). Mitigation: shut the build server down after the run (for example, `dotnet build-server shutdown`), so nothing holds the pipes.

5. **The limit is switched off.** `HYPERDOT_TIMEOUT=0` disables the per-process limit, leaving the 45-minute CI cap as the only stop. I have not checked whether the workflow sets it. Mitigation: grep `self-test.yml` for `HYPERDOT_TIMEOUT` and reject 0 in CI.
