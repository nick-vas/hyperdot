**Flow of `test`**

1. **Entry** (`hyperdot.ps1`): dot-sources the libs (l.189), then `Get-ProjectInfo` (l.198) detects the project. The `Runners` list is then passed through `Invoke-Setup; Invoke-Build; Invoke-Tests` (l.575).

2. **Detection** (`Detect.ps1`): the shallowest `project.godot` (l.3), the nearest `.sln`/`.csproj`, and the Godot version from `Godot.NET.Sdk` (default 4.7.2). If `-Runners` is empty, runners are chosen from project files (l.130–160): `validate` and `architecture` always, plus `dotnet`, `godottest`, `gut`, `smoke`, `juice`, and others when their config or test files exist.

3. **Build** (`Invoke-Build`, l.261): installs GUT if needed, runs `dotnet build` for C#, then `godot --headless --import`.

4. **Runners** (`Runners.ps1`): `Invoke-TestRunnerWithRetry` loops over runners and reruns on failure up to `-Retry`. `Invoke-TestRunner` (l.90) launches each one:
   - `dotnet`/`gdunit4`: `dotnet test` with a generated `godot.runsettings`
   - `godottest`: `godot --headless --run-tests --quit-on-finish`
   - `gut`: `-s addons/gut/gut_cmdln.gd -gexit`
   - `validate`/`flows`: `-s tools/*.gd`
   - `smoke`: `--quit-after <frames>`

5. **Report** (`Report.ps1`): parses JUnit/TRX, writes `summary.json` and `summary.md` (`Write-RunSummary`, l.255), and computes `failureDelta` against `.godot/hyperdot-history.jsonl`. Any failed runner stops with `tests-failed`.

**Files:** `<Results>/` (default `test-results/`) holds `hyperdot.log`, one folder per runner with its `*.junit.xml`/`*.trx`/logs, `coverage/`, `summary.json`, `summary.md`, and `<runner>.attempt<N>/` for retries. The project's `.godot/hyperdot-history.jsonl` gets one appended line. The `-Json` output reports `resultsDir`, `runnerResults[]`, `failureDelta`, `flaky[]`, and `quarantined[]`.
