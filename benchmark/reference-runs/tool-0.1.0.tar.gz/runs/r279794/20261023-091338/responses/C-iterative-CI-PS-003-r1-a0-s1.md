**If you change a file under `ci/godot/lib/`:**
- Run `Invoke-ScriptAnalyzer` with `ci/godot/PSScriptAnalyzerSettings.psd1`, and `tests/Test-LibNames.ps1` (no duplicate or alias-clashing names). Both run in CI.
- Run the self-test named in AGENTS.md's Self-tests table for that concern (e.g. `Plan.ps1` → `Test-Plan.ps1`, `Steam.ps1` → `Test-Steam.ps1`). Use `-NoGodot` where the table offers it. Godot-dependent ones need Godot and, for `bench`, `shot` and `audio -Mix`, a display (Xvfb on `:99`).
- Run `test` and `doctor` on `examples/csharp/game` and `examples/gdscript`. If `plan` changed, run the copy-and-`git init` check from AGENTS.md.

**If you change a skill (`.agents/skills/*/SKILL.md`):**
- Run `ci/godot/tools/Test-Skills.ps1` and `tests/Test-SkillFixtures.ps1`.
- If it quotes a shader, run `tests/Test-SkillShaders.ps1` (needs Godot).
- If it quotes flags, codes or versions, check them against the script, `docs/json.md` and `examples/csharp`, and run `tests/Test-Context.ps1`.

**If you change a page under `docs/`:**
- Run `tests/Test-DocLinks.ps1`.
- If the page names kit flags or files, run `tests/Test-Context.ps1`.
- If it covers palette or style, run `tests/Test-Palette.ps1`.
- A new error code goes in `docs/json.md` and must not rename an existing one.

**Always:** CI runs every self-test on push, so the local set above is the minimum before pushing.
