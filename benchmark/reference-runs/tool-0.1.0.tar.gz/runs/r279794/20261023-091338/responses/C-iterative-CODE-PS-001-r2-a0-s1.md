```powershell
function Invoke-TestRunnerResult {
    param(
        [Parameter(Mandatory)]
        [ValidateSet('dotnet', 'gdunit4', 'godottest', 'gut', 'validate', 'flows', 'juice', 'playthrough',
            'architecture', 'l10n', 'data', 'layout', 'textsize', 'smoke')]
        [string]$Runner,
        [Parameter(Mandatory)]$Info,
        [Parameter(Mandatory)][string]$ResultsDir,
        [string]$Filter = ''
    )

    $started = Get-Date
    $summary = Invoke-TestRunner -Runner $Runner -Info $Info -ResultsDir $ResultsDir -Filter $Filter -Coverage $false

    return [pscustomobject]@{
        Runner     = $Runner
        Ok         = [bool]$summary.Ok
        ResultsDir = $ResultsDir
        Seconds    = [math]::Round(((Get-Date) - $started).TotalSeconds, 1)
        Warnings   = @($summary.Warnings)
    }
}
```

Notes:
- I did not run this. Nothing was edited in the repository, so `Test-LibNames.ps1` has not been run against it.
- It wraps the existing `Invoke-TestRunner` in `Runners.ps1` rather than duplicating its switch. `Ok` and `Warnings` are taken from the summary that function returns; I did not read `Write-TestSummary`, so those two fields are assumed from how `Invoke-TestRunnerWithRetry` uses them.
- The runner list is a `ValidateSet`, so an unknown name fails at binding. `Invoke-TestRunner` would otherwise silently do nothing for it.
- Failures inside the runner still go through `Stop-GodotCi`. No new error code is added, so `docs/json.md` needs no change.
