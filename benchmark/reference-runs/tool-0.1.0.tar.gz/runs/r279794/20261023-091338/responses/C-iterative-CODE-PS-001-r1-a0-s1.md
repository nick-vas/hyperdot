```powershell
# One runner, run once, as a structured result. Invoke-TestRunner's switch ignores unknown names, so check the name first.
function Invoke-TestRunnerOnce {
    param(
        [Parameter(Mandatory)][string]$Runner,
        [Parameter(Mandatory)]$Info,
        [Parameter(Mandatory)][string]$ResultsDir,
        [string]$Filter = '',
        [int]$Frames = 300
    )
    $known = @('dotnet', 'gdunit4', 'godottest', 'gut', 'smoke', 'validate', 'flows', 'juice', 'playthrough',
        'architecture', 'l10n', 'data', 'layout', 'textsize')
    if ($Runner -notin $known) { Stop-GodotCi "Unknown test runner: $Runner" 'invalid-arguments' }

    $summary = Invoke-TestRunner -Runner $Runner -Info $Info -ResultsDir $ResultsDir -Filter $Filter `
        -Coverage $false -Frames $Frames -GameArgs @()
    return [pscustomobject]@{
        Runner  = $Runner
        Ok      = [bool]$summary.Ok
        Summary = $summary
    }
}
```

Notes:
- The name is Verb-Noun and distinct from `Invoke-TestRunner` and `Invoke-TestRunnerWithRetry`. I did not run `tests/Test-LibNames.ps1` to confirm it.
- The runner list comes from the switch in `Runners.ps1` and the header. I did not check `Write-TestSummary` for its exact output shape, so `.Ok` is taken from how `Invoke-TestRunnerWithRetry` reads it.
- `Invoke-TestRunner` returns the summary through the pipeline. If `Write-TestSummary` ever emits extra output, `$summary` becomes an array and `.Ok` breaks. Wrapping the call in `@(...)` and checking the count would guard against that.
- `invalid-arguments` is an existing code. `docs/json.md` lists it, as I saw in use in `Common.ps1`.
- I have not run this under pwsh.
