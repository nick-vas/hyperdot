- **Files to read:** `ci/godot/hyperdot.ps1`, to find the `param` block and see which parameters already have `[Validate*]` attributes.
- **Candidate selection:** pick one unvalidated parameter with a clear legal range or format, such as a numeric timeout or a string with a fixed pattern.
- **Check the dispatch:** confirm how that parameter is used by the subcommand it belongs to, so the new constraint does not reject values the script already accepts.
- **Check the contract:** confirm whether a new failure needs a `Stop-GodotCi` code. If it does, that code must be added to `docs/json.md`, since existing codes cannot be renamed.
- **Output:** a minimal unified diff against `hyperdot.ps1` only, at most 260 words, verified by reading and not by running the self-tests.

I haven't answered yet. Say go ahead, or name a parameter if you already have one in mind.
