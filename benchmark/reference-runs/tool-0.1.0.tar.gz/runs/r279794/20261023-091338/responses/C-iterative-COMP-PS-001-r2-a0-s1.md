**`test` flow**

1. **Entry (`hyperdot.ps1`)**: `test` is the default command. The script dot-sources every lib, reads the parameters, and calls `Get-ProjectInfo`. It starts the run log and history, then runs `Invoke-Setup`, `Invoke-Build`, and `Invoke-Tests`.

2. **Detection (`Detect.ps1`)**: The project is `-Project`, or the shallowest `project.godot` under the current folder. The Godot version comes from the csproj's `Godot.NET.Sdk`, then `GODOT_VERSION`, then 4.7.2. With no `-Runners`, `validate` and `architecture` always run. Others are added from the project: `dotnet` (a test SDK or gdUnit4 adapter in the solution), `godottest`, `gut`, `flows`, `smoke`, and the JSON-driven runners.

3. **Build (`Invoke-Build`)**: Installs GUT if needed, runs `dotnet build` for C# projects, then `godot --headless --import`. Crashes are retried.

4. **Runners (`Runners.ps1`)**: Results are wiped except `hyperdot.log`. Each runner runs through `Invoke-TestRunnerWithRetry`, which repeats a failed runner up to `-Retry` times. Godot is invoked as:
   - `gut`: `--headless --path P -s addons/gut/gut_cmdln.gd -gexit`
   - `validate`: `-s tools/validate.gd`
   - `smoke`: `--quit-after <Frames>`
   - `godottest`: `--run-tests --quit-on-finish`
   - `dotnet`/`gdunit4`: `dotnet test` with a generated `godot.runsettings`

5. **Verdict (`Report.ps1`)**: Parses JUnit and TRX files. A runner passes when its exit code is 0, nothing failed, and at least one test ran. Quarantined failures are excluded.

**Files written**
- `test-results/hyperdot.log`
- `test-results/<runner>/`: JUnit/TRX, the runner's log, `summary.json`, `summary.md`, `findings.json`
- `test-results/<runner>.attempt<N>/` for failed retries
- `test-results/coverage/` with `-Coverage`
- `.godot/hyperdot-history.jsonl` in the project

The `-Json` result reports `runnerResults`, `failureDelta`, `flaky`, `quarantined`, and `log`.
