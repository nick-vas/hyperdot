1. **Reading scene state before it settles.** `test_score.gd:16-17` reads `main.score.points` right after `add_child_autofree`. If the game sets points in a deferred call or on the first frame, the read is early. `flows.gd:24-25` and `:75` wait a frame for this reason. **Mitigation:** `await get_tree().process_frame` before the assert.

2. **Unseeded randomness.** The GUT tests never seed the RNG, but `flows.gd:68` seeds every flow. **Mitigation:** call `seed(...)` with a fixed value in `before_each`.

3. **Held input leaking between tests.** `flows.gd:92-93` releases every action after each flow, because a held action carries into the next run. A GUT test that fails midway leaves its action pressed. **Mitigation:** an `after_each` that calls `Input.action_release` for each name in `InputMap.get_actions()`.

4. **Window size.** Headless Godot opens a 64x64 window (`flows.gd:69-70`), so layout-dependent asserts change with the run. **Mitigation:** set `root.size` in the test, as `flows.gd:70` does, instead of relying on the default.

5. **Wall-clock waits.** A `yield_for(seconds)` drifts on a loaded runner. `flows.gd:101-104` counts physics frames instead. **Mitigation:** wait a frame count, and use `test -Retry` with `quarantine.json` (listed in AGENTS.md's self-tests table) for tests that still flake.

Scope: I read the first 150 lines of `flows.gd` and `self-test.yml`, and the GUT test file in full. I did not open the GUT runner, so the retry and quarantine behaviour comes from AGENTS.md and is unverified.
