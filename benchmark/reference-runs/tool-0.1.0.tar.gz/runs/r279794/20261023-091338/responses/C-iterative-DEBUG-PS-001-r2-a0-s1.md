**Five likely causes of a hanging test run**

1. **Godot deadlock or an await that never resumes.** Mitigation: `Invoke-Logged` (`ci/godot/lib/Common.ps1:184`) stops the process tree after `Get-ProcessTimeout` (default 1800 s, set by `HYPERDOT_TIMEOUT`) and returns 124. Keep that limit below the 45-minute job limit (`timeout-minutes: 45` in `.github/workflows/self-test.yml`) so the kit's stop fires first. `Test-ProcessTimeout.ps1` covers this.

2. **Compile or test session outliving its limit.** `Runners.ps1:35` sets `TestSessionTimeout` to 1800000 ms, and `:44` sets `CompileProcessTimeout` to 180000 ms. Mitigation: keep these aligned with `HYPERDOT_TIMEOUT`. I did not confirm that the session timeout kills the process tree, so check that on a stalled run.

3. **Pipe held open by a child process.** A build server can keep stdout open after Godot exits, so reads never reach end-of-stream. Mitigation: `Invoke-Logged` breaks out when `HasExited` is true (`Common.ps1:216`). Keep that check.

4. **Godot waiting for a display.** `bench`, `shot` and `audio -Mix` need one. Mitigation: start Xvfb and set `DISPLAY`, as `AGENTS.md` requires. Nothing in the runners detects a missing display, so it shows up only as a timeout.

5. **Retries multiplying the wait.** Crash retries (`Common.ps1:240`) repeat only for exit codes of 128 and up. A timeout returns 124, so it is not retried. Mitigation: the 45-minute job limit is the backstop against a crash-then-hang sequence.

**Gap:** `Soak.ps1` runs its own process handling and does not call `Get-ProcessTimeout`. A hung soak server is bounded only by its own stop-grace logic.
