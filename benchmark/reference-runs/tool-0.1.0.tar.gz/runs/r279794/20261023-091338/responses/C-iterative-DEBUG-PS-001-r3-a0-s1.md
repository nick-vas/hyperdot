**Five likely causes of a hanging test run, with mitigations**

1. **A Godot or test process deadlocks or never resumes an `await`.** `Invoke-Logged` in `Common.ps1` kills the process tree after `Get-ProcessTimeout` (1800 s by default, set by `HYPERDOT_TIMEOUT`) and returns 124. Mitigation: lower `HYPERDOT_TIMEOUT` in the workflow to stay under the 45-minute `timeout-minutes`. Don't set it to 0.

2. **A process waits on stdin.** `Invoke-Logged` redirects stdout and stderr but not stdin, so a prompt inherits the console and blocks until the time limit. No guard exists. Mitigation: set `RedirectStandardInput = $true` and close `StandardInput` right after `Start`.

3. **No display for `bench`, `shot` or `audio -Mix`.** These wait on or fail against a missing X server. Mitigation: start `Xvfb :99` and set `DISPLAY=:99`, as the `measure` job in `self-test.yml` does.

4. **gdUnit4 compile or session stall in the dotnet runner.** `New-RunSettings` in `Runners.ps1` sets `CompileProcessTimeout` to 180000 ms and `TestSessionTimeout` to 1800000 ms. Mitigation: keep both, and raise them only on a known-slow runner.

5. **A child process keeps the output pipes open after the parent exits**, such as a build server. `Invoke-Logged` breaks out of its loop once the process has exited (the `HasExited` check). Mitigation: keep that check, and shut down build servers after a run.

**Compounding risk:** `test -Retry` reruns the whole runner, so each hung attempt can cost up to 30 minutes. Two attempts exceed the 45-minute job limit, and GitHub cancels the job without a summary. Use `-Retry 0` when debugging hangs.

I did not run the suite. These findings come from reading the code.
