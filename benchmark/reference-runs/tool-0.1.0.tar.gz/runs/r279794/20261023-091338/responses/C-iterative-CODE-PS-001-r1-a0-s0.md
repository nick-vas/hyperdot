Files I will read:
- `AGENTS.md` (already loaded in context, so I'll use it as is)
- `ci/godot/lib/Common.ps1`, for the strict-mode setup, `Stop-GodotCi`, and `Set-JsonField` conventions
- `ci/godot/lib/Runners.ps1`, for how existing runners are shaped and how they return results

Plan:
- Check how `Common.ps1` sets strict mode and `$ErrorActionPreference`, and how `Stop-GodotCi` takes its stable code.
- Check how `Runners.ps1` invokes a runner and what fields its result carries, so the new function returns the same shape.
- Write a Verb-Noun function that returns a single structured object (no `Write-Output`) and wraps possibly-empty results in `@(...)`.
- Route failures through `Stop-GodotCi "message" 'stable-code'` and keep logs on `Write-Host`/`Write-CiLog`.
- Return only the code, with a brief note under 320 words.
