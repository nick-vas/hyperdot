```powershell
# Runs one test runner (Invoke-TestRunner) and returns its summary: Ok, Warnings and the rest of Write-TestSummary's
# object. A failing runner is a result, not an error: the caller decides what the run does with it.
function Invoke-SingleTestRunner {
    param(
        [Parameter(Mandatory)]
        [ValidateSet('dotnet', 'gdunit4', 'godottest', 'gut', 'validate', 'flows', 'juice', 'playthrough',
            'architecture', 'l10n', 'data', 'layout', 'textsize', 'smoke')]
        [string]$Runner,
        [Parameter(Mandatory)]$Info,
        [Parameter(Mandatory)][string]$ResultsDir,
        [string]$Filter = '',
        [bool]$Coverage = $false,
        [int]$Frames = 300
    )

    # Wrapped in @(): a runner that writes nothing else still yields one object, and the summary is the last one written.
    $results = @(Invoke-TestRunner -Runner $Runner -Info $Info -ResultsDir $ResultsDir -Filter $Filter -Coverage $Coverage -Frames $Frames -GameArgs @())
    if ($results.Count -eq 0) { Stop-GodotCi "$Runner runner produced no result" 'failed' }
    return $results[-1]
}
```

Notes:
- Not added to the repository. I checked the name against `ci/godot/lib` and found no clash, but `Test-LibNames.ps1` has not been run, and I did not execute the function.
- `-Frames 300` is my guess at a smoke default. I did not check it against `hyperdot.ps1`, so confirm it there or drop the parameter.
