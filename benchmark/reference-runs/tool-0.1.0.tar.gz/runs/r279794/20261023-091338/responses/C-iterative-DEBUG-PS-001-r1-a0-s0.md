Files I will read:
- `ci/godot/lib/Common.ps1`: the shared helpers, including `Stop-GodotCi` and any process time limit.
- `ci/godot/lib/Runners.ps1`: the test runners, to see how they launch Godot and wait on it.
- `.github/workflows/self-test.yml`: the CI job timeouts and how the self-tests are invoked.
- `AGENTS.md` (already loaded): the self-test table, including `Test-ProcessTimeout.ps1` and `Test-Flaky.ps1`, to check which guards are covered.

Plan:
- Read `Common.ps1` and `Runners.ps1` to find every place a child process is started and waited on, and whether a time limit applies there.
- Identify the likely hang points: a Godot process that never exits, a test waiting for a signal that never arrives, a stdin or pipe read that blocks, a retry or import loop with no bound, and a missing job-level timeout in CI.
- For each cause, note the setting or code that already guards it (such as the process time limit, `test -Retry`, or `quarantine.json`) and where that guard is missing.
- Check `self-test.yml` for `timeout-minutes` and step-level limits to see whether a stuck runner is cut off by CI.
- Write the five causes, each with one concrete mitigation, in no more than 260 words.
