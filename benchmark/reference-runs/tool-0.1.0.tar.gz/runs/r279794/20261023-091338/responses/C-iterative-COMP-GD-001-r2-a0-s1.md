The GDScript example has one GUT test file, `test/test_score.gd`, which `extends GutTest`. Its three tests are named `test_<behaviour>` (for example `test_miss_resets_combo`) and use `assert_*` calls. The `test/flows/startup.flow.json` file is for the `flows` runner, not GUT, and `test_score.gd.uid` is Godot's own resource ID.

**Discovery:** `Detect.ps1` (`Get-GutTestFiles`) walks every `.gd` file and keeps those with a line matching `^extends GutTest`. Filenames don't matter, so the `test_*.gd` naming is convention only. If any are found, the `gut` runner is selected.

**Running:** `Runners.ps1` (the `gut` case) requires `addons/gut/gut_cmdln.gd` and starts Godot headless with `-s addons/gut/gut_cmdln.gd -gexit`. It writes JUnit XML to the results folder. Without a `.gutconfig.json`, it passes one `-gdir=` per folder containing a GutTest script. `-Filter` becomes `-gunit_test_name`.

I did not confirm that `addons/gut` exists in the example, and `project.godot` contains no GUT plugin setting. I also did not run the tests.
