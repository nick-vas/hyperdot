**Before pushing, run these checks.** CI's self-test workflow runs all of them, so anything you can't run locally (Godot or a display) will still be checked there.

**Any change under `ci/godot/lib/`**
- Always: PSScriptAnalyzer on `ci/godot` with `ci/godot/PSScriptAnalyzerSettings.psd1`, and `tests/Test-LibNames.ps1` if you add or rename a function.
- Always: the self-test for that concern in the AGENTS.md table. For example, `Plan.ps1` → `Test-Plan.ps1`, `Localization.ps1` → `Test-Localization.ps1`, `Steam.ps1` → `Test-Steam.ps1`.
- If you change `test`, `doctor` or a shared runner: `pwsh ci/godot/hyperdot.ps1 test` on `examples/csharp/game` and `examples/gdscript`, and `doctor` on both.

**A skill (`.agents/skills/*/SKILL.md`)**
- Always: `pwsh ci/godot/tools/Test-Skills.ps1`, `pwsh tests/Test-SkillFixtures.ps1` and `pwsh tests/Test-DocLinks.ps1`.
- If it quotes a command, flag, error code or version: `tests/Test-Context.ps1`.
- If it quotes a shader: `tests/Test-SkillShaders.ps1` (needs Godot).
- If it describes capture mode: `tests/Test-Capture.ps1` (needs Godot and a display).

**A page under `docs/`**
- Always: `tests/Test-DocLinks.ps1`.
- If it names kit flags, files, commands or error codes, or you change `docs/json.md`: `tests/Test-Context.ps1`.
- If it documents a feature with its own row in the table (e.g. the palette in `STYLE.md` → `Test-Palette.ps1`): run that row.

I did not run any of these; this answer is from reading `AGENTS.md` and `self-test.yml`.
