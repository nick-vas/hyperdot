**Every change**
- Lint: PSScriptAnalyzer clean on `ci/godot`, `hooks` and `benchmark`.
- `pwsh ci/godot/hyperdot.ps1 test` and `doctor` green on `examples/csharp/game` and `examples/gdscript`.

**If you change `ci/godot/lib/*.ps1`**
- Always: `tests/Test-LibNames.ps1` (unique names, no alias clashes).
- Run the script in AGENTS.md's table for that concern. For example, Plan → `Test-Plan.ps1`, Playtest → `Test-Playtest.ps1`, Palette → `Test-Palette.ps1`, Steam → `Test-Steam.ps1`.
- If you add or change an error code, update `docs/json.md`. Codes are API.

**If you change a skill (`.agents/skills/*/SKILL.md`)**
- Always: `pwsh ci/godot/tools/Test-Skills.ps1` and `tests/Test-SkillFixtures.ps1`.
- Always: `tests/Test-DocLinks.ps1`.
- If it quotes a flag, command, error code or version: `tests/Test-Context.ps1`, and check it against `docs/json.md` and `examples/csharp`.
- If it quotes a shader: `tests/Test-SkillShaders.ps1` (needs Godot).

**If you change a page under `docs/`**
- Always: `tests/Test-DocLinks.ps1`.
- If it names kit flags, files or commands: `tests/Test-Context.ps1`.

**Environment:** Godot and a display (`Xvfb :99`, `DISPLAY=:99`, not `xvfb-run`) are needed for the scripts marked Godot or display in the table. CI runs the full set on push and on pull requests to `main`.

I read AGENTS.md and `.github/workflows/self-test.yml`. I have not run any of these checks here.
