1. **Reading state before the scene is ready.** `test_score.gd:16-17` reads `main.score.points` right after `add_child_autofree`. If `main.gd` sets that up in a deferred call, the read races. Mitigation: `await get_tree().process_frame` after `add_child_autofree`, as `flows.gd:75` does.

2. **Unseeded randomness.** `flows.gd:68` seeds the global RNG for each flow, but `test_score.gd` never seeds it, so any random draw in `Score` or `main.gd` changes between runs. Mitigation: call `seed(0)` in `before_each`.

3. **Display not ready in CI.** The `measure` job starts `Xvfb :99 &` and exports `DISPLAY` without waiting for the server (`self-test.yml:372-373`). The Web step only sleeps 2 seconds (`:495`). A window-based test can start before the display accepts connections. Mitigation: poll `xdpyinfo -display :99` until it succeeds before the next step.

4. **Fixed frame waits.** `wait` and `wait_until` count frames, and `wait_until` defaults to 300 (`flows.gd:176`). A slow runner can exhaust that. Mitigation: wait on a state condition with an explicit, larger `timeout`, not a fixed `wait` count.

5. **State leaking between tests.** `flows.gd:88-93` releases held actions between flows, but GUT tests get no such reset, so a held action or a singleton can carry into the next test. Mitigation: release actions and free singletons in `after_each`. Use `test -Retry` with `quarantine.json` only as a dated stopgap, since `Test-Flaky.ps1` covers it.

I did not read `godot.yml`, `main.gd`, or the GUT runner in `Runners.ps1`. Causes 1 and 5 depend on them and should be checked there.
