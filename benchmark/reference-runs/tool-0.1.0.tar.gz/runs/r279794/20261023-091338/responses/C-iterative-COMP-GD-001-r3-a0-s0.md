- **Files to read:** `examples/gdscript/test/` (directory listing and test scripts), `examples/gdscript/project.godot` (GUT plugin and test settings), `ci/godot/lib/Runners.ps1` (the test runner and how it invokes GUT), and `ci/godot/lib/Detect.ps1` (how the kit detects GDScript tests).
- **Discovery:** Check how files are found (naming pattern, folder, `test_` prefix or `.gd` suffix) and whether Detect.ps1 keys on GUT or a `test/` folder.
- **Organization and naming:** Look at the test classes, `extends` base, method naming (`test_*`), and any grouping by feature or file.
- **Runner:** Trace how Runners.ps1 launches GUT (command line, flags, output parsing into the `-Json` result) and where failures are reported.
- **Output:** Write a summary of at most 200 words covering organization, naming, discovery, and execution, citing `file:line` where useful.

I have not read any files yet. Tell me to proceed and I'll do the reading and give the 200-word summary.
