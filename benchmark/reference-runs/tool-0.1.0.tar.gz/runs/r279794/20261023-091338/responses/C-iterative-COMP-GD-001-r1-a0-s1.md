The GDScript example has one GUT test file, `examples/gdscript/test/test_score.gd`, with three tests. The `flows/startup.flow.json` file is a flow script for the separate `flows` runner, not a GUT test. `test_score.gd.uid` is Godot's import sidecar. The `project.godot` file has no test settings.

**Organization and naming:** The file extends `GutTest`, and each test is a `test_*` function. The names describe behaviour: `test_every_fifth_hit_raises_the_multiplier`, `test_miss_resets_combo`, and `test_main_scene_scores_on_ready`. The last one instantiates `res://main.tscn` and asserts on the scene.

**Discovery:** `Detect.ps1` selects the `gut` runner when any `.gd` file in the project has `extends GutTest` at line start (`Get-GutTestFiles`). The kit does not read `.gutconfig.json` here because none exists. The runner then passes each folder holding such a file to GUT as `-gdir=`.

**Running:** `Runners.ps1` checks that `addons/gut/gut_cmdln.gd` exists. It runs Godot headless with `-s addons/gut/gut_cmdln.gd -gexit -gdisable_colors`, writes `gut.junit.xml` and `gut.log` to the results folder, and passes `-gunit_test_name` when a filter is given.
