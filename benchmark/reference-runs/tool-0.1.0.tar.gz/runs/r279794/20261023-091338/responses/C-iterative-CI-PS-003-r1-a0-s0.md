**Files I will read:**
- `AGENTS.md`: already loaded above via CLAUDE.md, so I will use that copy rather than re-read it.
- `.github/workflows/self-test.yml`: to confirm which self-tests CI runs and how the plan step is wired.

**Plan:**
- Map each change type (`ci/godot/lib`, skills, `docs/`) to the rules in AGENTS.md: the Self-tests table, the skill checks, and the example verification.
- Check `self-test.yml` for any extra checks it runs, such as doc links or the `plan` step.
- Write if/then rules that name the scripts, including the `-NoGodot` and display requirements.
- Keep the answer to 240 words or fewer.

I have not written the answer yet. Say the word and I'll read the workflow file and give it.
