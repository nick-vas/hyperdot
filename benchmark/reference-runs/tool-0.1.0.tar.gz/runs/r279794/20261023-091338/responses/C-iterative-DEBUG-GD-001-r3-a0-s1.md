Five likely causes, with a mitigation for each. I read the test file, `flows.gd`, and `self-test.yml`.

1. **Display not ready when the first Godot step starts.** `self-test.yml:372` starts `Xvfb :99 &` with no readiness check, so the `bench` and `shot` steps can race it. The Web step waits 2 s (line 495), but `measure` does not.
   *Mitigation:* poll for `/tmp/.X11-unix/X99` before the bench step.

2. **Reading scene state before `_ready`.** `test_score.gd:16-17` reads `main.score.points` straight after `add_child_autofree`. If `main.gd` sets up `score` on a deferred call or the first frame, the assert sees nothing.
   *Mitigation:* add `await get_tree().process_frame` before reading, as `flows.gd:25` and `:75` do.

3. **State leaking between tests.** GUT runs every test in one process. Autoloads, static vars, and the root window size (which `flows.gd:69-70` has to reset by hand) carry over.
   *Mitigation:* reset shared state in `before_each` and keep each test's scene in `add_child_autofree`.

4. **Unseeded randomness.** `flows.gd:68` calls `seed()` per flow, but nothing in `test_score.gd` does, so any `randi()` in the game changes between runs.
   *Mitigation:* call `seed(0)` in `before_each`, or give the test a fixed seed.

5. **Frame counts standing in for conditions.** `wait` steps in `flows.gd` count frames, and `wait_until` gives up after 300 frames by default. A slow runner can time out where a fast one passes.
   *Mitigation:* wait on the condition with `wait_until` and a larger `timeout`. For a test that is still flaky, use `test -Retry` with a dated `quarantine.json` entry, so it cannot hide a real failure for long.
