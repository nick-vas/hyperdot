The `-Frames` parameter has no validation. Zero or negative values reach `--quit-after` and the shot and smoke runners unchecked. The change below uses `ValidateRange(1, 100000)`. The upper bound is my choice, not something the code states; adjust it if you have a real limit.

```diff
--- a/ci/godot/hyperdot.ps1
+++ b/ci/godot/hyperdot.ps1
@@ -75,2 +75,3 @@
     # Frames the smoke runner plays, launched exports play, and shot waits before each screenshot.
-    [int]$Frames = 120,
+    [ValidateRange(1, 100000)]
+    [int]$Frames = 120,
```

Checked by reading only, not run:
- `$Frames` is passed to the test runner (line 334), `--quit-after` for exported builds (line 535), and `Invoke-Shot` (line 584). Every caller needs at least one frame, so the lower bound of 1 rejects only values that would fail anyway.
- The attribute runs at parameter binding, before any `Stop-GodotCi` call, so no new error code is needed and `docs/json.md` is unchanged.
- The `[ValidateRange]` attribute sits above `[int]`, matching the existing `-Retry` line (56–57).
