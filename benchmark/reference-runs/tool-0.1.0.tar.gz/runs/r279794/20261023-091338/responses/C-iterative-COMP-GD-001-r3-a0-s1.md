**Organization and naming:** The example has one GUT suite, `test/test_score.gd`, which `extends GutTest`. Its three methods are named `test_*` and check the score multiplier, combo reset, and that the main scene scores on ready. There is also `test/flows/startup.flow.json`, a scripted scene check. That file belongs to the separate `flows` runner, not GUT. The `.uid` file is Godot's own.

**Discovery:** There is no `.gutconfig.json`, so `Get-GutTestFiles` (Detect.ps1:56) searches for `.gd` files whose first-column `extends GutTest` line matches, and Detect.ps1:141 adds the `gut` runner when any are found. Runners.ps1:141-144 then passes each such folder to GUT as `-gdir=res://...`.

**Execution:** Runners.ps1:135-150 runs Godot headless with `addons/gut/gut_cmdln.gd`, `-gexit`, and `-gjunit_xml_file` pointing to `gut.junit.xml` in the results folder. Output goes to `gut.log`. A `-Filter` becomes `-gunit_test_name`. The run fails if `addons/gut` is missing. `Write-TestSummary` then reads the results.

**Not verified:** `project.godot` enables no GUT plugin, and I did not confirm that `addons/gut` is present in the example. I also did not trace how the `flows` runner finds its JSON files.
