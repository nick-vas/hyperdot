# Token benchmark 20261023-091338

Model claude-haiku-5-5, 3 run(s) per task and profile, 48 session(s), CLI 2.1.309 (Claude Code), without the plugin.
Tokens include cache reads and writes; cost is Claude Code's own figure. Medians leave out sessions stopped at the time limit, whose spend is unknown (the "Unknown" column).

| Profile | Runs | Success % | Median tokens | P90 tokens | Median output | Median turns | Median cost | Total cost | Successes per $ | Median time (s) | Retries | Unknown |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| C-iterative | 24 | 91.7 | 94,054 | 132,870 | 2,876 | 6 | $0.0077 | $0.2021 | 108.85 | 18.0 | 0 | 0 |

| Task | Profile | Successes | Median tokens | Median cost | Failures |
|---|---|---:|---:|---:|---|
| COMP-PS-001 | C-iterative | 3/3 | 131,707 | $0.0161 |  |
| COMP-GD-001 | C-iterative | 3/3 | 90,976 | $0.0041 |  |
| CODE-PS-001 | C-iterative | 3/3 | 87,991 | $0.0087 |  |
| CODE-PS-002 | C-iterative | 3/3 | 129,370 | $0.0050 |  |
| DEBUG-PS-001 | C-iterative | 2/3 | 95,462 | $0.0078 | 261 words, limit 260 |
| DEBUG-GD-001 | C-iterative | 3/3 | 132,396 | $0.0081 |  |
| CI-PS-001 | C-iterative | 2/3 | 71,502 | $0.0051 | missing 're:\bscop(e/ed)\b' |
| CI-PS-003 | C-iterative | 3/3 | 88,692 | $0.0080 |  |
