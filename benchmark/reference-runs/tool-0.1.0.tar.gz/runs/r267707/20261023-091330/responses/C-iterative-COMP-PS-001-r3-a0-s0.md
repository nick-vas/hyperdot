Files I will read:
- `ci/godot/hyperdot.ps1` (entry point and the `test` dispatch)
- `ci/godot/lib/Detect.ps1` (project and runner detection)
- `ci/godot/lib/Runners.ps1` (how Godot is invoked per runner)
- `ci/godot/lib/Report.ps1` (the files and reports a run writes)
- `docs/json.md` (the `-Json` output contract)

Plan:
- Read `hyperdot.ps1` to trace how `test` is dispatched, which parameters it takes, and which libs it loads.
- Read `Detect.ps1` to see how the project root and runners (GUT, gdUnit4, GoDotTest, dotnet) are found.
- Read `Runners.ps1` to see the Godot command line for each runner, plus retries and timeouts.
- Read `Report.ps1` and `docs/json.md` to list the output files (JUnit/TRX, history, logs) and the JSON fields and error codes.
- Write an answer of at most 240 words that follows the flow in order.
