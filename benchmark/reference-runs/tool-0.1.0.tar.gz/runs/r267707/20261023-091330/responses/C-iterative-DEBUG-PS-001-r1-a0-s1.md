Most likely causes of a hanging test run, each with a mitigation. I read the greps of `Common.ps1`, `Runners.ps1` and `self-test.yml`, not the full files.

1. **Godot stalls or never quits.** Guard: `Get-ProcessTimeout` (`Common.ps1:173`) defaults to 1800 s. On expiry it kills the process tree and returns 124. Mitigation: set `HYPERDOT_TIMEOUT` lower for quick feedback. `0` turns the guard off, so don't use it.

2. **Test script never calls quit.** GUT, GoDotTest and the smoke runner can wait forever for an exit. Guards: `-gexit` for GUT (`Runners.ps1:139`), `--quit-on-finish` for GoDotTest (line 116) and `--quit-after` for the smoke run (line 195). Mitigation: make sure custom runners always pass one of these.

3. **gdUnit4Net rebuild or session stalls.** Guards: the generated runsettings set `TestSessionTimeout` to 1800000 ms and `CompileProcessTimeout` to 180000 ms (`Runners.ps1:35,44`). Mitigation: shorten `CompileProcessTimeout` if builds are normally fast.

4. **Missing display for `bench`, `shot` and `audio -Mix`.** Under `--headless` the other runners need none. I found no code guard for this, only the documented workaround. Mitigation: start `Xvfb :99 &` and set `DISPLAY=:99`. Don't use `xvfb-run`, which breaks `-Json`. `self-test.yml:372` does this. Also, a backgrounded Xvfb that dies leaves the display missing.

5. **Crash at shutdown or a flaky test, then retries.** The shutdown crash is the known `singleton is null` one. Retries add time, not hangs. Guard: the crash retry in `Common.ps1:253` is capped at 2 retries. `test -Retry` is capped by the count you pass (`Runners.ps1:245`). Mitigation: keep `-Retry` small and move known-flaky tests into `quarantine.json`.

Backstop for the CI workflow: each job has `timeout-minutes: 45`. `Test-ProcessTimeout.ps1` runs in the workflow to check the process time limit.
