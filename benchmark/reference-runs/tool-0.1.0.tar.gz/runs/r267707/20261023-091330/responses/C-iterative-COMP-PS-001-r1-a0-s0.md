Files I will read:
- `ci/godot/hyperdot.ps1`
- `ci/godot/lib/Detect.ps1`
- `ci/godot/lib/Runners.ps1`
- `ci/godot/lib/Report.ps1`
- `docs/json.md`

Plan:
- Read `hyperdot.ps1` to find the `test` entry point: parameter handling, dot-sourcing of libs, and the dispatch to the test command.
- Read `Detect.ps1` to see how the project root and runners (GUT, gdUnit4, GoDotTest, dotnet) are detected.
- Read `Runners.ps1` to see how Godot is invoked for each runner: arguments, import step, timeouts and retries.
- Read `Report.ps1` and `docs/json.md` to see which files a run produces (reports, history, JSON fields) and the stable error codes.
- Then write the answer in 240 words or fewer.
