```powershell
# Runs one GUT-style test runner and returns its outcome. The caller decides what a failed run means.
function Invoke-SingleTestRunner {
    param(
        [Parameter(Mandatory)][string]$Runner,
        [Parameter(Mandatory)][string]$ProjectDir,
        [Parameter(Mandatory)][string]$ResultsDir,
        [string]$Filter,
        [string]$FilePath = $env:GODOT_BIN
    )

    if (-not $FilePath) { Stop-GodotCi 'GODOT_BIN is not set' 'godot-not-found' }
    if ($Runner -ne 'gut') { Stop-GodotCi "Unknown runner: $Runner" 'invalid-arguments' }
    if (-not (Test-Path -LiteralPath (Join-Path $ProjectDir 'addons/gut/gut_cmdln.gd'))) {
        Stop-GodotCi 'gut runner: addons/gut is missing'
    }

    if (Test-Path -LiteralPath $ResultsDir) { Remove-Item -Recurse -Force $ResultsDir }
    New-Item -ItemType Directory -Force $ResultsDir | Out-Null

    $junit = Join-Path $ResultsDir 'gut.junit.xml'
    $arguments = @('--headless', '--path', $ProjectDir, '-s', 'addons/gut/gut_cmdln.gd',
        '-gexit', '-gdisable_colors', "-gjunit_xml_file=$junit")
    if ($Filter) { $arguments += "-gunit_test_name=$Filter" }

    Start-LogGroup 'GUT'
    $log = Join-Path $ResultsDir 'gut.log'
    $code = Invoke-Logged $FilePath $arguments $log
    Stop-LogGroup

    return [pscustomobject]@{
        Runner  = $Runner
        Ok      = ($code -eq 0)
        Code    = $code
        Junit   = $junit
        Log     = $log
        TimedOut = ($code -eq 124)
    }
}
```

Notes:
- It follows the conventions in `Common.ps1` and `Runners.ps1`. The only output is the final `return` of one `[pscustomobject]`, with no `Write-Output`. Logging goes through `Start-LogGroup`/`Stop-LogGroup` and `Invoke-Logged`, which use `Write-Console`, so stderr stays clean under `-Json`.
- Failures use `Stop-GodotCi "message" 'code'`. The codes `godot-not-found` and `invalid-arguments` are my picks. `invalid-arguments` already appears in `Common.ps1`. Check that both are in `docs/json.md`, and add `godot-not-found` there if it's missing. The repo says codes are API and must never be renamed.
- A test run that exits non-zero is returned as `Ok = $false`, not thrown, which matches `Invoke-Logged`'s "return the exit code" contract.
- I didn't run it. Strict mode and `$ErrorActionPreference = 'Stop'` come from the entry point.
