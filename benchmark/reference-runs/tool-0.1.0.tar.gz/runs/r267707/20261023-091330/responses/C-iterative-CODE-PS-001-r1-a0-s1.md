```powershell
# Runs one program as a test runner and returns what happened. A missing program stops the run; a failing test run
# does not, so the caller decides what a non-zero exit code means (as Invoke-Logged does).
function Invoke-SingleTestRunner {
    param(
        [Parameter(Mandatory)][string]$Runner,
        [Parameter(Mandatory)][string]$FilePath,
        [string[]]$ArgumentList = @(),
        [Parameter(Mandatory)][string]$ResultsDir,
        [string]$Filter
    )
    Set-StrictMode -Version 3.0

    if (Test-Path -LiteralPath $ResultsDir) { Remove-Item -Recurse -Force $ResultsDir }
    New-Item -ItemType Directory -Force $ResultsDir | Out-Null
    if (-not (Get-Command $FilePath -CommandType Application -ErrorAction SilentlyContinue)) {
        Stop-GodotCi "$Runner runner: program not found: $FilePath" 'runner-program-missing'
    }
    if ($Filter) { $ArgumentList += @('--filter', $Filter) }

    $log = Join-Path $ResultsDir "$Runner.log"
    Start-LogGroup $Runner
    $code = Invoke-Logged $FilePath $ArgumentList $log
    Stop-LogGroup

    $errors = @(Get-GodotLogErrors $log)
    if ($code -eq 0 -and $errors.Count -gt 0) { Write-CiLog "$Runner exited 0 but logged $($errors.Count) engine error(s)" }

    $result = [pscustomobject]@{
        runner = $Runner
        ok     = ($code -eq 0 -and $errors.Count -eq 0)
        code   = $code
        errors = @($errors | Select-Object -First 30)
        log    = $log
    }
    return $result
}
```

Notes:
- No `Write-Output`. The function logs with `Write-CiLog` and `Start-LogGroup`/`Stop-LogGroup`, and its only output is the returned object.
- `Stop-GodotCi` is used only for a missing program. A failing run comes back as `ok = $false` so the caller decides.
- `runner-program-missing` is a new code. It must be added to `docs/json.md` and never renamed.
- The caller adds the result with `Set-JsonField runnerResults @(...)`.
- Errors are wrapped in `@(...)`, as `Get-GodotLogErrors` requires.
- I haven't run this. It also scans the log with `Get-GodotLogErrors`, which targets Godot, so a non-Godot runner's log would be scanned too.
- The `--filter` flag is only right for `dotnet test`.
