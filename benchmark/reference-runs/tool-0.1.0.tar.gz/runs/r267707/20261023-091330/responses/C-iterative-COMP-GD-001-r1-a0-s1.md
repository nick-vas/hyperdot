**Organization:** `examples/gdscript/test/` holds `test_score.gd` (plus its `.uid`) and `flows/startup.flow.json`. The flow file belongs to the `flows` runner, not GUT. `project.godot` has no test settings. The example has no `.gutconfig.json`.

**Naming:** The script is `test_score.gd` and begins with `extends GutTest`. Its test methods are named `test_*`, for example `test_miss_resets_combo`. They cover the `Score` class and the main scene.

**Discovery:** `Get-GutTestFiles` in `Detect.ps1` finds tests by content, not by file name. It scans the project's `.gd` files, skipping folders that contain a `.gdignore`. It keeps those with a line matching `^extends\s+GutTest`. If any exist, `gut` is added to the selected runners.

**Running:** The `gut` runner in `Runners.ps1` first requires `addons/gut/gut_cmdln.gd`. If it is missing, it fails with "gut runner: addons/gut is missing". The command line is `godot --headless --path <project> -s addons/gut/gut_cmdln.gd -gexit -gdisable_colors -gjunit_xml_file=<ResultsDir>/gut.junit.xml`.

Without `.gutconfig.json`, it adds a `-gdir=res://…` argument for every folder containing a GutTest script. `-Filter` becomes `-gunit_test_name=<Filter>`. Output goes to `gut.log`.
