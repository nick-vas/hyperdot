```diff
--- a/ci/godot/hyperdot.ps1
+++ b/ci/godot/hyperdot.ps1
@@ -75,3 +75,4 @@
     # Frames the smoke runner plays, launched exports play, and shot waits before each screenshot.
+    [ValidateRange(1, 100000)]
     [int]$Frames = 120,
     # smoke: run at this fixed rate of game time (--fixed-fps), so -Frames is game time and a bot's run is the same on
```

`-Frames` is the number of frames the smoke runner plays, launched exports play, and `shot` waits before each screenshot. Today it accepts zero and negative values, which can't mean anything for a frame count. The new range rejects them before any work starts. The upper bound is my own generous cap, not a limit I found in the script.

I didn't check how the script uses `-Frames` further down or whether `docs/json.md` mentions it. I also didn't run any tests. If a caller passes `-Frames 0` on purpose, this change would break it.
