Five likely causes of a hanging test run, each with a mitigation. I read only grep matches from the three files, not the full files.

1. **Godot or a test child process never exits.**
   - Guard: `Get-ProcessTimeout` and the wait loop in `Common.ps1` (lines 173–235). It kills the process tree with `Kill($true)` and returns 124.
   - Mitigation: raise `HYPERDOT_TIMEOUT` only if the run is legitimately slow. Otherwise find the test that spins.

2. **gdUnit4Net rebuilds the project and stalls.**
   - Guard: the generated runsettings in `Runners.ps1` set `CompileProcessTimeout` to 180000 ms and `TestSessionTimeout` to 1800000 ms.
   - Mitigation: keep the build clean and warm so the 180 s compile limit isn't hit.

3. **Display-dependent steps (`bench`, `shot`, `audio -Mix`) have no display.**
   - Guard: `self-test.yml` starts `Xvfb :99` directly and exports `DISPLAY` (lines 370–373).
   - Mitigation: start Xvfb yourself and set `DISPLAY=:99`. Don't use `xvfb-run`, because it breaks `-Json`.

4. **A flaky test or a crashed import or export is retried over and over.**
   - Guard: `test -Retry` with `quarantine.json` (`Invoke-TestRunnerWithRetry`, `Runners.ps1` line 236). Retries are capped at `$Retry` extra attempts. `Test-CrashRetry.ps1` covers the repeat of a crashed import or export.
   - Mitigation: keep `-Retry` small and quarantine known-flaky tests.

5. **The whole CI job hangs.**
   - Guard: `timeout-minutes: 45` on the jobs in `self-test.yml` (lines 17, 249, 365, 478, 501, 512).
   - Mitigation: set a tighter `timeout-minutes` on the slow jobs, so a hang fails sooner than 45 minutes.

I didn't confirm what guards a stalled download (the `download-failed` code and `Test-DownloadFailed.ps1` look relevant).
