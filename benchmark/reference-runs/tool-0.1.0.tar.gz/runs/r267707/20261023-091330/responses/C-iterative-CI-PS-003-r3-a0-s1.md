**Change under `ci/godot/lib/`**
- Always run `pwsh tests/Test-LibNames.ps1`. It catches duplicate function names and clashes with built-in aliases.
- Run the self-test whose "Covers" entry matches the file you touched. For example, `Plan.ps1` maps to `Test-Plan.ps1` and `Store.ps1` to `Test-Store.ps1`.
- Run `Test-Context.ps1` if you changed or renamed a flag.
- Run `pwsh ci/godot/hyperdot.ps1 test -Project examples/csharp/game` and the same with `-Project examples/gdscript`. Also run `doctor` on both. All four must be green.
- If you changed `plan`, check it the way CI's Plan step does:
  1. Copy `examples/gdscript` to a temporary folder.
  2. Run `git init` there.
  3. Run `plan -Do init -Project <copy>`.
  4. Run `plan -Json -Project <copy>`.
  
  Expect phase `concept` and at least one next action.
- If the matching test needs a display (`bench`, `shot`, `audio -Mix`), start `Xvfb :99 &` and set `DISPLAY=:99`. Don't use `xvfb-run`.
- If you added an error code, add it to `docs/json.md`.

**Skill change (`.agents/skills/`)**
- Run `pwsh ci/godot/tools/Test-Skills.ps1` and `pwsh tests/Test-SkillFixtures.ps1`. Both must pass.
- Run `Test-DocLinks.ps1` and `Test-Context.ps1`.
- If the skill quotes a shader, run `Test-SkillShaders.ps1`.
- Check every quoted command, flag, code and version against the real script, `docs/json.md` and `examples/csharp`.
- The description says only when to use the skill, never how.

**Docs change (`docs/`)**
- Run `pwsh tests/Test-DocLinks.ps1`.
- If the page names kit flags or files, also run `Test-Context.ps1`.
- If the page is `docs/json.md`, check it against the error codes in the code.

CI also runs PSScriptAnalyzer on `ci/godot`, `hooks` and `benchmark`. I haven't run it here.
