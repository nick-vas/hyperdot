```diff
--- a/ci/godot/hyperdot.ps1
+++ b/ci/godot/hyperdot.ps1
@@ -58,5 +58,6 @@
     # Collect coverage (dotnet, gdunit4, godottest) into one report.
     [switch]$Coverage,
     # Fail when line coverage is below this percentage (implies -Coverage).
+    [ValidateRange(0, 100)]
     [double]$MinCoverage = 0,
```

I haven't run this. `-MinCoverage` is a percentage with no check today. `Report.ps1` and `hyperdot.ps1` only test `-gt 0`, so a negative value silently turns the gate off. A value above 100, such as `-MinCoverage 900`, can never be met, so the run fails with no hint of why. The attribute rejects both at parameter binding and keeps the default of 0. I looked at `-Resolution`, `-Clients`, `-Count`, `-PeakDb`, `-JunkPps` and `-PaletteTolerance` first. All of them are already checked, with the `invalid-arguments` code.
