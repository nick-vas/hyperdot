Files I'll read and plan:

- `AGENTS.md`: already in context. It gives the display, Xvfb and stderr rules, the `await process_frame` rule, and the self-test table (`Test-Flaky.ps1`, `Test-Flows.ps1`).
- `examples/gdscript/test`: read the GUT tests for timing waits, shared state, randomness and scene or autoload leakage.
- `ci/godot/tools/flows.gd`: check how steps are timed (frames versus wall-clock), plus resize, hold and release handling.
- `.github/workflows/self-test.yml`: check the runner setup, Xvfb, Godot caching or downloads, matrix versions and any retry or quarantine settings.
- Plan: read these four, then pick five causes grounded in what the files show. Pair each with one repo-specific mitigation (for example `test -Retry`, `quarantine.json`, frame-based waits), and keep the answer to 260 words or fewer.
