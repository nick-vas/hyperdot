Files to read:
- `AGENTS.md` (already in context; conventions)
- `ci/godot/lib/Common.ps1` (`Stop-GodotCi`, `Set-JsonField`, `Write-CiLog`)
- `ci/godot/lib/Runners.ps1` (how existing runners shape their results)

Plan:
- Read `Common.ps1` to get the exact signatures of `Stop-GodotCi`, `Write-CiLog` and `Set-JsonField`, and how `$script:JsonDoc` is used.
- Read `Runners.ps1` to match an existing runner's naming (Verb-Noun), parameters, result fields, exit-code handling and use of `@(...)`.
- Write a Verb-Noun function with no `Write-Output`. It will log with `Write-CiLog`, fail with `Stop-GodotCi "message" 'stable-code'`, and return a single `[pscustomobject]` result, wrapping collections in `@(...)`.
- If I add a new error code, note that it belongs in `docs/json.md` and must never be renamed.

I haven't read the files yet. Next I'll read the three files and then write the function.
