**Before pushing, by what you changed** (from `AGENTS.md` and `self-test.yml`):

**A file under `ci/godot/lib`**
- Always run `pwsh tests/Test-LibNames.ps1` (no duplicate function names, no built-in alias clashes). CI also runs PSScriptAnalyzer, so run it too.
- Run the self-test for the concern you changed. Examples: `Audio.ps1` → `Test-Audio.ps1`; `Plan.ps1` → `Test-Plan.ps1`; `Doctor.ps1` → the matching `Test-Store`, `Test-Platforms`, `Test-Addons`, `Test-Steam`, `Test-Context` or `Test-RepoHygiene`.
- If the script needs Godot, Xvfb or ffmpeg, set those up first. Start `Xvfb :99 &` and set `DISPLAY=:99`; don't use `xvfb-run`. Use `-NoGodot` where the script has it and you can't run Godot.
- If you touched shared or runner code, run `pwsh ci/godot/hyperdot.ps1 test -Project examples/csharp/game` and the same with `-Project examples/gdscript`. Both must be green, and so must `doctor` on both.
- If `plan` is affected, copy `examples/gdscript` to a temporary folder and `git init` it. Then run `plan -Do init -Project <copy>` and `plan -Json -Project <copy>`. Expect phase `concept` and at least one next action.
- If you change a version matrix entry, rerun the examples on that Godot version.

**A skill under `.agents/skills`**
- Run `pwsh ci/godot/tools/Test-Skills.ps1` and `pwsh tests/Test-SkillFixtures.ps1`; both must pass.
- Check any command, flag, error code or version quoted in the skill against the real script, `docs/json.md` and `examples/csharp`.
- Also run `Test-DocLinks.ps1` and `Test-Context.ps1`. Add `Test-SkillShaders.ps1` (needs Godot) if the skill quotes a shader.
- The description must say only when to use the skill, never how.

**A page under `docs/`**
- Run `pwsh tests/Test-DocLinks.ps1`.
- Run `Test-Context.ps1` if the page quotes kit flags.
- If you add or change an error code, update `docs/json.md`. Codes are API: add them, never rename them.
