These rules come from `AGENTS.md` and `.github/workflows/self-test.yml`. I read both. I did not open the test scripts, so what each one covers comes from the AGENTS.md table.

**Change to `ci/godot/lib/*.ps1`**
- Always run `pwsh tests/Test-LibNames.ps1`. It fails on duplicate function names and names that clash with built-in aliases.
- Run the example checks:
  - `pwsh ci/godot/hyperdot.ps1 test -Project examples/csharp/game` and `test -Project examples/gdscript`.
  - `doctor` on both examples.
  - All four must be green.
- Run the self-test for the concern you touched, from the "Self-tests" table. For example, `Plan.ps1` maps to `Test-Plan.ps1`, `Audio.ps1` to `Test-Audio.ps1` and `Steam.ps1` to `Test-Steam.ps1`.
  - Scripts marked "Godot" or "display" need Godot. For the display ones, start `Xvfb :99 &` and set `DISPLAY=:99`.
- If you touched plan code, check `plan` as the Plan step in `self-test.yml` does. Copy `examples/gdscript` to a temp folder and run `git init` there. Then run `plan -Do init -Project <copy>` and `plan -Json -Project <copy>`. Expect phase `concept` and at least one next action.
- If you added or changed an error code, add it to `docs/json.md`.
- If you changed a version matrix entry, re-run both examples on that Godot.

**Change to a skill (`.agents/skills/*/SKILL.md`)**
- Run `pwsh ci/godot/tools/Test-Skills.ps1` and `pwsh tests/Test-SkillFixtures.ps1`. Both must pass.
- Run `Test-DocLinks.ps1` for links and quoted paths, and `Test-Context.ps1` for flags quoted against the real script.
- If the skill quotes a shader, run `Test-SkillShaders.ps1`. It needs Godot.
- Check that the description says only when to use the skill, not how.

**Change to a page under `docs/`**
- Run `pwsh tests/Test-DocLinks.ps1` and `pwsh tests/Test-Context.ps1`.
- If you edited `docs/json.md`, check it against the real output and error codes.

`.github/workflows/self-test.yml` runs everything, so use it as the final check.
