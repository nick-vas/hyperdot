```diff
--- a/ci/godot/hyperdot.ps1
+++ b/ci/godot/hyperdot.ps1
@@ -94,7 +94,8 @@
     # bench: a name for this run in bench.csv, e.g. 'vsync-off 1080p'.
     [string]$Label = '',
     # bench, shot: window size, e.g. 1920x1080.
+    [ValidatePattern('^[1-9]\d{1,4}x[1-9]\d{1,4}$')]
     [string]$Resolution,
```

I haven't run this. `-Resolution` is only documented as "e.g. 1920x1080", and the pattern rejects values like `1920`, `1920*1080` or `0x0` when the parameters bind. I didn't check how `bench` and `shot` parse the value.

I first looked at `-Clients`, `-Count` and `-PeakDb`. `Soak.ps1` and `Sfx.ps1` already check them and fail with `invalid-arguments`. A `ValidateRange` there would replace that stable error code with a PowerShell binding error, so I chose `-Resolution`.
