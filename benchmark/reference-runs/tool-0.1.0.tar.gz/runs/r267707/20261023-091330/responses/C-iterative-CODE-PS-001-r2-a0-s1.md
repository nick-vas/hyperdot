```powershell
# Runs one program as a test runner and returns its verdict. A failing test is a result (Ok = $false), not an error:
# the caller decides what a failure means. Only a bad call stops the run.
function Invoke-ProgramTestRunner {
    param([string]$Runner, [string]$FilePath, [string[]]$ArgumentList = @(), [string]$ResultsDir)

    if (-not $Runner -or -not $FilePath -or -not $ResultsDir) {
        Stop-GodotCi 'Invoke-ProgramTestRunner needs -Runner, -FilePath and -ResultsDir' 'invalid-arguments'
    }
    if (Test-Path -LiteralPath $ResultsDir) { Remove-Item -Recurse -Force $ResultsDir }
    New-Item -ItemType Directory -Force $ResultsDir | Out-Null
    $log = Join-Path $ResultsDir "$Runner.log"

    Start-LogGroup $Runner
    $clock = [System.Diagnostics.Stopwatch]::StartNew()
    $code = Invoke-Logged $FilePath $ArgumentList $log
    Stop-LogGroup

    # Godot often exits 0 after printing errors, so the log is scanned too.
    $errors = @(Get-GodotLogErrors $log)
    if ($code -eq 0 -and $errors.Count -gt 0) { $code = 1 }
    if ($code -eq 124) { Write-CiLog "$Runner hit the time limit" }

    return [pscustomobject]@{
        Runner  = $Runner
        Ok      = ($code -eq 0)
        Code    = $code
        Errors  = $errors
        Log     = $log
        Seconds = [math]::Round($clock.Elapsed.TotalSeconds, 1)
    }
}
```

I read `Common.ps1` and `Runners.ps1` and wrote this from them. I haven't run it or any self-test.

- **Return value:** it returns one `[pscustomobject]`, and nothing in it calls `Write-Output`.
- **Logging:** it uses only `Write-CiLog`, `Start-LogGroup`, `Stop-LogGroup` and `Invoke-Logged`. These keep stdout clean for `-Json`.
- **Failure codes:** `Stop-GodotCi` is used only for a bad call, with the stable code `invalid-arguments`. That code is already in the contract, so nothing new goes in `docs/json.md`.
- **Failing tests:** they are a result, not an error. The caller reads `Ok`. A timeout comes back as `Code` 124 from `Invoke-Logged`.
- **Empty or single results:** `$errors` is wrapped in `@(...)`, so `.Count` works under strict mode with zero or one lines.
- **Naming:** the name is Verb-Noun, so it avoids the built-in alias clashes. I haven't run `Test-LibNames.ps1` to confirm the name is unique across `ci/godot`.
