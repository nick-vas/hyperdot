**Organization:** `examples/gdscript/test/` holds one GUT suite, `test_score.gd`. It has a `.uid` sidecar and a `flows/startup.flow.json` file for the separate `flows` runner. `project.godot` has no GUT-specific entries (no matches for "gut", "enabled" or "autoload").

**Naming:** The suite is named `test_<topic>.gd` and starts with `extends GutTest`. Its test functions are `test_<behavior>`, for example `test_miss_resets_combo`, `test_every_fifth_hit_raises_the_multiplier` and `test_main_scene_scores_on_ready`.

**Discovery:**
- `Detect.ps1` selects the `gut` runner when `Get-GutTestFiles` finds any project `*.gd` file with a line matching `^extends\s+GutTest`.
- It uses `Find-ProjectFiles`, which skips folders containing a `.gdignore`.
- File names and folder don't matter for detection.

**Running:**
- The `gut` case in `Runners.ps1` first requires `addons/gut/gut_cmdln.gd`. If it's missing, it stops with "gut runner: addons/gut is missing".
- It then runs Godot with `--headless --path <project> -s addons/gut/gut_cmdln.gd -gexit -gdisable_colors -gjunit_xml_file=<ResultsDir>/gut.junit.xml`.
- If `.gutconfig.json` exists, GUT uses it. Otherwise the kit adds a `-gdir=res://…` argument for each folder holding a GutTest script.
- `-Filter` becomes `-gunit_test_name=<name>`.
- Output goes to `gut.log`, and the JUnit XML feeds the kit's report.
