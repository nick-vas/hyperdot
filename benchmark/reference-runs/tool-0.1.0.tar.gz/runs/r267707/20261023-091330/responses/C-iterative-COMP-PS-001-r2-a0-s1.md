`test` runs three steps in order: `Invoke-Setup`, `Invoke-Build`, then `Invoke-Tests` (`hyperdot.ps1:575`). I read the five files and did not run anything.

**Entry and detection**
- `hyperdot.ps1` dot-sources every `lib/*.ps1`. Under `-Json` it turns on JSON mode, so logs go to stderr.
- `Get-ProjectInfo` (`Detect.ps1:116`) finds `project.godot`, the `.sln`/`.csproj`, the Godot version and whether the project is C#.
- Runners come from `-Runners`, or are auto-detected. `validate` and `architecture` always run. The rest are added by markers in the project:
  - `dotnet`: a test SDK or gdUnit4 adapter in a csproj.
  - `godottest`: a GoDotTest reference.
  - `gut`: GUT test files.
  - `flows`: `*.flow.json` files.
  - `smoke`: a main scene.
  - `juice`, `playthrough`, `data`, `textsize` and `layout`: a `<name>.json` file.
  - `l10n`: translation sources.
- `gdunit4` is never auto-detected; you have to name it in `-Runners`.

**Setup and build**
- `Invoke-Setup` uses `GODOT_BIN` or installs Godot.
- `Invoke-Build` installs GUT if needed and runs `dotnet build`. It then runs `godot --headless --import`, retrying crashes.

**Per-runner invocation** (`Invoke-TestRunner`, `Runners.ps1:90`)
- `dotnet` and `gdunit4` use `dotnet test`.
- `godottest` runs `godot --headless --run-tests --quit-on-finish`.
- `gut` runs `godot --headless -s addons/gut/gut_cmdln.gd -gexit`.
- `validate` and `flows` run `godot --headless -s tools/*.gd`.
- `smoke` runs `godot --headless --quit-after <Frames>`.
- The others call helper runners.
- `-Retry` and `quarantine.json` wrap each runner.

**Files produced**
- `test-results/hyperdot.log`
- `test-results/<runner>/` with per-runner logs and `*.junit.xml`, plus `findings.json` and coverage in some runs
- `summary.json` and `summary.md` (`Write-RunSummary`, `Report.ps1:255`)
- `coverage/index.html`, when coverage is on
- `.godot/hyperdot-history.jsonl`

`-Json` adds `runnerResults`, `failureDelta` and `resultsDir`. A failing runner stops the run with `tests-failed`.
