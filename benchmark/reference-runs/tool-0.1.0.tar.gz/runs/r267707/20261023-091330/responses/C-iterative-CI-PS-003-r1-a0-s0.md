Files to read and plan:

- `AGENTS.md`: I have it from the system reminder. I'll re-read its "Working here" and "Self-tests" sections to confirm the rules for skills, docs and `lib` changes.
- `.github/workflows/self-test.yml`: I'll read the full file. I want to see which scripts it runs, what each step needs (Godot, display, ffmpeg), and whether any steps run on every change.
- `tests/Test-LibNames.ps1`, `tests/Test-DocLinks.ps1` and `tests/Test-Context.ps1`: I'll check what they cover. The goal is to confirm that a `lib` change, a docs change and a skill change each have a matching check.
- `ci/godot/tools/Test-Skills.ps1` and `tests/Test-SkillFixtures.ps1`: I'll confirm these are the skill checks.
- Plan: write if/then rules grouped as lib file, skill and docs page. For each rule I'll name the script, then add the always-run example checks (`test` and `doctor` on both examples). I'll keep the answer to 240 words or fewer.
