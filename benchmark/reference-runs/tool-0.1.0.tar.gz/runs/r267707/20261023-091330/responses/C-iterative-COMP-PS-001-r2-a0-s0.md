Files I will read:
- `ci/godot/hyperdot.ps1` (entry script and `test` dispatch)
- `ci/godot/lib/Detect.ps1` (project and runner detection)
- `ci/godot/lib/Runners.ps1` (per-runner Godot/dotnet invocation)
- `ci/godot/lib/Report.ps1` (report and output files)
- `docs/json.md` (the `-Json` contract and error codes)

Plan:
- Read `hyperdot.ps1` to see how `test` is parsed and dispatched, and which setup steps (Godot lookup, import) run first.
- Read `Detect.ps1` to see how the project root and runners are found (GUT, gdUnit4, GoDotTest, dotnet).
- Read `Runners.ps1` to see how Godot or dotnet is launched for each runner and how results are collected.
- Read `Report.ps1` and `docs/json.md` to find the files a run writes (reports, history, JSON fields).
- Then write the explanation in 240 words or fewer.
