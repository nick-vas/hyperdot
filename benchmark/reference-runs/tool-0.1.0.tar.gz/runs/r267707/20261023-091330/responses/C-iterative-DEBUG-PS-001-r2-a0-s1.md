Five likely causes of a hanging test run, each with a mitigation. I read the guards in `Common.ps1`, `Runners.ps1` and `self-test.yml` through grep matches only, not the full files.

1. **Godot stalls or never exits** (import, a test scene, a stuck child). Mitigation: set `HYPERDOT_TIMEOUT`. `Get-ProcessTimeout` in `Common.ps1:173` defaults to 1800 s. The runner kills the whole process tree with `Kill($true)` and returns 124. `Test-ProcessTimeout.ps1` covers this.

2. **A crashed import or export that is repeated.** A crash can loop or stall. Mitigation: the repeat is capped at 2 retries (`Common.ps1:253`, "retry N of 2"), and each attempt still has the time limit. `Test-CrashRetry.ps1` covers it.

3. **Missing display for `bench`, `shot` or `audio -Mix`.** Rendering can block when no display exists. Mitigation: start `Xvfb :99 &` and set `DISPLAY=:99`, as `self-test.yml:368-373` does. Don't use `xvfb-run`, which merges stderr into stdout and breaks `-Json`.

4. **Test-framework stalls: a gdUnit4Net project rebuild or a hung test session.** Mitigation: the generated runsettings in `Runners.ps1` set `TestSessionTimeout` to 1800000 ms (line 35) and `CompileProcessTimeout` to 180000 ms (line 44).

5. **Flaky tests that make `-Retry` multiply the run time.** Mitigation: `Invoke-TestRunnerWithRetry` (`Runners.ps1:236`) reruns the whole runner up to `-Retry` more times. Keep `-Retry` low and list known flaky tests in `quarantine.json`. At the workflow level, every job has `timeout-minutes: 45`, which stops a run that gets past the per-process limits.

One caveat: the process limit is per process, so a run with several long steps can exceed 30 minutes in total. The 45-minute job limit is the only guard against that.
