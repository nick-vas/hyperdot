Here are the rules, drawn from AGENTS.md and the steps in `.github/workflows/self-test.yml`. CI runs every script on every push, so these rules decide what to run locally first.

**If you change a file under `ci/godot/lib/`:**
- Always run `pwsh tests/Test-LibNames.ps1`. It catches duplicate function names and names that clash with built-in aliases.
- Run the self-test whose "Covers" entry matches the concern you touched. For example, `Plan.ps1` maps to `Test-Plan.ps1`, `Audio.ps1` to `Test-Audio.ps1`, and `Store.ps1` to `Test-Store.ps1`.
- Run `Test-Context.ps1` as well if you changed flag names. It holds the template, skills and docs to the kit's real flags.
- Run `pwsh ci/godot/hyperdot.ps1 test -Project examples/csharp/game`, then the same with `-Project examples/gdscript`. Also run `doctor` on both. All four must be green.
- If you touched `plan`, copy `examples/gdscript` to a temporary folder and run `git init` there. Then run `plan -Do init -Project <copy>`, followed by `plan -Json -Project <copy>`. Expect phase `concept` and at least one next action.
- If the test needs Godot, install it. If it needs a display, run `Xvfb :99 &` and set `DISPLAY=:99`. Don't use `xvfb-run`.
- If you added an error code, add it to `docs/json.md`.

**If you change a skill under `.agents/skills/`:**
- Run `pwsh ci/godot/tools/Test-Skills.ps1` and `pwsh tests/Test-SkillFixtures.ps1`.
- Run `Test-DocLinks.ps1` and `Test-Context.ps1`.
- If the skill quotes a shader, run `Test-SkillShaders.ps1`.
- Check every quoted command, flag, error code and version against the real script, `docs/json.md` and `examples/csharp`.
- Keep the description to when to use the skill, never how.

**If you change a page under `docs/`:**
- Run `pwsh tests/Test-DocLinks.ps1`.
- Run `Test-Context.ps1` if the page names kit flags or files.
- If you change `docs/json.md`, check it against the error codes in the code.

CI also runs PSScriptAnalyzer, which I can't run here, so run it yourself if you can.
