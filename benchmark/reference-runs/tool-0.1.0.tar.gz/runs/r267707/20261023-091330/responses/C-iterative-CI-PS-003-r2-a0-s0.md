Files I will read and my plan:

- `AGENTS.md`: I've already got it in context. I'll re-check the "Working here" rules and the Self-tests table for what each script covers and needs.
- `.github/workflows/self-test.yml`: I'll read it to see which steps run which scripts, and how skills, docs and lib changes map to them.
- Plan: I'll read `self-test.yml` first (it's the only file I haven't seen). Then I'll map the three change types to scripts:
  - `ci/godot/lib` changes: `Test-LibNames.ps1`, plus the self-test for the concern changed.
  - Skills: `Test-Skills.ps1` and `Test-SkillFixtures.ps1`.
  - `docs/`: `Test-DocLinks.ps1`.
- I'll note the prerequisites: Godot, a display (Xvfb :99, not xvfb-run), ffmpeg, and `-NoGodot` where it exists.
- I'll also include the example checks: `test` and `doctor` on both examples, plus the `plan` check.
- Then I'll write the if/then rules in 240 words or fewer.
