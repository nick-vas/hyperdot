**Entry.** `ci/godot/hyperdot.ps1` defaults `-Command` to `test`. It dot-sources `lib/*.ps1`, asserts the results folder is safe to clear (`Assert-SafeToClear`), and runs `Invoke-Setup; Invoke-Build; Invoke-Tests` (`:575`). Setup downloads or finds Godot and sets `GODOT_BIN`.

**Detection.** `Detect.ps1`'s `Get-ProjectInfo` uses `Find-GodotProject` and `Find-Solution` to locate the project, and `Find-GoDotTestScene` and `Get-GutTestFiles` to find test frameworks. It yields `$info.Runners`. If that list is empty, the run is build-only.

**Invoking runners.** `Invoke-Tests` reads `quarantine.json` (a broken file stops the run with `invalid-quarantine`), clears the results folder, then calls `Invoke-TestRunnerWithRetry` per runner. That wraps `Invoke-TestRunner` in `Runners.ps1`, which switches on the runner:
- `dotnet` and `gdunit4` run `dotnet test` with a settings file.
- `godottest` runs `godot --headless --path P [scene] --run-tests --quit-on-finish`. With coverage it runs under coverlet.
- `gut` runs `godot --headless -s addons/gut/gut_cmdln.gd -gexit` with a JUnit output path.
- `validate` and `flows` run `tools/validate.gd` and `tools/flows.gd` with `-s`.
- `smoke` runs `--quit-after <frames>`.
- Other runners are juice, playthrough, architecture, l10n, data, layout and textsize.

**Outputs.** Each runner writes to `<Results>/<runner>/`: logs such as `gut.log` and `godottest.log`, `*.junit.xml` or `.trx`, and coverage `*.cobertura.xml`. Retries are kept as `<runner>.attempt<N>`. `Report.ps1` parses these (`Read-JUnit`, `Read-Trx`) and writes `summary.json` and `summary.md`. It also appends to `.godot/hyperdot-history.jsonl`, which feeds the failure delta.

**Result.** With `-Json`, `Set-JsonField` adds `resultsDir`, `coverage`, `failureDelta`, `flaky`, `quarantined` and `runnerResults`. Failures raise `tests-failed`, `no-coverage` or `coverage-below-minimum`.

I did not read `docs/json.md`. The field names and error codes above come from the code.
