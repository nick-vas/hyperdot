Five likely causes of flaky GDScript tests in this kit's CI, each with a mitigation. I read `flows.gd`, the file list for `examples/gdscript/test`, and `self-test.yml`. I did not open `test_score.gd`, so none of these is tied to its contents.

1. **Frame-timing races.** `flows.gd` uses fixed `wait N` steps on `physics_frame`, so a slow runner can reach an `assert` before the game has settled.
   *Mitigation:* use `wait_until` with a `timeout` instead of `wait`. It polls up to `FRAME_LIMIT` (3600) frames.

2. **Unseeded randomness.** A GUT test that uses `randi()` without a seed gives different results on each run. Flows call `seed()` per flow, but GUT tests don't.
   *Mitigation:* call `seed(...)` in `before_each`, or set `"seed"` in the `.flow.json`.

3. **Leaked state between tests.** Autoloads, `Input` actions and `root.size` carry over from one test to the next. `flows.gd` resets size and releases actions, but GUT tests don't.
   *Mitigation:* free scenes with `autofree()` and `queue_free` plus one frame wait, and release actions in `after_each`.

4. **Display and resolution differences.** Headless Godot opens a 64×64 window, while Xvfb is 1920×1080. Layout-dependent tests pass or fail depending on which one runs them. Start Xvfb directly, not with `xvfb-run`, which merges stderr into stdout.
   *Mitigation:* have the test set `root.size` explicitly, as `flows.gd` does with `_project_size()`.

5. **Startup and import races.** Reading scene state before the first frame, or running before the import finishes, fails intermittently. The kit documents `await process_frame` after `add_child`, and crashed imports get repeated.
   *Mitigation:* `await process_frame` after `add_child`, and run `validate` before `test`. For a test that still flakes, run `test -Retry`, which reports tests that only passed on a retry, and add that test to `quarantine.json` with an expiry date.
