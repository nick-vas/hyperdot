Plan (not answering yet):

- List `examples/gdscript/test` (Glob) to see the file layout and naming of the test scripts.
- Read `examples/gdscript/project.godot` for GUT/addon settings, autoloads and test config.
- Grep `ci/godot/lib/Detect.ps1` for how GDScript/GUT projects and test directories are detected.
- Grep `ci/godot/lib/Runners.ps1` for the GUT runner: command line, prefix/suffix, directories, retries, result parsing.
- Combine the findings into an answer of 200 words or fewer.
