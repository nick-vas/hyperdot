Five likely causes of flaky GDScript tests in this kit's CI, each with a mitigation. I read `test_score.gd`, `startup.flow.json`, `flows.gd` and the Xvfb and retry lines in `self-test.yml`. I did not read the rest of `self-test.yml`.

1. **Reading scene state before it is ready.** `test_main_scene_scores_on_ready` asserts `main.score.points` right after `add_child_autofree`, with no frame wait. `AGENTS.md` says a scene's `_ready` state isn't safe to read until the first frame.
   *Mitigation:* add `await wait_frames(1)` before the assertion, or use `wait_until`.

2. **Fixed frame counts.** `startup.flow.json` uses `{ "wait": 2 }`. That is 2 physics frames, and a slow runner may not have finished by then.
   *Mitigation:* replace it with `wait_until` and a `timeout`.

3. **Unseeded randomness.** `flows.gd` calls `seed()` from the flow's `"seed"` field. GUT tests don't. If `Score` or `main.tscn` ever uses `randi()`, results will vary between runs.
   *Mitigation:* call `seed(1)` in `before_each`.

4. **State leaking between tests or flows.** `Input` actions and `root.size` carry over between tests. `flows.gd` resets them, but GUT tests don't.
   *Mitigation:* use `autofree` or `add_child_autofree` for every node, and release actions in `after_each`.

5. **Display and window differences.** Headless Godot opens a 64×64 window, while the Xvfb in `self-test.yml` is 1920×1080. Layout-dependent assertions can pass in one and fail in the other.
   *Mitigation:* set `root.size` explicitly, as `flows.gd` does with `_project_size()`. For a test that still flakes, run `test -Retry`, which reports tests that only passed on a retry, and add that test to `quarantine.json` with an expiry date.
