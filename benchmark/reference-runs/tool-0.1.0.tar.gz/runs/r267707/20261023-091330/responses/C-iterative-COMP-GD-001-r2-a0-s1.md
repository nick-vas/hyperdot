**Organization and naming:** `examples/gdscript/test/` holds one GUT suite, `test_score.gd`. It starts with `extends GutTest` and has `func test_*` methods: `test_every_fifth_hit_raises_the_multiplier`, `test_miss_resets_combo` and `test_main_scene_scores_on_ready`. A separate `test/flows/startup.flow.json` is a flow definition for the `flows` runner, not a GUT test. The `.gd.uid` file is Godot's generated metadata.

`project.godot` has no GUT, test or autoload entries, so it doesn't affect discovery.

**Discovery:** `Get-GutTestFiles` in `Detect.ps1:56` scans the project's `.gd` files, skipping folders that have a `.gdignore`. It keeps any file with a line matching `^extends\s+GutTest`. If at least one such file exists, `gut` is added to the selected runners (`Detect.ps1:141`). The filename doesn't matter to the kit, though `Runners.ps1`'s header comment mentions `test_*.gd`.

**Execution:** In `Runners.ps1:135`, the `gut` runner stops with an error if `addons/gut/gut_cmdln.gd` is missing. Otherwise it runs Godot with `--headless --path <project> -s addons/gut/gut_cmdln.gd -gexit -gdisable_colors` and `-gjunit_xml_file=<ResultsDir>/gut.junit.xml`.

- If `.gutconfig.json` exists, GUT uses that config.
- If not, the kit adds one `-gdir=res://…` for each folder that contains a GutTest script.
- `-Filter` becomes `-gunit_test_name=<name>`.
- Output goes to `gut.log`, and results are reported from the JUnit XML.
