`test` in `ci/godot/hyperdot.ps1` is the default `-Command`. I read `Runners.ps1`, `Report.ps1`, `Detect.ps1`'s function list and the `test` dispatch in `hyperdot.ps1`. I did not read `Detect.ps1`'s bodies or `docs/json.md`, so how runners are chosen is inferred.

**Flow**
- The script first calls `Assert-SafeToClear` on the results folder. It builds `$info` with `Get-ProjectInfo` from `Detect.ps1`. That function relies on helpers such as `Find-GodotProject`, `Find-Solution`, `Find-GoDotTestScene` and `Get-GutTestFiles`. `$info` holds the project directory, the solution, the GoDotTest scene and `Runners`.
- The `test` branch runs `Invoke-Setup; Invoke-Build; Invoke-Tests`. `Invoke-Build` runs `dotnet build` for C# projects, then `godot --headless --import`, which is retried if Godot crashes.
- `Invoke-Tests` reads `quarantine.json` and clears the results folder, keeping only `hyperdot.log`. It then calls `Invoke-TestRunnerWithRetry` once per runner, which wraps `Invoke-TestRunner`.

**How each runner runs**
- `dotnet` and `gdunit4` call `dotnet test` with a settings file and a results directory. `gdunit4` first checks that the csproj references `gdUnit4.test.adapter`.
- `godottest` runs Godot with `--headless --path … --run-tests --quit-on-finish`, wrapped in coverlet when coverage is on.
- `gut` runs `-s addons/gut/gut_cmdln.gd -gexit` and writes a JUnit file.
- `validate` and `flows` run `tools/validate.gd` and `tools/flows.gd` with `-s`.
- `smoke` runs `--quit-after <Frames>` and scans the log for errors.
- `juice`, `playthrough`, `architecture`, `l10n`, `data`, `layout` and `textsize` run through their own `lib/*.ps1` runners.

**Outputs**
- Per runner, under `<Results>/<runner>/`, there is a log, JUnit or TRX XML, and sometimes `findings.json`, `glyphs.json` or cobertura coverage.
- At the top level there are `summary.json` and `summary.md`, written by `Write-RunSummary`.
- `Set-TestRunHistory` appends to `.godot/hyperdot-history.jsonl`. `Get-FailureDelta` compares against that history.
- With `-Json`, the result has `resultsDir`, `runnerResults`, `failureDelta`, `flaky` and `quarantined`.
- A failed runner stops the run with the code `tests-failed`.
