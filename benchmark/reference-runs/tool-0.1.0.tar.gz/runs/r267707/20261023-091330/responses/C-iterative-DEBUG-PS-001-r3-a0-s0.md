Files I will read:
- `ci/godot/lib/Common.ps1` (process launching, time limits, `Stop-GodotCi`)
- `ci/godot/lib/Runners.ps1` (test runners, retry, crash handling)
- `AGENTS.md` (already in context: display/Xvfb notes, self-test table)
- `.github/workflows/self-test.yml` (job and step timeouts)

Plan:
- Grep Common.ps1 for the process time limit, kill logic, and download handling.
- Grep Runners.ps1 for timeouts, `-Retry`, and the gdUnit4 "tests found but not run" guard.
- Check self-test.yml for `timeout-minutes` and Xvfb setup.
- Match each of five hang causes (Godot waiting on a display, a runaway or orphaned child process, a stalled download, a flaky test that never ends, a CI job without a timeout) to the guard that exists.
- Write the answer in 260 words or fewer, with one mitigation per cause.

I haven't answered yet, as you asked.
