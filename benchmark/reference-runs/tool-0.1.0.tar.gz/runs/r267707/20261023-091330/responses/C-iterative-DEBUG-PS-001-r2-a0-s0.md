Files I will read:
- `ci/godot/lib/Common.ps1`: process launching and the time limit.
- `ci/godot/lib/Runners.ps1`: the test runners (GUT, dotnet, gdUnit4, GoDotTest) and retry or crash handling.
- `AGENTS.md`: already in context. It covers the display requirement (Xvfb) and the self-test table.
- `.github/workflows/self-test.yml`: job and step timeouts, and how the display is started.

Plan:
- Grep Common.ps1 and Runners.ps1 for `timeout`, `WaitForExit`, `Start-Process`, `Kill`, and `Retry` to find the existing guards.
- Read the process-running helper to see how it handles stdout and stderr pipes, the time limit, and killing the process tree.
- Check Runners.ps1 for the places a run could stall: a missing display, the Godot import step, a GUT or dotnet child that never exits, and the retry or crash repeat.
- Check self-test.yml for `timeout-minutes` and the Xvfb setup, and match each against the tests named in AGENTS.md (`Test-ProcessTimeout.ps1`, `Test-CrashRetry.ps1`).
- Pick five causes, each with one mitigation and the setting or code that already guards it. Write the answer in 260 words or fewer.
