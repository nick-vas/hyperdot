```diff
--- a/ci/godot/hyperdot.ps1
+++ b/ci/godot/hyperdot.ps1
@@ -73,5 +73,6 @@
     [string]$Results = 'test-results',
     [string]$Output = 'build',
     # Frames the smoke runner plays, launched exports play, and shot waits before each screenshot.
+    [ValidateRange(1, 1000000)]
     [int]$Frames = 120,
```

Why `-Frames` needs it: it is passed straight to Godot's `--quit-after` (`ci/godot/lib/Runners.ps1:195`), where 0 means never quit, so `-Frames 0` hangs the smoke run. Negative values are meaningless. The upper bound only stops absurd values. The default of 120 is unchanged. I haven't run the self-tests or the examples against this change.
