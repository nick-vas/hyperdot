```powershell
# Runs one program as a test runner and returns its verdict. A failing test is a result (Ok = $false), not an error:
# the caller decides what a failure means. Only a bad call stops the run.
function Invoke-ProgramTestRunner {
    param([string]$Runner, [string]$FilePath, [string[]]$ArgumentList = @(), [string]$ResultsDir)

    if (-not $Runner -or -not $FilePath) {
        Stop-GodotCi 'Invoke-ProgramTestRunner needs -Runner and -FilePath' 'invalid-arguments'
    }
    if (Test-Path -LiteralPath $ResultsDir) { Remove-Item -Recurse -Force $ResultsDir }
    New-Item -ItemType Directory -Force $ResultsDir | Out-Null
    $log = Join-Path $ResultsDir "$Runner.log"

    Start-LogGroup $Runner
    $clock = [System.Diagnostics.Stopwatch]::StartNew()
    $code = Invoke-Logged $FilePath $ArgumentList $log
    Stop-LogGroup

    # Godot often exits 0 after printing errors, so the log is scanned too.
    $errors = @(Get-GodotLogErrors $log)
    if ($code -eq 0 -and $errors.Count -gt 0) { $code = 1 }
    if ($code -eq 124) { Write-CiLog "$Runner hit the time limit" }

    return [pscustomobject]@{
        Runner  = $Runner
        Ok      = ($code -eq 0)
        Code    = $code
        Errors  = $errors
        Log     = $log
        Seconds = [math]::Round($clock.Elapsed.TotalSeconds, 1)
    }
}
```

How it follows `AGENTS.md`:
- **Return value:** it returns a single `[pscustomobject]`, and nothing in it uses `Write-Output`. `Invoke-Logged`, `Start-LogGroup` and `Stop-LogGroup` write only to the host or the run log.
- **Logging:** logging goes through `Write-CiLog`, so `-Json` keeps stdout clean.
- **Failure codes:** `Stop-GodotCi` is used only for a bad call, with the stable code `invalid-arguments`. That code is already in `docs/json.md`, so no new code is needed.
- **Failing tests:** they are not an error. The caller reads `Ok`, as the other runners do. A timeout comes back as `Code` 124 from `Invoke-Logged`.
- **Empty or single results:** `$errors` is wrapped in `@(...)`, so `.Count` works under strict mode when there are zero or one lines.
- **Naming:** the name is Verb-Noun, so it avoids the built-in alias clashes. I haven't run `Test-LibNames.ps1` to confirm it's unique across `ci/godot`.

I haven't run the function or any self-test.
