Five likely causes of flaky GDScript tests in this kit's CI, each with a mitigation:

1. **Reading scene state before `_ready` has run.** `test_main_scene_scores_on_ready` (`examples/gdscript/test/test_score.gd:15`) asserts on `main.score.points` right after `add_child_autofree`. AGENTS.md says a scene's setup isn't visible until the first frame.
   *Mitigation:* add `await wait_frames(1)` (or `await get_tree().process_frame`) before the assert.

2. **Unseeded randomness.** `flows.gd:68` calls `seed(...)` so flows are repeatable, but GUT tests don't get that.
   *Mitigation:* call `seed(0)` in `before_each`, or give the flow a fixed `"seed"` in `startup.flow.json`.

3. **Timing by frames or wall-clock.** `flows.gd` counts `physics_frame` for `wait` and `hold`. Software rendering under Xvfb on a loaded runner can stretch frame times, so any `create_timer`-based wait becomes fragile.
   *Mitigation:* use frame counts, or `wait_until` with a bounded condition, not real-time sleeps.

4. **Leaked input and window state between tests.** Held actions and resizes carry over. Headless Godot opens at 64×64, and `flows.gd` resets the size and releases held actions for this reason.
   *Mitigation:* release actions and restore the window size in `after_each`, as `flows.gd:88-95` does.

5. **Display and environment variance on the runner.** The workflow starts Xvfb directly, and `timeout-minutes: 45` is the only guard. Godot downloads and crashed imports or exports can also fail intermittently.
   *Mitigation:* run `hyperdot.ps1 test -Retry`, which flags tests that passed only on a retry. For known flakes, list them in `quarantine.json` with an expiry date. Cover both with `tests/Test-Flaky.ps1`.

I read the test, `flows.gd` and the workflow, but only searched the workflow for the Xvfb, retry and timeout lines. I did not read it in full.
