Five likely causes of flaky GDScript tests in this kit's CI, each with a mitigation. I read `flows.gd`, the test folder and `self-test.yml`. I did not open `ci/godot/lib/Runners.ps1`, and I did not run anything.

1. **Unseeded randomness.** `flows.gd:68` seeds from the flow's `seed` field, defaulting to 0. GUT tests that call `randi()` or `randf()` directly (nothing in `test_score.gd` does today) get no such seed. *Mitigation:* call `seed(n)` in `before_each`, or pass `--seed=N` through `-GameArgs`, as `self-test.yml:469` does.

2. **Frame-timing races.** A test that reads node state right after `add_child` runs before `_ready` has taken effect. `AGENTS.md` flags this, and `flows.gd` works around it with `await process_frame` (lines 25, 75, 95). *Mitigation:* in each test, `await get_tree().process_frame` after `add_child`, or `await physics_frame` for physics-driven checks. Never use `OS.delay_msec` or wall-clock sleeps.

3. **Leaked state between tests.** Autoloads, static variables and orphan nodes persist across test methods. *Mitigation:* reset autoloads in `before_each`, free scenes with `add_child_autofree`, and run the suite in a clean project copy.

4. **Display and GPU differences.** `bench`, `shot` and `audio -Mix` need a display. Without one they differ from a desktop run, and Firefox even reports WebGL 2 missing under headless (`self-test.yml:486`). *Mitigation:* start `Xvfb :99` directly and set `DISPLAY=:99` (`self-test.yml:370-373`). `xvfb-run` merges stderr into stdout and breaks `-Json`.

5. **Slow or contended runners.** Hard-coded wait times and tight timeouts fail when a shared runner is slow. *Mitigation:* count frames instead of seconds. Run `test -Retry` so a pass on retry is reported as flaky rather than hidden. Put a known flaky test in `quarantine.json` with an expiry date (see the `self-test.yml:294` step).
