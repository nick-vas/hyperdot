Files I will read:
- `AGENTS.md` (already in context; conventions)
- `ci/godot/lib/Common.ps1` (`Stop-GodotCi`, `Write-CiLog`, `Set-JsonField`, process helpers)
- `ci/godot/lib/Runners.ps1` (existing runner signatures and result shape)

Plan:
- Read Common.ps1 to confirm the real helper names and signatures: how `Stop-GodotCi` takes a message and a stable code, and how logs reach stderr under `-Json`.
- Read Runners.ps1 to copy the existing runner's parameters, return shape (object or hashtable) and naming, so the new function matches.
- Write one Verb-Noun function. It will use `@(...)` around results and `foreach` for iteration. It will have no `Write-Output`, and it will log with `Write-CiLog` or `Write-Host`.
- On a missing runner or executable, fail with `Stop-GodotCi "message" 'stable-code'`. If I add a new code, I will note that it belongs in `docs/json.md`.
- Return only the code, in at most 320 words, with the result as a single `[pscustomobject]` as the last pipeline value.
