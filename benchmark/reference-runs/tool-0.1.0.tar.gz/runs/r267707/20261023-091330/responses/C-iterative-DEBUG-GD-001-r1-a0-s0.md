Files I will read:
- `AGENTS.md` (already in context; I'll re-check the display, Xvfb and self-test notes)
- `examples/gdscript/test/*` (the GUT tests: timing, await, randomness, shared state)
- `ci/godot/tools/flows.gd` (frame waits, input steps, `await process_frame` handling)
- `.github/workflows/self-test.yml` (runner setup, Xvfb, retries, Godot version matrix)
- `ci/godot/lib/Runners.ps1` and the `quarantine.json` handling, only if needed to tailor the `-Retry` mitigation

Plan:
- Read the test folder and `flows.gd` to find real timing, ordering and global-state hazards.
- Read the workflow to see how the display, Godot version and `test -Retry` are configured on Linux runners.
- Choose five distinct causes (frame and timing races, unseeded RNG, shared autoload or scene state, headless or display differences, slow CI runners and timeouts), each tied to a file I found.
- Pair each cause with one mitigation that uses the kit's own features (`test -Retry`, `quarantine.json`, `flows.gd` steps, Xvfb on `:99`).
- Write the answer in 260 words or fewer.
