Plan (no answer yet):

- Glob `examples/gdscript/test/**` to see the folder layout and file names.
- Read `examples/gdscript/project.godot` for GUT config, autoloads and any test-related settings.
- Grep `ci/godot/lib/Detect.ps1` for how GUT is detected (addon folder, `.gutconfig.json`, test dirs).
- Grep and read the GUT section of `ci/godot/lib/Runners.ps1`: command line, prefix and suffix, directories, retries and result parsing.
- Combine the layout, naming and discovery findings with the runner behavior into an answer of 200 words or fewer.
