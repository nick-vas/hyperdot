Files I will read:
- `ci/godot/lib/Common.ps1` (process launching, time limits, `Stop-GodotCi`)
- `ci/godot/lib/Runners.ps1` (test runners, retry, crash handling)
- `AGENTS.md` (already in context; the Xvfb and display notes)
- `.github/workflows/self-test.yml` (job and step timeouts)

Plan:
- Grep Common.ps1 for the process timeout, kill and wait logic.
- Grep Runners.ps1 for runner invocations, `-Retry`, and the guard against tests found but not run.
- Check self-test.yml for `timeout-minutes` and the display setup.
- Match each cause I find to the setting or code that guards it, or note that none exists.
- Write the five causes, each with one mitigation, in 260 words or fewer.
