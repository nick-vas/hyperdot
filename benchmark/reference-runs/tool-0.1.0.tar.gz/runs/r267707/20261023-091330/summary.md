# Token benchmark 20261023-091330

Model claude-sonnet-5-5, 3 run(s) per task and profile, 48 session(s), CLI 2.1.309 (Claude Code), without the plugin.
Tokens include cache reads and writes; cost is Claude Code's own figure. Medians leave out sessions stopped at the time limit, whose spend is unknown (the "Unknown" column).

| Profile | Runs | Success % | Median tokens | P90 tokens | Median output | Median turns | Median cost | Total cost | Successes per $ | Median time (s) | Retries | Unknown |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| C-iterative | 24 | 58.3 | 82,509 | 108,812 | 1,618 | 5 | $0.1116 | $2.7402 | 5.11 | 18.2 | 0 | 0 |

| Task | Profile | Successes | Median tokens | Median cost | Failures |
|---|---|---:|---:|---:|---|
| COMP-PS-001 | C-iterative | 1/3 | 98,995 | $0.1691 | 282 words, limit 240 / 264 words, limit 240 |
| COMP-GD-001 | C-iterative | 3/3 | 83,862 | $0.0516 |  |
| CODE-PS-001 | C-iterative | 3/3 | 81,628 | $0.1909 |  |
| CODE-PS-002 | C-iterative | 3/3 | 87,959 | $0.1056 |  |
| DEBUG-PS-001 | C-iterative | 2/3 | 63,073 | $0.0533 | 270 words, limit 260 |
| DEBUG-GD-001 | C-iterative | 1/3 | 84,137 | $0.1041 | 265 words, limit 260 / missing 'process_frame' |
| CI-PS-001 | C-iterative | 1/3 | 67,017 | $0.0639 | 261 words, limit 220 / 276 words, limit 220 |
| CI-PS-003 | C-iterative | 0/3 | 78,605 | $0.1787 | 288 words, limit 240 / 277 words, limit 240 / 256 words, limit 240 |
