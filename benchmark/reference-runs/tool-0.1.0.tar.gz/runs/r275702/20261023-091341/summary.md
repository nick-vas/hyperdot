# Token benchmark 20261023-091341

Model claude-haiku-5-5, 3 run(s) per task and profile, 24 session(s), CLI 2.1.309 (Claude Code), without the plugin.
Tokens include cache reads and writes; cost is Claude Code's own figure. Medians leave out sessions stopped at the time limit, whose spend is unknown (the "Unknown" column).

| Profile | Runs | Success % | Median tokens | P90 tokens | Median output | Median turns | Median cost | Total cost | Successes per $ | Median time (s) | Retries | Unknown |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| B-scoped | 24 | 75 | 66,606 | 109,581 | 1,986 | 4 | $0.0042 | $0.1305 | 137.91 | 12.0 | 0 | 0 |

| Task | Profile | Successes | Median tokens | Median cost | Failures |
|---|---|---:|---:|---:|---|
| COMP-PS-001 | B-scoped | 2/3 | 109,581 | $0.0150 | 263 words, limit 240 |
| COMP-GD-001 | B-scoped | 3/3 | 67,384 | $0.0021 |  |
| CODE-PS-001 | B-scoped | 2/3 | 66,222 | $0.0060 | missing 'Stop-GodotCi' |
| CODE-PS-002 | B-scoped | 3/3 | 74,631 | $0.0040 |  |
| DEBUG-PS-001 | B-scoped | 3/3 | 44,947 | $0.0024 |  |
| DEBUG-GD-001 | B-scoped | 2/3 | 109,353 | $0.0072 | 266 words, limit 260 |
| CI-PS-001 | B-scoped | 0/3 | 49,637 | $0.0040 | missing 're:\bscop(e/ed)\b' |
| CI-PS-003 | B-scoped | 3/3 | 61,372 | $0.0055 |  |
