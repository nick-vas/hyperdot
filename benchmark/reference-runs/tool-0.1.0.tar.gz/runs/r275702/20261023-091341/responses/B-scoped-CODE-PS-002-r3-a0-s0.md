```diff
@@ -119,3 +119,4 @@
     [string[]]$Sound,
-    [int]$Count = 1,
+    [ValidateRange(1, 1000)]
+    [int]$Count = 1,
     [string]$Seed = '1',
```
