```powershell
function Invoke-SingleTestRunner {
    param(
        [ValidateSet('dotnet', 'gdunit4', 'godottest', 'gut', 'smoke', 'validate', 'architecture', 'juice',
            'playthrough', 'l10n', 'data', 'textsize', 'layout', 'flows')]
        [string]$Runner,
        $Info,
        [string]$ResultsDir,
        [string]$Filter = '',
        [bool]$Coverage = $false,
        [int]$Frames = 0,
        [string[]]$GameArgs = @()
    )

    # Invoke-TestRunner returns Write-TestSummary's object; the Runner name is added so callers can
    # collect several results without losing which runner produced each one.
    $summary = Invoke-TestRunner -Runner $Runner -Info $Info -ResultsDir $ResultsDir -Filter $Filter `
        -Coverage $Coverage -Frames $Frames -GameArgs $GameArgs
    $summary | Add-Member -NotePropertyName Runner -NotePropertyValue $Runner -Force
    return $summary
}
```
