**Always:** run PSScriptAnalyzer over `ci/godot`, `hooks` and `benchmark` (the lint job), and `tests/Test-DocLinks.ps1` if you touched any link or quoted path.

**If a file in `ci/godot/lib/` changes:**
- Run `tests/Test-LibNames.ps1`, since a duplicate or alias-clashing name fails the build.
- Run the self-test for its concern. Doctor: `Test-RepoHygiene`, `Test-Context`, `Test-Addons`. Plan: `Test-Plan`, `Test-TrelloSync`. Runners: `Test-ProcessTimeout`, `Test-CrashRetry`, `Test-FailureDelta`. Audio: `Test-Audio`. Version: `Test-GameVersion`, `Test-UpdatePins`. Web: `Test-Web` (needs Godot templates, Node and a browser).
- Run `hyperdot.ps1 test` and `doctor` on `examples/csharp/game` and `examples/gdscript`.

**If a skill (`.agents/skills/*/SKILL.md`) changes:**
- `ci/godot/tools/Test-Skills.ps1` and `tests/Test-SkillFixtures.ps1` must both pass.
- It quotes a shader: `tests/Test-SkillShaders.ps1` (Godot).
- It quotes a command, flag, error code or version: `tests/Test-Context.ps1`, and check the value against the script, `docs/json.md` and `examples/csharp`.

**If a page under `docs/` changes:**
- `tests/Test-DocLinks.ps1`.
- It names a flag, file, `-Json` field or error code: `tests/Test-Context.ps1`. Codes are API, so never rename one; add new ones to `docs/json.md`.
- It quotes a skill: also `Test-Skills.ps1`.

Any workflow edit also needs `actionlint` (pinned v1.7.12). Self-tests needing a display (Xvfb on `:99`, not `xvfb-run`) or Godot can't run on every machine; say which you could not run.
