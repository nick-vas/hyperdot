**Entry (`hyperdot.ps1`)**: `test` is the default command. The script dot-sources `lib/*.ps1`, then `Get-ProjectInfo` resolves the project, and `Invoke-Setup`, `Invoke-Build`, `Invoke-Tests` run in order.

**Detection (`Detect.ps1`)**: The project is the shallowest `project.godot` under the current folder, or `-Project`. The `.sln` is the nearest one that references the game's `.csproj`. The Godot version comes from `Godot.NET.Sdk` in the csproj, else `GODOT_VERSION`, else 4.7.2. With no `-Runners`, the kit adds `validate` and `architecture`, then `dotnet`, `godottest`, `gut`, `flows`, `smoke`, `juice`, `playthrough`, `l10n`, `data`, `textsize` and `layout` when their files or markers exist.

**Build**: `dotnet build` if there is a solution, then `godot --headless --import`. Retries happen only on crashes.

**Runners (`Runners.ps1`)**: Each runner's results go to `test-results/<runner>/`.
- `dotnet` and `gdunit4`: `dotnet test` with a generated `godot.runsettings`, writing TRX.
- `godottest`: `godot --headless --path P <scene> --run-tests --quit-on-finish`, log converted to JUnit.
- `gut`: `godot ... -s addons/gut/gut_cmdln.gd -gexit`, JUnit XML.
- `validate`, `flows`: `-s tools/*.gd`, log converted to JUnit.
- `smoke`: `--quit-after <frames>`, then log errors checked.

**Verdict (`Report.ps1`)**: Results are parsed into `summary.json`, `summary.md`, and a failure delta against the last run with the same scope. Any failed runner stops with `tests-failed`.

**Files**: `test-results/` (cleared each run except `hyperdot.log`), `<runner>.attemptN/` with `-Retry`, `coverage/`, and `.godot/hyperdot-history.jsonl`. Output contract: `docs/json.md`.
