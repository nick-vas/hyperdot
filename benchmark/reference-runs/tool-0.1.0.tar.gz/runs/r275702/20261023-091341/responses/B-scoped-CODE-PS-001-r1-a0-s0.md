```powershell
# Runs one test runner (the names in the table at the top of Runners.ps1) and returns its summary, with Ok, Code,
# Warnings and so on. An unknown runner or a missing project stops the run; the runner's own failures come back in the result.
function Invoke-OneTestRunner {
    param([Parameter(Mandatory)][string]$Runner, [Parameter(Mandatory)]$Info, [Parameter(Mandatory)][string]$ResultsDir,
        [string]$Filter = '', [bool]$Coverage = $false, [int]$Frames = 0, [string[]]$GameArgs = @(), [int]$FixedFps = 0)

    $known = @('dotnet', 'gdunit4', 'godottest', 'gut', 'validate', 'flows', 'juice', 'playthrough', 'architecture',
        'l10n', 'data', 'layout', 'textsize', 'smoke')
    if ($Runner -notin $known) { Stop-GodotCi "Unknown test runner: $Runner" 'invalid-arguments' }
    if (-not $Info) { Stop-GodotCi "$Runner runner: no project info" }
    return Invoke-TestRunner -Runner $Runner -Info $Info -ResultsDir $ResultsDir -Filter $Filter -Coverage $Coverage `
        -Frames $Frames -GameArgs $GameArgs -FixedFps $FixedFps
}
```
