**Every change**
- Lint: `Invoke-ScriptAnalyzer` over `ci/godot`, `hooks` and `benchmark` (`self-test.yml`, lint job).
- `hyperdot.ps1 test -Project examples/csharp/game` and `-Project examples/gdscript` must be green, and `doctor` green on both.

**If a file under `ci/godot/lib` changes**
- Always: `tests/Test-LibNames.ps1`.
- Then the test for its concern, for example:
  - Localization: `Test-Localization.ps1` (`-NoGodot` for logic)
  - Audio: `Test-Audio.ps1`
  - Palette: `Test-Palette.ps1`
  - Steam, Store, Platforms, Addons: `Test-Steam.ps1`, `Test-Store.ps1`, `Test-Platforms.ps1`, `Test-Addons.ps1`
  - Web: `Test-Web.ps1`
  - Context: `Test-Context.ps1`
  - Setup or Version: `Test-UpdatePins.ps1`, `Test-GameVersion.ps1`
  - Runners: `Test-ProcessTimeout.ps1`, `Test-CrashRetry.ps1`, `Test-FailureDelta.ps1`
- If Plan or Init changes: run the plan check in AGENTS.md (copy, `git init`, `plan -Do init`, `plan -Json`), plus `Test-Plan.ps1`.

**If a skill changes** (`.agents/skills/*/SKILL.md`)
- `ci/godot/tools/Test-Skills.ps1` and `tests/Test-SkillFixtures.ps1`.
- `tests/Test-DocLinks.ps1`.
- `tests/Test-Context.ps1` if it quotes a flag, file, or error code.
- `tests/Test-SkillShaders.ps1` if it quotes a shader (Godot needed).
- `tests/Test-Capture.ps1` for capture mode (Godot and display).

**If a page under `docs/` changes**
- `tests/Test-DocLinks.ps1`.
- `tests/Test-Context.ps1` if it names kit flags or files. Changes to `docs/json.md` also need it.
