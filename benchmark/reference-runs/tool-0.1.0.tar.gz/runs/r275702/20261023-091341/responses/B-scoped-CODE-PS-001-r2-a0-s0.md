```powershell
# Runs one test runner and returns its summary (Write-TestSummary). The runner name is checked first because the switch in
# Invoke-TestRunner silently ignores a name it does not know, which would pass a run that tested nothing.
function Invoke-SingleTestRunner {
    param(
        [Parameter(Mandatory)][string]$Runner,
        [Parameter(Mandatory)]$Info,
        [Parameter(Mandatory)][string]$ResultsDir,
        [string]$Filter = '',
        [bool]$Coverage = $false,
        [int]$Frames = 600,
        [string[]]$GameArgs = @(),
        [int]$FixedFps = 0
    )

    $known = @('dotnet', 'gdunit4', 'godottest', 'gut', 'validate', 'flows', 'juice', 'playthrough',
        'architecture', 'l10n', 'data', 'layout', 'textsize', 'smoke')
    if ($Runner -notin $known) { Stop-GodotCi "Unknown test runner: $Runner" 'invalid-arguments' }

    return Invoke-TestRunner -Runner $Runner -Info $Info -ResultsDir $ResultsDir -Filter $Filter -Coverage $Coverage `
        -Frames $Frames -GameArgs $GameArgs -FixedFps $FixedFps
}
```
