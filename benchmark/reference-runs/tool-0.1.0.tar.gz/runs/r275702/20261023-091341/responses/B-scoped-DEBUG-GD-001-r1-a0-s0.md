1. **Unseeded randomness.** `test_score.gd` has no seed, so a rare roll can change the outcome between runs. `flows.gd` calls `seed()` per flow. *Mitigation:* call `seed(<fixed>)` in each GUT test that uses randomness, or in `before_each`.

2. **Reading state before `_ready`.** `test_main_scene_scores_on_ready` reads `main.score.points` right after `add_child_autofree`. Slower CI runners can expose the gap. *Mitigation:* `await get_tree().process_frame` before asserting, as `flows.gd` does at line 25 and line 75.

3. **Input and window state leaking between tests.** A hold left open, or a resized root window, carries into the next test. `flows.gd` releases every action (lines 89–93) and resets `root.size` (line 70). *Mitigation:* in `after_each`, call `Input.action_release` for each action in `InputMap.get_actions()` and restore `get_window().size`.

4. **Timing-dependent waits.** `wait_until` gives up after a fixed number of frames (default 300). Software rendering on the Linux runners in `self-test.yml` makes frame rates vary. *Mitigation:* raise `timeout` in the `.flow.json` for slow scenes, and prefer waiting on a condition over a fixed frame count. Keep `test -Retry` and `quarantine.json` as a backstop only.

5. **Display differences between machines.** Headless Godot opens a 64×64 window, and the `measure` job needs Xvfb on `:99`. A test that passes on a Windows developer machine can fail on the Linux runner. *Mitigation:* run GDScript tests with `DISPLAY=:99` in the same way as the `measure` job, and set the window size explicitly in the test.
