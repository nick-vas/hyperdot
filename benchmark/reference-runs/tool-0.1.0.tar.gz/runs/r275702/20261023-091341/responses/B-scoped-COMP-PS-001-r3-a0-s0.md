**Entry:** `ci/godot/hyperdot.ps1 test` dot-sources every `lib/*.ps1`, then `Get-ProjectInfo` resolves the project (`Find-GodotProject`: shallowest `project.godot`, or `-Project`) and the solution. It runs `Invoke-Setup`, `Invoke-Build`, then `Invoke-Tests`. `-Results` is checked for safety first (`Assert-SafeToClear`).

**Detection (`Detect.ps1`):** Runners are chosen from project files. A `.csproj` marks C#, `Chickensoft.GoDotTest` selects `godottest`, and `GutTest` scripts select `gut`. `*.flow.json` selects `flows`, and `juice.json`, `playthrough.json`, `data.json`, `textsize.json` and `layout.json` each select their runner. `validate`, `architecture` and `l10n` are always included. `-Runners` overrides this, and unknown names are rejected.

**Build:** `dotnet build` for the solution (C#), then `godot --headless --path <p> --import`. Godot crashes during import are retried; ordinary failures are not.

**Invocation (`Runners.ps1`, `Invoke-TestRunner`):** Each runner gets `test-results/<runner>/` (cleared first), and the Godot binary comes from `$env:GODOT_BIN`.
- `dotnet`/`gdunit4`: `dotnet test` on the solution or `.csproj`. `gdunit4` requires the adapter reference.
- `godottest`: `godot --headless --path … --run-tests[=Filter] --quit-on-finish`. With coverage, coverlet wraps it.
- `gut`: `-s addons/gut/gut_cmdln.gd -gexit -gjunit_xml_file=…`.
- `validate`, `flows`, and the other kit checks: `-s tools/<x>.gd`.
- `smoke`: `--quit-after <frames>`.

**Outputs (`Report.ps1`, `docs/json.md`):**
- Per runner: `*.junit.xml` or `.trx`, `godottest.log`, `findings.json`
- `test-results/coverage/` (Cobertura, plus `index.html` when coverage is collected)
- `test-results/summary.json` and `summary.md`
- `test-results/hyperdot.log`
- `.godot/hyperdot-history.jsonl`, appended with a line per run, used for `failureDelta`

**Exit:** `tests-failed` if any runner fails, `no-coverage` or `coverage-below-minimum` if `-MinCoverage` is unmet. `-Retry` reruns failing runners, and `quarantine.json` excludes tests that have an owner and an end date.
