1. **Godot stalls on an editor dialog, import, or prompt.** Guard: `Get-ProcessTimeout` (`ci/godot/lib/Common.ps1:173`) defaults to 1800 s, and the process is killed with its children and returns 124. Mitigation: keep it non-zero (`HYPERDOT_TIMEOUT=0` disables it) and check `tests/Test-ProcessTimeout.ps1` still passes.

2. **gdUnit4Net compile or rebuild hangs before any test runs.** Guard: `CompileProcessTimeout` at 180000 ms (`ci/godot/lib/Runners.ps1:44`). Mitigation: keep it below the job limit so the failure is reported, not the job being cancelled.

3. **A test waits forever (an await that never resolves, or a server that never answers).** Guard: `TestSessionTimeout` at 1800000 ms (`Runners.ps1:35`), which bounds the whole session. Mitigation: lower it for CI, and give each async test its own bound. The session timeout is the outer limit only.

4. **The CI job itself never ends.** Guard: `timeout-minutes: 45` on the jobs in `.github/workflows/self-test.yml` (lines 17, 249, 365, 478, 501, 512). I did not check `.github/workflows/godot.yml`, so I can't confirm the shipped game workflow sets one. Mitigation: add `timeout-minutes` to every job that runs `test`.

5. **`-Retry` makes a slow run look hung.** Each failed runner is run again, so total time multiplies. Guard: `Invoke-TestRunner` (`Runners.ps1:238`) with `-Retry` and `quarantine.json`, covered by `tests/Test-Flaky.ps1`. Mitigation: cap `-Retry` at 1 or 2 in CI and keep the process timeout in place.

I did not read the stdout/stderr redirection or the `WaitForExit` path in `Common.ps1` (around line 235). A pipe-buffer deadlock there is possible but unchecked.
