**Layout:** `examples/gdscript/test/` holds one GUT suite, `test_score.gd` (`extends GutTest`), plus its `.uid` file and `flows/startup.flow.json`. Each test is a `func test_*()` using `assert_*`. Names describe behaviour (`test_miss_resets_combo`). One test instantiates `res://main.tscn` via `add_child_autofree`.

**Discovery:** `Detect.ps1` (`Get-GutTestFiles`) finds any `.gd` containing `^extends GutTest`, and selects the `gut` runner if one exists. The example has no `.gutconfig.json`.

**Running:** `Runners.ps1` (`gut` case) requires `addons/gut/gut_cmdln.gd`. It runs Godot headless with `-s addons/gut/gut_cmdln.gd -gexit`, adds `-gdir=` for each folder holding a GutTest script, writes `gut.junit.xml` and `gut.log`, and passes `-Filter` as `-gunit_test_name`. The summary is written by `Write-TestSummary`.

**Caveat:** the example has no `addons/gut` folder (the glob found no `gut_cmdln.gd`), so the runner would stop with "addons/gut is missing" unless setup installs GUT first. I didn't check the setup code to confirm.
