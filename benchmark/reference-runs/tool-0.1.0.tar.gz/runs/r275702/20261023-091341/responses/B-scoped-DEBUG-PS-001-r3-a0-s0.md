1. **A Godot process never exits (deadlock, or an `await` that never resumes).** Guard: `Invoke-Logged` in `Common.ps1:184` kills the process tree after `Get-ProcessTimeout` (default 1800 s, `Common.ps1:174`) and returns 124. Mitigation: set `HYPERDOT_TIMEOUT` lower for CI, or fix the test's `await`.

2. **gdUnit4 session stalls.** Guard: `TestSessionTimeout` 1800000 in the runsettings (`Runners.ps1:35`), plus `--quit-on-finish` (`Runners.ps1:116`). Mitigation: keep the session timeout below the process timeout so the runner reports the failure rather than being killed.

3. **GUT never leaves the run loop.** Guard: `-gexit` in the GUT args (`Runners.ps1:139`). Mitigation: confirm every GUT invocation keeps `-gexit`, and add timeouts to tests that await signals.

4. **The C# compile hangs before any test runs.** Guard: `CompileProcessTimeout` 180000 (`Runners.ps1:44`). Mitigation: leave it in place; a rebuild that takes longer than 3 minutes is a failure, not a slow run.

5. **Retries multiply the wait until the CI job is killed.** Guard: `timeout-minutes: 45` on the jobs in `.github/workflows/self-test.yml`. Each `-Retry` attempt (`Runners.ps1:236`) gets its own 1800 s limit, so two attempts that hang already exceed the 45-minute job limit. Mitigation: keep `-Retry` at 0 or 1 in CI, and consider a per-job limit that covers the retries.
