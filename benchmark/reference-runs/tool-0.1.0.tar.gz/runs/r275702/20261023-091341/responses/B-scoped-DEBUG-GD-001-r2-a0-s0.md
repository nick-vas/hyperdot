1. **Unseeded randomness in GUT tests.** `flows.gd` seeds each flow (`seed(flow.seed)`, default 0), but a plain GUT test that calls `randf()` or shuffles arrays gets a different sequence on every run.
   *Mitigation:* call `seed(…)` in `before_each` in `examples/gdscript/test`, or set a fixed `seed` in the flow JSON.

2. **Fixed frame counts instead of conditions.** Frame timing varies with CI load, and `wait N` in a flow or a test that awaits a set number of physics frames can end before the game is ready.
   *Mitigation:* use `wait_until` with an explicit `timeout` (capped at `FRAME_LIMIT` 3600) rather than `wait`, and in GUT use `await` on a signal or a condition loop.

3. **Window and layout state before the first frame.** The headless window starts at 64×64 and the root resizes during its first frame, so a test that reads sizes or anchors right after `add_child` gets stale values.
   *Mitigation:* `await process_frame` after `add_child`, as `flows.gd` does, and set `root.size` explicitly in the test.

4. **Input and node state leaking between tests.** A held action or an unfreed node carries into the next test. `flows.gd` releases every action and awaits a frame after `queue_free()` for this reason.
   *Mitigation:* in `after_each`, call `Input.action_release` for every action in `InputMap.get_actions()`, then `queue_free()` and `await process_frame`.

5. **Retries hide the flake.** Because `test -Retry` re-runs failures, a test that fails on its first attempt passes silently and the cause stays.
   *Mitigation:* read the "passed on a retry" report from `test -Retry` in the `self-test.yml` run, and add the test to `quarantine.json` with an expiry date only while a fix is in progress.
