```diff
--- a/ci/godot/hyperdot.ps1
+++ b/ci/godot/hyperdot.ps1
@@ -119,2 +119,3 @@
     [string[]]$Sound,
+    [ValidateRange(1, 1000)]
     [int]$Count = 1,
```
