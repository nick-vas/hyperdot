**Entry point (`ci/godot/hyperdot.ps1`)**
`test` is the default command. It dot-sources the `lib/*.ps1` files, wraps everything in a `trap` that ends with `unexpected-error`, then runs `Invoke-Setup`, `Invoke-Build` and `Invoke-Tests`. `-Results` is checked by `Assert-SafeToClear`, and the run log and history are started.

**Detection (`lib/Detect.ps1`, `Get-ProjectInfo`)**
- The project is the shallowest `project.godot` under the current folder, or `-Project`.
- A `.csproj` makes it C#, and the nearest `.sln` that references it is the solution.
- Godot version comes from `Godot.NET.Sdk` in the csproj, else `GODOT_VERSION`, else 4.7.2.
- With no `-Runners`, it always selects `validate` and `architecture`. It adds `dotnet`, `godottest`, `gut`, `flows`, `smoke`, `juice`, `playthrough`, `l10n`, `data`, `textsize` and `layout` when it finds the matching markers. `none` means build only.

**Build**
`dotnet build` runs for a solution. Then `Godot --headless --path <p> --import`, retried only on crashes.

**Runners (`lib/Runners.ps1`)**
- `dotnet` and `gdunit4`: `dotnet test` with a generated `godot.runsettings` and a TRX logger.
- `godottest`: `Godot --headless --run-tests --quit-on-finish`, with coverlet when coverage is on.
- `gut`: `Godot -s addons/gut/gut_cmdln.gd -gexit`, writing JUnit.
- `validate`, `flows`, `smoke`: Godot `-s tools/*.gd` or `--quit-after`, with their own JUnit.
- `-Retry` reruns a failed runner whole, keeping `<runner>.attempt<N>`.

**Reporting (`lib/Report.ps1`)**
JUnit and TRX are parsed into totals. A runner with zero tests fails. The failure delta is compared with the last run of the same scope.

**Files produced**
- `test-results/hyperdot.log`
- `test-results/<runner>/` (JUnit, TRX, logs)
- `test-results/summary.json` and `summary.md`
- `test-results/coverage/index.html` when coverage is collected
- an appended line in `.godot/hyperdot-history.jsonl`

With `-Json`, stdout gets one `hyperdot/1` document, and failures stop with codes such as `tests-failed`.
