**Organization and naming.** The GDScript example has one GUT suite, `test/test_score.gd` (`extends GutTest`). Its three tests are `test_*` functions: two unit tests on `Score` (multiplier every fifth hit, miss resets combo) and one scene test that instantiates `res://main.tscn` and checks points after ready. `test/flows/startup.flow.json` is a flow file for the `flows` runner, not a GUT test. `project.godot` sets `run/main_scene="res://main.tscn"` and uses the GL Compatibility renderer.

**Discovery.** `Detect.ps1` selects `gut` when `Get-GutTestFiles` finds any `.gd` with `^extends GutTest` (line 141). The `*_test` naming is not checked; the `extends` line is what matters.

**Running.** `Runners.ps1` (lines 135–148) runs Godot headless with `addons/gut/gut_cmdln.gd -gexit`, writes JUnit XML to the results folder, and uses `.gutconfig.json` if present. Otherwise it passes `-gdir=<res path>` for each folder holding a GutTest script. `-Filter` becomes `-gunit_test_name`.
