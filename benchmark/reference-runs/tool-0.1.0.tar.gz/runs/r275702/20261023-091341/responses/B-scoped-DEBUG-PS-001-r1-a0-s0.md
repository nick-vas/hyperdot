1. **Godot process stalls** (import, editor wait, or a frame that never ends). `Invoke-Logged` in `ci/godot/lib/Common.ps1:184` stops the whole process tree after `Get-ProcessTimeout` (`Common.ps1:173`), which defaults to 1800 s. Mitigation: keep the default and raise `HYPERDOT_TIMEOUT` only when a suite truly needs longer.

2. **Timeout disabled.** `HYPERDOT_TIMEOUT=0` turns the guard off (`Common.ps1:172`), so a hang runs until the CI job is cancelled. Mitigation: never set it to 0 in CI, and keep the `Test-ProcessTimeout.ps1` self-test green.

3. **Retries multiply the wait.** `Invoke-TestRunnerWithRetry` (`ci/godot/lib/Runners.ps1:236`) reruns the whole runner up to `-Retry` times. Each attempt can take the full timeout, so one hang becomes (Retry+1) × 1800 s, which exceeds the 45-minute job cap. Mitigation: keep `-Retry` small and put known flaky tests in `quarantine.json` rather than retrying the suite.

4. **C# test session or build stalls.** The gdUnit4Net project sets `TestSessionTimeout` to 1800000 ms and `CompileProcessTimeout` to 180000 ms (`Runners.ps1:35`, `:44`). Mitigation: these are the guards already in place; check that a stuck `dotnet build` hits the 180 s limit before the session limit.

5. **A hang outside the process guard.** A job can stall in steps the process timeout does not cover, such as setup or a child that survives the kill. Mitigation: each job in `.github/workflows/self-test.yml` has `timeout-minutes: 45` (lines 17, 249, 365, and others), which is the outer cap. Its gap is that the 45-minute cap is shorter than one retried 1800 s hang, so a hang shows up as a cancelled job instead of a clear failure.
