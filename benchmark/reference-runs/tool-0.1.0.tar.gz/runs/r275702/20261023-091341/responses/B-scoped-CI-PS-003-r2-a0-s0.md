**Changes under `ci/godot/lib/`**
- Always: PSScriptAnalyzer on `ci/godot` with `ci/godot/PSScriptAnalyzerSettings.psd1`, then `tests/Test-LibNames.ps1` (no duplicate names or alias clashes).
- Always: `test -Project examples/csharp/game` and `test -Project examples/gdscript` must be green, and `doctor` green on both.
- If the change touches a concern in the AGENTS.md "Self-tests" table (e.g. `Localization.ps1` → `Test-Localization.ps1`, `Steam.ps1` → `Test-Steam.ps1`, `Plan.ps1` → `Test-Plan.ps1`): run that script too.
- If it touches `Plan.ps1` or `Init.ps1`: also do the plan check on a copy of `examples/gdscript`, as the Plan step of `self-test.yml` does.

**Changes to a skill (`.agents/skills/*/SKILL.md`)**
- Always: `pwsh ci/godot/tools/Test-Skills.ps1` and `pwsh tests/Test-SkillFixtures.ps1`.
- Always: `pwsh tests/Test-DocLinks.ps1` (links and quoted paths).
- If it names a command, flag, error code or version: `pwsh tests/Test-Context.ps1`.
- If it quotes a shader: `pwsh tests/Test-SkillShaders.ps1` (needs Godot).

**Changes to a page under `docs/`**
- Always: `pwsh tests/Test-DocLinks.ps1`.
- If it names a command, flag, file or error code, or changes `docs/json.md`: `pwsh tests/Test-Context.ps1`.
- If it describes a check's behaviour: run that check's self-test from the table.

**Before pushing**
- Running the matching scripts is required; `self-test.yml` runs them all on push, so a failing local run will also fail CI.
