1. **Fixed frame counts in flows.** `wait` and `action`'s `hold` count frames, so a slow runner can end a step before the game has reacted. Mitigation: use `wait_until` with an explicit `timeout` in the `.flow.json`, which waits for a condition instead of a count (capped at `FRAME_LIMIT` = 3600 in `flows.gd`).

2. **Resize races the first frame.** `flows.gd` says the engine resizes the root window during its first frame, and Xvfb can lag further. Mitigation: after a `resize` step, add a `wait_until` on a layout property that the resize changes (for example, a Control's size), instead of assuming the new size has applied.

3. **Unseeded randomness in GUT tests.** `flows.gd` seeds each flow from its `seed` key (default 0), but `examples/gdscript/test/test_score.gd` never seeds. Mitigation: call `seed(0)` in a `before_each` in every GUT test file that touches random code.

4. **Reading state before the scene settles.** `test_main_scene_scores_on_ready` asserts `main.score.points` right after `add_child_autofree`, before any frame has run. If `main.gd` scores from a timer or `_process`, the result depends on timing. Mitigation: `await get_tree().process_frame` before the assert.

5. **Neighbours' errors and an unready display.** `flows.gd` attributes any ERROR printed between flow markers to the current flow, so a late error from a freed scene lands on the next flow. `self-test.yml` also starts `Xvfb :99 &` and runs `bench`/`shot` immediately, and the web job uses a fixed `Start-Sleep -Seconds 2`. Mitigation: poll `xdpyinfo -display :99` until it succeeds before any display step, and for test-level flakes use `test -Retry` with a dated `quarantine.json` entry (covered by `tests/Test-Flaky.ps1`).
