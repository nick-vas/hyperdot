```diff
--- a/ci/godot/hyperdot.ps1
+++ b/ci/godot/hyperdot.ps1
@@ -121,3 +121,4 @@
     [string]$Seed = '1',
     [string]$Vary,
+    [ValidateRange(0, 1)]
     [double]$Amount = 0.05,
```
