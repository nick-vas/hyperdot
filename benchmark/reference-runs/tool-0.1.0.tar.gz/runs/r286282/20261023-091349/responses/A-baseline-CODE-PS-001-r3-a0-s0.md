```powershell
function Invoke-TestRunner {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Project,
        [Parameter(Mandatory)][scriptblock]$Run
    )

    $watch = [System.Diagnostics.Stopwatch]::StartNew()
    try {
        $output = @(& $Run $Project *>&1 | ForEach-Object { "$_" })
    }
    catch {
        Stop-GodotCi "Test runner '$Name' failed: $($_.Exception.Message)" 'runner-failed'
    }
    $watch.Stop()

    $exitCode = $LASTEXITCODE
    [pscustomobject]@{
        Runner          = $Name
        Project         = $Project
        ExitCode        = $exitCode
        Passed          = ($exitCode -eq 0)
        DurationSeconds = [math]::Round($watch.Elapsed.TotalSeconds, 2)
        Output          = $output
    }
}
```

`runner-failed` is a new stable code: add it to `docs/json.md` before use.
