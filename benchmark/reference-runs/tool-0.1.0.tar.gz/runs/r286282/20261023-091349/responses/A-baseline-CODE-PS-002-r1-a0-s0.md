```diff
--- a/ci/godot/hyperdot.ps1
+++ b/ci/godot/hyperdot.ps1
@@ -75,3 +75,3 @@
     # Frames the smoke runner plays, launched exports play, and shot waits before each screenshot.
-    [int]$Frames = 120,
+    [ValidateRange(1, 1000000)]
+    [int]$Frames = 120,
     # smoke: run at this fixed rate of game time (--fixed-fps), so -Frames is game time and a bot's run is the same on
```
