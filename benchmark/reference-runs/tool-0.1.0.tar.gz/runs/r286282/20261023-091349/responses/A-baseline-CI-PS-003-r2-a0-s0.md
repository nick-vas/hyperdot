**Every change (lib, skill or docs):**
- Run `pwsh ci/godot/hyperdot.ps1 test -Project examples/csharp/game`, `test -Project examples/gdscript`, and `doctor` on both. All must be green.

**If a file under `ci/godot/lib/` changed:**
- Run the self-test whose table row covers that file's concern, e.g. `Plan.ps1` → `tests/Test-Plan.ps1`, `Sfx.ps1` → `tests/Test-Sfx.ps1`, `Steam.ps1` → `tests/Test-Steam.ps1`.
- If you added, renamed or aliased a function → `tests/Test-LibNames.ps1`.
- If you added or changed an error code → `tests/Test-ErrorKeys.ps1`, and update `docs/json.md`. Codes are API; never rename them.
- If you changed a flag, command or output field → `tests/Test-Context.ps1`.

**If a skill changed (`.agents/skills/*/SKILL.md`):**
- Always `pwsh ci/godot/tools/Test-Skills.ps1` and `pwsh tests/Test-SkillFixtures.ps1`.
- If it quotes commands, flags, error codes or versions → `tests/Test-Context.ps1`.
- If it quotes a shader → `tests/Test-SkillShaders.ps1` (needs Godot).
- If it links to or quotes paths → `tests/Test-DocLinks.ps1`.

**If a docs page changed (`docs/`):**
- Always `tests/Test-DocLinks.ps1`.
- If it names flags, commands or error codes → `tests/Test-Context.ps1`.

The lib-to-test mapping is by concern, which AGENTS.md asks for ("run the self-test for what you change"); the table is the authority. Some self-tests need Godot or a display; if those aren't available here, say so rather than skipping silently.
