**Every change**
- Run `pwsh ci/godot/hyperdot.ps1 test -Project examples/csharp/game`, the same with `examples/gdscript`, and `doctor` on both.

**If a file under `ci/godot/lib/` changes**
- Run the table row for its concern, e.g. `Plan.ps1` → `tests/Test-Plan.ps1`, `Store.ps1` → `Test-Store.ps1`, `Web.ps1` → `Test-Web.ps1`, `Credits.ps1` → `Test-Credits.ps1`.
- If you changed `doctor` code, also run `Test-Context.ps1` and `Test-RepoHygiene.ps1`.
- If you added or renamed a function, run `tests/Test-LibNames.ps1`.
- If you added a `Stop-GodotCi` code, document it in `docs/json.md` (codes are API) and run `Test-DocLinks.ps1`.
- If you changed `plan`, also run the Plan step from `.github/workflows/self-test.yml` by hand.

**If a skill in `.agents/skills/` changes**
- `pwsh ci/godot/tools/Test-Skills.ps1` and `pwsh tests/Test-SkillFixtures.ps1` must both pass.
- If it quotes commands, flags, error codes or versions, run `tests/Test-Context.ps1`.
- If it quotes links or paths, run `tests/Test-DocLinks.ps1`.
- If it contains shaders, run `tests/Test-SkillShaders.ps1` (needs Godot).
- If it describes capture mode, run `tests/Test-Capture.ps1` (needs Godot and a display).

**If a page under `docs/` changes**
- Run `tests/Test-DocLinks.ps1`.
- If it quotes flags, commands or `-Json` fields, or is `docs/json.md`, run `tests/Test-Context.ps1`.

**If a test needs Godot or a display**
- Start `Xvfb :99 &` with `DISPLAY=:99`. Don't use `xvfb-run`. If you can't run the test here, say so in the report and don't claim it passed.
