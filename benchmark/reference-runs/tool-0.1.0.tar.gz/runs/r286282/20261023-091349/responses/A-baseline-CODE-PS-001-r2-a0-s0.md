```powershell
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'

function Invoke-TestRunner {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][ValidateSet('dotnet', 'godot')][string]$Runner,
        [Parameter(Mandatory)][string]$ProjectPath,
        [string[]]$Arguments = @()
    )

    $exe = if ($Runner -eq 'dotnet') { 'dotnet' } else { 'godot' }
    if ($null -eq (Get-Command $exe -ErrorAction SilentlyContinue)) {
        Stop-GodotCi "$exe not found for the $Runner runner" 'runner-missing'
    }

    Write-CiLog "Running $Runner tests in $ProjectPath"
    $watch = [System.Diagnostics.Stopwatch]::StartNew()
    $lines = @(& $exe @Arguments 2>&1 | ForEach-Object { "$_" })
    $exitCode = $LASTEXITCODE
    $watch.Stop()

    [pscustomobject]@{
        Runner   = $Runner
        Project  = $ProjectPath
        ExitCode = $exitCode
        Passed   = ($exitCode -eq 0)
        Seconds  = [math]::Round($watch.Elapsed.TotalSeconds, 1)
        Output   = $lines
    }
}
```

Notes:
- Test failures return `Passed = $false` in the result. Only a missing executable stops the run, through `Stop-GodotCi`.
- `runner-missing` is a new stable code. It must be added to `docs/json.md` before this is merged.
- The function does not enforce a time limit. The kit's process timeout helper should be used in its place.
- `godot` is a placeholder for the path the kit resolves for Godot. The real runner would also need the GUT or gdUnit4 arguments.
- I did not check this against `ci/godot/lib/Runners.ps1` or run it. This environment is Linux with no `pwsh` checked, so it is untested.
