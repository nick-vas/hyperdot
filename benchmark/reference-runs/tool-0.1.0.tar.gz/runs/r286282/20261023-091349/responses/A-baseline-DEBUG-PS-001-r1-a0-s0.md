Five likely causes, from reading the code (I have not reproduced a hang):

1. **A Godot process that never resumes**, such as an `await` on a signal that never fires. Guard: `Invoke-Logged` in `ci/godot/lib/Common.ps1` kills the process tree after `HYPERDOT_TIMEOUT` (default 1800 s) and returns 124. Mitigation: set a smaller `HYPERDOT_TIMEOUT` for local runs, and leave it non-zero in CI, since `0` turns the guard off.

2. **A child process keeps stdout or stderr open after the parent exits**, such as a build server. Guard: the read loop breaks once the parent has exited, so this only hangs if the parent itself hangs. Mitigation: run `dotnet build-server shutdown` between runs so a leftover node is not holding pipes.

3. **A gdUnit4Net compile or session stall.** Guard: `ci/godot/lib/Runners.ps1` sets `CompileProcessTimeout` to 180000 ms and `TestSessionTimeout` to 1800000 ms. Mitigation: give long suites explicit bounded waits, and lower the session timeout for suites that should finish in minutes.

4. **Retry multiplying the wait.** `Invoke-TestRunnerWithRetry` reruns the whole runner up to `-Retry` more times, and each attempt gets its own timeout, so the worst case is (Retry + 1) × timeout. Mitigation: keep `-Retry` at 1 or 2 in CI, and check the total against the job's time limit.

5. **A soak server that ignores shutdown.** Guard: `ci/godot/lib/Soak.ps1` waits `StopGraceSeconds`, then kills the tree. On Windows there is no SIGTERM, so the kill comes at once. Mitigation: keep the grace period short, and use the `soak-fixture-cs` self-test to confirm the server handles SIGTERM.

The existing guards are covered by `tests/Test-ProcessTimeout.ps1`, `tests/Test-SceneCount.ps1` and `tests/Test-Soak.ps1`. I did not run them.
