1. **Reading scene state before `_ready` runs.** Godot scripts run before the first frame, so a test that asserts right after `add_child` can see unset state and pass or fail depending on timing. **Mitigation:** `await process_frame` after every `add_child` in GUT tests, as AGENTS.md requires for `-s` scripts.

2. **Display race or missing display on the runner.** Tests that touch rendering, `shot`, or `audio -Mix` fail when Xvfb is not ready or `DISPLAY` is unset. **Mitigation:** start `Xvfb :99 &` and export `DISPLAY=:99` in the composite action before Godot starts. Do not use `xvfb-run`, which merges stderr into stdout and breaks `-Json`.

3. **Slow shared runners hitting time limits.** Godot startup, import, and GUT suites can run long on loaded hosts and trip the process time limit. **Mitigation:** run with `test -Retry`, record the known intermittent tests in `quarantine.json` (`flaky-fixture` shows the pattern), and fix the root cause rather than raising the limit everywhere.

4. **State leaking between tests.** Autoloads, singletons, and files under `user://` such as settings or saves persist across tests and runs, so order changes the result. **Mitigation:** reset autoloads in `before_each`, and point each test at its own temporary `user://` path.

5. **Unseeded randomness or wall-clock timing.** Unseeded RNG, `Time.get_ticks_msec()`, or real-time waits give different results on each run and on slower machines. **Mitigation:** seed RNG explicitly (the procgen seed streams), and drive timing with physics or frame counts instead of real time.

Triage: `test` reports failure deltas against the previous run, and `status` lists `recurringErrors`. Use them to confirm a test is flaky, not just newly broken, before quarantining it.
