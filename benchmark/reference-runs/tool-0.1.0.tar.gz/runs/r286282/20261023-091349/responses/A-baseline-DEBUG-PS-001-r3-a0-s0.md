Five likely causes, from the code (static read only; I did not run a hanging test):

1. **Godot deadlocks, or an `await` never resumes.** `Get-ProcessTimeout` in `ci/godot/lib/Common.ps1:173` stops the process after 1800 s by default, and `Invoke-Logged` returns 124. *Mitigation:* set `HYPERDOT_TIMEOUT` to a lower value in CI, since the default still means 30 minutes of waiting.

2. **The limit is switched off.** `HYPERDOT_TIMEOUT=0` disables the timeout entirely (`Common.ps1:172`). *Mitigation:* never set it to 0 in CI or in agent sessions, and keep it finite.

3. **Pipe-buffer deadlock.** If stdout and stderr were read one after the other, a full pipe would block the child. `Invoke-Logged` reads both with `ReadLineAsync` (`Common.ps1:200-201`), which avoids this. *Mitigation:* keep the two async readers. Do not replace them with sequential reads.

4. **Compile or rebuild hangs in the .NET runner.** `Runners.ps1:35` sets `TestSessionTimeout` to 1800000 ms, and `Runners.ps1:44` sets `CompileProcessTimeout` to 180000 ms. *Mitigation:* confirm both are present in the generated gdUnit4 settings, and lower them if CI waits too long.

5. **A server or flood process outlives its test.** `Soak.ps1:124-150` waits for a grace period, then calls `Kill($true)` on the process tree. *Mitigation:* make sure every spawned server is stopped in a `finally` block, so the soak runner's kill path is not the only thing that cleans up.

Retries (`test -Retry`, `Invoke-TestRunnerWithRetry` in `Runners.ps1:236`) can multiply a hang's cost, so keep `-Retry` small and quarantine known flaky tests.
