**Entry point:** `ci/godot/hyperdot.ps1` with `test` as the default command. It dot-sources `lib/*.ps1`, then calls `Get-ProjectInfo` (`lib/Detect.ps1`).

**Detection:** The project is the shallowest folder with `project.godot`. The Godot version comes from `Godot.NET.Sdk` in the csproj, else `4.7.2`. With no `-Runners`, it always selects `validate` and `architecture`, then adds:
- `dotnet`: a `.sln` whose csproj references `Microsoft.NET.Test.Sdk` or gdUnit4.
- `godottest`: a csproj referencing Chickensoft GoDotTest.
- `gut`: scripts that `extends GutTest`.
- `flows`: `*.flow.json`.
- `smoke`: `run/main_scene` set.
- `juice`, `playthrough`, `l10n`, `data`, `textsize`, `layout`: the matching json file exists.

**Steps:** `Invoke-Setup` uses `GODOT_BIN` or installs Godot. `Invoke-Build` installs GUT if needed, runs `dotnet build` on the solution, then `godot --headless --path <p> --import`. `Invoke-Tests` wipes `-Results` (keeping `hyperdot.log`) and runs each runner through `Invoke-TestRunnerWithRetry`.

**Godot per runner** (`lib/Runners.ps1`):
- `validate`: `-s tools/validate.gd`
- `flows`: `-s tools/flows.gd`
- `gut`: `-s addons/gut/gut_cmdln.gd -gexit -gjunit_xml_file=…`
- `godottest`: `--run-tests --quit-on-finish`, or coverlet around it
- `smoke`: `--quit-after <Frames>`
- `dotnet` and `gdunit4`: `dotnet test` with a generated `godot.runsettings`

**Files:** `test-results/<runner>/` holds JUnit or TRX, logs, and `findings.json`. Failed attempts are kept as `<runner>.attempt<N>`. Coverage is merged into `test-results/coverage/`. `summary.json`, `summary.md` and `hyperdot.log` sit in `test-results/`. The project's `.godot/hyperdot-history.jsonl` gets a line per run.
