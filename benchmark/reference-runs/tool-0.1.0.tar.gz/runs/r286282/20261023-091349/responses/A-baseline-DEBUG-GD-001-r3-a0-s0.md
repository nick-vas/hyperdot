**Five likely causes of flaky GDScript tests in this kit's CI, each with one mitigation**

1. **Unseeded randomness.** A test that calls `randf()` or `randi()` gets different values each run. *Mitigation:* give each test its own `RandomNumberGenerator` with a fixed `seed`. `Architecture.ps1` already rejects the global generator in game code, so tests should follow the same rule.

2. **Fixed waits.** `await get_tree().create_timer(0.1)` or a fixed frame count passes on a fast machine and fails on a loaded runner. *Mitigation:* poll the real condition against a deadline, as `flows.gd` does with its per-step `timeout` (default 300). Also watch `flaky[]` in the summary. `-Retry` makes a timing failure pass silently on the second attempt, so the flake is hidden unless someone reads that list.

3. **State leaking between tests.** GUT runs every test in one Godot process, so autoload values, `Input` state or a `user://` save from one test can change the next. *Mitigation:* reset that state in `before_each`, and give each test its own `user://` path.

4. **Reading the scene too early.** Scripts run with `-s` cannot see `_ready` until the first frame. *Mitigation:* `await process_frame` after `add_child`, before reading anything the scene sets up, as `AGENTS.md` requires.

5. **Cold import on a fresh checkout.** CI starts without `.godot/`, so the first run imports assets and classes while tests run, and an intermittent missing-class or missing-resource error can appear. *Mitigation:* run `godot --headless --import` as a separate step before `test`. Keep the run history as a CI artifact too, because `.godot/` is not in a fresh checkout and `status`'s `flakyTests` never builds up on CI.
