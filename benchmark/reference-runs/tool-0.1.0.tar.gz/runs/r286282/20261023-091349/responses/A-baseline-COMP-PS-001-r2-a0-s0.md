`hyperdot.ps1 test` runs in four stages: resolve the project, build, run each runner, then summarise.

**1. Entry script** (`ci/godot/hyperdot.ps1`). It dot-sources the `lib/*.ps1` files and calls `Get-ProjectInfo`, which finds `project.godot` and the solution, reads the Godot version, and picks the runners. `test` then starts the run log and history, and calls `Invoke-Setup`, `Invoke-Build`, `Invoke-Tests` in that order.

**2. Detection** (`lib/Detect.ps1`, `Get-ProjectInfo`). Without `-Runners`, it always adds `validate` and `architecture`. It adds `dotnet` for a test-SDK or gdUnit4 reference, `godottest` for Chickensoft, `gut` for `test_*.gd`, `flows`, `smoke` when `run/main_scene` is set, and the optional `juice`, `playthrough`, `l10n`, `data`, `textsize` and `layout` runners when their JSON files exist.

**3. Build** (`Invoke-Build`). It installs GUT if needed, runs `dotnet build` for C# projects, then `godot --headless --import`.

**4. Runners** (`lib/Runners.ps1`). `Invoke-Tests` clears the results folder except `hyperdot.log`, then runs each runner into `test-results/<runner>/`:
- `dotnet` and `gdunit4`: `dotnet test` with a generated `godot.runsettings`, writing TRX.
- `godottest`: `$GODOT_BIN --headless --path … <scene> --run-tests --quit-on-finish`, writing a JUnit file converted from the log.
- `gut`: `gut_cmdln.gd -gexit -gjunit_xml_file=…`.
- `validate`, `flows`: `-s tools/*.gd`.
- `smoke`: `--quit-after <Frames>`.

`-Retry` reruns a failed runner and keeps `<runner>.attempt<N>`.

**Outputs.** Per runner: JUnit or TRX, logs, and `coverage/` when enabled. At the root: `summary.json`, `summary.md`, `hyperdot.log`. Each run appends a line to `.godot/hyperdot-history.jsonl`, which the failure delta and `status` read.
