**Five likely causes of a hanging test run**

1. **A test awaits a signal that never fires.** Godot sits on a deadlocked `await`. Guard: `Invoke-Logged` stops the process tree after `HYPERDOT_TIMEOUT` seconds (default 1800, `ci/godot/lib/Common.ps1:174`) and returns 124. Mitigation: lower `HYPERDOT_TIMEOUT` for local runs and give each test `await` its own timeout.

2. **Headless Godot never exits.** Guard: `--quit-on-finish` for gdUnit (`ci/godot/lib/Runners.ps1:116`) and `-gexit` for GUT (`Runners.ps1:139`). Mitigation: any new runner must pass an equivalent exit flag.

3. **The gdUnit4 session or the C# compile runs too long.** Guard: `TestSessionTimeout` of 1800000 ms and `CompileProcessTimeout` of 180000 ms (`Runners.ps1:35,44`). Mitigation: find the slow suite with the test duration report (`Test-TestDuration.ps1`) before raising either limit.

4. **A display-dependent command waits for a window.** This applies to `bench`, `shot` and `audio -Mix` when no display is present. The only guard is the global timeout. Mitigation: start `Xvfb :99` and set `DISPLAY=:99`, as AGENTS.md describes.

5. **A child process keeps the pipes open, or retries multiply the wait.** A build server can hold stdout open after the program exits. Guard: `Common.ps1:216` breaks the read loop once the process has exited. Each `test -Retry` attempt can wait the full timeout. Mitigation: cap retries and quarantine known flaky tests in `quarantine.json` (`Test-Flaky.ps1`).

These come from reading the code, not from running the tests.
