**Layout:** `examples/gdscript/test/` holds `test_score.gd` (GUT, three tests) and `flows/startup.flow.json`, a UI flow that runs through `flows.gd`, not GUT.

**Naming:** GUT runs only files named `test_*.gd`. Each test is a `func test_...()` method in a script that `extends GutTest`. Test names describe behaviour, such as `test_miss_resets_combo`. `Doctor.ps1` warns about GUT scripts without the `test_` prefix.

**Discovery:** With no `.gutconfig.json`, `Get-GutTestFiles` (`Detect.ps1:56`) finds every `.gd` file whose line starts with `extends GutTest`. `Runners.ps1` passes each containing folder to GUT as `-gdir=res://...`, sorted and de-duplicated. If `.gutconfig.json` exists, the kit leaves discovery to it.

**Running:** The `gut` runner (`Runners.ps1:135`) requires `addons/gut/gut_cmdln.gd` and runs headless with `-s addons/gut/gut_cmdln.gd -gexit -gdisable_colors`. It writes `gut.junit.xml` and `gut.log` to the results folder. `-Filter` becomes `-gunit_test_name`, which selects tests by name.
