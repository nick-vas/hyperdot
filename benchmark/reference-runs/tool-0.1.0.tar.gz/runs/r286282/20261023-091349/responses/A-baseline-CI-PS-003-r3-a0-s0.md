**Source:** AGENTS.md's self-test table and rules. I have not run these checks.

**Any change**
- If a `ci/godot/lib` file changed, run `pwsh tests/Test-LibNames.ps1` (unique function names, no alias clashes).

**If a file in `ci/godot/lib` changed**
- Run the self-test for its concern. For example, `Audio.ps1` → `Test-Audio.ps1`, `Steam.ps1` → `Test-Steam.ps1`, `Plan.ps1` → `Test-Plan.ps1`. `Doctor.ps1` → `Test-Platforms.ps1`, `Test-Addons.ps1`, `Test-RepoHygiene.ps1`, `Test-Context.ps1`.
- Run `pwsh ci/godot/hyperdot.ps1 test -Project examples/csharp/game` and `-Project examples/gdscript`, and `doctor` on both. Both must be green. These need Godot.

**If a skill changed** (`.agents/skills/*/SKILL.md`)
- `pwsh ci/godot/tools/Test-Skills.ps1` and `pwsh tests/Test-SkillFixtures.ps1` must pass.
- If it quotes a command, flag, error code or version: `pwsh tests/Test-Context.ps1`.
- If it quotes a link or path: `pwsh tests/Test-DocLinks.ps1`.
- If it contains a shader: `pwsh tests/Test-SkillShaders.ps1` (needs Godot).
- If it covers capture mode: `pwsh tests/Test-Capture.ps1` (needs Godot and a display).

**If a page under `docs/` changed**
- `pwsh tests/Test-DocLinks.ps1`.
- If it quotes a command, flag, error code or version, or if `docs/json.md` changed: `pwsh tests/Test-Context.ps1`.

Do not push while any of these fail. If Godot or a display is unavailable here, say so in the commit or PR notes and run what you can.
