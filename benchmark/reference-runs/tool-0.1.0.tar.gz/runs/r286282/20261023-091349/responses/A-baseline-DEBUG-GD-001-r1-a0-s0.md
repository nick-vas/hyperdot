1. **Order-dependent shared state.** GUT runs tests in file order, and one test can leave autoloads, `Engine.time_scale`, `user://` files or nodes behind. Mitigation: reset that state in `after_each`, and use `add_child_autofree` so nodes don't leak. Then run the suite locally in a different order to confirm no test depends on another.

2. **Unseeded randomness.** A test that calls the global `randf()` or `randi()` gets different results each run. `Architecture.ps1` already flags these calls in game code, so tests should not be exempt. Mitigation: give each test a `RandomNumberGenerator` with a fixed seed.

3. **Frame timing and wall-clock assertions.** Tests that wait on real time or a varying frame rate pass on a fast machine and fail on a loaded runner. Mitigation: assert on simulated ticks, not seconds, and run the suite at a fixed frame rate. The `FixedFps` parameter in `Invoke-TestRunnerWithRetry` (`Runners.ps1:238`) is the hook for this.

4. **First-frame race.** `AGENTS.md` notes that scripts cannot see a scene's `_ready` until the first frame. A test that reads scene state right after `add_child` passes or fails depending on timing. Mitigation: `await process_frame` after `add_child`, before reading anything.

5. **Cold start and timeouts on CI.** The first run imports the project, and a slow runner can exceed the process limit. Mitigation: raise `HYPERDOT_TIMEOUT` for the CI job, and check that the crash-retry path (`Test-CrashRetry.ps1`) covers the import step.

For failures that remain after these fixes, use `test -Retry` and record each test in `quarantine.json` with an owner, an expiry date and a reason. The report lists flaky and quarantined tests, so the retries are never silent.

I checked these against the repository code and docs. I did not run the test suite.
