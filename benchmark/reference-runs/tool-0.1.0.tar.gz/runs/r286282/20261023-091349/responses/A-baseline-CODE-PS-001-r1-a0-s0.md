```powershell
function Invoke-TestRunnerStep {
    param([Parameter(Mandatory)][string]$Name, [Parameter(Mandatory)][string]$Exe, [string[]]$Arguments = @(), [Parameter(Mandatory)][string]$ResultsDir)

    if (-not $Exe) { Stop-GodotCi "$Name runner: no executable given" }
    New-Item -ItemType Directory -Force $ResultsDir | Out-Null
    $log = Join-Path $ResultsDir "$Name.log"
    $code = [int](Invoke-Logged $Exe $Arguments $log)
    return [pscustomobject][ordered]@{
        Runner   = $Name
        ExitCode = $code
        Passed   = ($code -eq 0)
        Log      = $log
    }
}
```

Note: `Invoke-TestRunner` already exists in `ci/godot/lib/Runners.ps1:90`, so this name is deliberately different. `Invoke-Logged` is the repo's existing helper (used at `Runners.ps1:126`); I did not run this code.
