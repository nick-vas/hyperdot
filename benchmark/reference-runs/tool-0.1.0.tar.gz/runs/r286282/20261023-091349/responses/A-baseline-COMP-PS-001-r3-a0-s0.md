**Entry point:** `ci/godot/hyperdot.ps1` takes `test` as its default command. It dot-sources the `lib/*.ps1` files, then `Get-ProjectInfo` (`lib/Detect.ps1`) works out the project, Godot version, solution and runners.

**Detection:** `Find-GodotProject` takes the shallowest `project.godot` (or `-Project`). The Godot version comes from `Godot.NET.Sdk/` in the csproj, else `GODOT_VERSION`, else 4.7.2. With no `-Runners`, it adds `validate` and `architecture` always, plus `dotnet`, `godottest`, `gut`, `flows`, `smoke`, `juice`, `playthrough`, `l10n`, `data`, `textsize` or `layout` when the matching files exist.

**Run:** `test` runs `Invoke-Setup`, then `Invoke-Build` (GUT install, `dotnet build`, `godot --headless --import`), then `Invoke-Tests`. Each runner goes through `Invoke-TestRunnerWithRetry` and `Invoke-TestRunner` (`lib/Runners.ps1`):
- `dotnet`/`gdunit4`: `dotnet test` with a generated `godot.runsettings`.
- `godottest`: `godot --headless --path … --run-tests`, or coverlet when coverage is on.
- `gut`: `gut_cmdln.gd -gexit`.
- `validate`, `flows`: `-s tools/*.gd`.
- `smoke`: `--quit-after $Frames`.
- Others call their own `lib` runner.

Failures are read from JUnit or TRX, then `Write-TestSummary` decides pass or fail. `-Retry` reruns a failed runner.

**Files:** `test-results/<runner>/` (JUnit/TRX, `*.log`, `coverage/`), `test-results/summary.json`, and `test-results/hyperdot.log`. Retried attempts are kept as `<runner>.attempt<N>`. Each run also appends a line to `.godot/hyperdot-history.jsonl`. `-Json` prints one `hyperdot/1` document on stdout.
