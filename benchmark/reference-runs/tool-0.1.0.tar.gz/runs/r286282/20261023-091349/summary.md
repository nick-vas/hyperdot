# Token benchmark 20261023-091349

Model claude-haiku-5-5, 3 run(s) per task and profile, 24 session(s), CLI 2.1.309 (Claude Code), with this repository loaded as a plugin (its skills).
Tokens include cache reads and writes; cost is Claude Code's own figure. Medians leave out sessions stopped at the time limit, whose spend is unknown (the "Unknown" column).

| Profile | Runs | Success % | Median tokens | P90 tokens | Median output | Median turns | Median cost | Total cost | Successes per $ | Median time (s) | Retries | Unknown |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| A-baseline | 24 | 75 | 72,954 | 252,136 | 2,288 | 4 | $0.0036 | $0.1105 | 162.93 | 13.0 | 0 | 0 |

| Task | Profile | Successes | Median tokens | Median cost | Failures |
|---|---|---:|---:|---:|---|
| COMP-PS-001 | A-baseline | 3/3 | 267,602 | $0.0127 |  |
| COMP-GD-001 | A-baseline | 3/3 | 80,648 | $0.0024 |  |
| CODE-PS-001 | A-baseline | 3/3 | 26,700 | $0.0017 |  |
| CODE-PS-002 | A-baseline | 3/3 | 80,936 | $0.0051 |  |
| DEBUG-PS-001 | A-baseline | 2/3 | 89,130 | $0.0043 | 265 words, limit 260 |
| DEBUG-GD-001 | A-baseline | 0/3 | 53,012 | $0.0033 | 280 words, limit 260 / 265 words, limit 260 / missing 'quarantine'; 264 words, limit 260 |
| CI-PS-001 | A-baseline | 1/3 | 25,304 | $0.0025 | missing 're:\bscop(e/ed)\b' / 241 words, limit 220 |
| CI-PS-003 | A-baseline | 3/3 | 26,381 | $0.0016 |  |
