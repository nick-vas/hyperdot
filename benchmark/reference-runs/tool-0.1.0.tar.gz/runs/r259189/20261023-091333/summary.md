# Token benchmark 20261023-091333

Model claude-sonnet-5-5, 3 run(s) per task and profile, 24 session(s), CLI 2.1.309 (Claude Code), without the plugin.
Tokens include cache reads and writes; cost is Claude Code's own figure. Medians leave out sessions stopped at the time limit, whose spend is unknown (the "Unknown" column).

| Profile | Runs | Success % | Median tokens | P90 tokens | Median output | Median turns | Median cost | Total cost | Successes per $ | Median time (s) | Retries | Unknown |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| A-baseline | 24 | 45.8 | 30,368 | 97,270 | 834 | 1.5 | $0.0248 | $0.7897 | 13.93 | 9.2 | 0 | 0 |

| Task | Profile | Successes | Median tokens | Median cost | Failures |
|---|---|---:|---:|---:|---|
| COMP-PS-001 | A-baseline | 0/3 | 104,628 | $0.0759 | 296 words, limit 240 / 303 words, limit 240 / 332 words, limit 240 |
| COMP-GD-001 | A-baseline | 2/3 | 61,643 | $0.0260 | 206 words, limit 200 |
| CODE-PS-001 | A-baseline | 3/3 | 20,069 | $0.0116 |  |
| CODE-PS-002 | A-baseline | 3/3 | 61,586 | $0.0258 |  |
| DEBUG-PS-001 | A-baseline | 1/3 | 41,142 | $0.0209 | 291 words, limit 260 / 279 words, limit 260 |
| DEBUG-GD-001 | A-baseline | 1/3 | 19,887 | $0.0093 | 280 words, limit 260 / 295 words, limit 260 |
| CI-PS-001 | A-baseline | 1/3 | 19,702 | $0.0069 | 231 words, limit 220 / 237 words, limit 220 |
| CI-PS-003 | A-baseline | 0/3 | 20,049 | $0.0103 | 280 words, limit 240 / 249 words, limit 240 / 282 words, limit 240 |
