```powershell
function Invoke-TestRunner {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Project,
        [Parameter(Mandatory)][scriptblock]$Run,
        [int]$TimeoutSec = 600
    )
    Set-StrictMode -Version 3.0
    $ErrorActionPreference = 'Stop'

    if (-not (Test-Path -LiteralPath $Project -PathType Container)) {
        Stop-GodotCi "Project folder not found: $Project" 'project-not-found'
    }

    Write-Host "Running $Name tests in $Project"
    $watch = [System.Diagnostics.Stopwatch]::StartNew()
    $failures = @()
    $exitCode = 0
    try {
        $lines = @(& $Run $Project 2>&1)
        $exitCode = $LASTEXITCODE
        if ($null -eq $exitCode) { $exitCode = 0 }
        foreach ($line in $lines) {
            $text = "$line"
            if ($text -match '^\s*(FAILED|ERROR)\b') { $failures += $text.Trim() }
        }
    }
    catch {
        Stop-GodotCi "$Name runner crashed: $($_.Exception.Message)" 'runner-crashed'
    }
    $watch.Stop()

    $passed = ($exitCode -eq 0 -and $failures.Count -eq 0)
    $result = [pscustomobject]@{
        runner     = $Name
        passed     = $passed
        exitCode   = $exitCode
        failures   = @($failures)
        durationMs = [int]$watch.ElapsedMilliseconds
    }

    Set-JsonField 'runner' $result
    return $result
}
```

Notes:
- Uses `Stop-GodotCi` with stable codes (`project-not-found`, `runner-crashed`). Per AGENTS.md, add them to `docs/json.md`.
- Logs via `Write-Host`, never `Write-Output`; the result is the only pipeline value.
- `@(...)` wraps possibly empty or single results.
- `$TimeoutSec` is declared but not enforced. Remove it or wire it to the repo's process time limit.
- I haven't run this, and `Set-JsonField`'s argument order is assumed. I didn't check it against `ci/godot/lib/Common.ps1`.
