- **Scope context with a short index:** Keep `AGENTS.md` to layout and rules only, and move the self-test table and Targets into `docs/`. Agents load it on every turn, so a shorter file saves tokens each time. Point to `docs/` pages by path so agents open them only when needed.

- **Prompt templates by task:** Give `/game`, `init` and the architect small per-task templates. Include only the relevant gate or phase from `plan.json`, `GDD.md` and `ADR.md`. Don't paste whole templates into every prompt.

- **Cache stable prefixes:** Put the stable material first in subagent and benchmark prompts: AGENTS.md, skills and `docs/json.md`. Put the changing task text last, so prompt caching applies. In CI, cache the downloaded Godot, the templates and the `.godot` import folder, so agents don't spend turns on setup and reimport.

- **Cap output size:** Always run with `-Json` and have the Stop hook and `godot-verifier` read only the summary fields: status, stable error code, failing test names and the first N lines of each failure. Write full logs to files and reference them by path. Truncate stderr and the PR comment.

- **Run only the affected checks:** Use the "Run the self-test for what you change" mapping to choose tests, instead of all of `self-test.yml`. Run `test` on one example project rather than both unless a version matrix entry changed. Reuse the failure delta from the previous run, so agents see only new failures.
