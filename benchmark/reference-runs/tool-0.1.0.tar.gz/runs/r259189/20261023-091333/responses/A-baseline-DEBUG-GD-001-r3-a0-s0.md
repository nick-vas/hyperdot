Five likely causes of flaky GDScript tests in this kit's CI, each with a mitigation. I answered from the repo guidance and didn't inspect the code.

1. **Scene readiness races.** Code run with `-s tools/x.gd` can't see a scene's `_ready` until the first frame, so a test that reads state straight after `add_child` is sometimes early. *Mitigation:* `await process_frame` after `add_child` in GUT tests, as the kit's own tools do.

2. **Timing and frame-rate dependence.** Tests that use real-time waits, physics steps or `delta` behave differently on slow shared Linux runners. *Mitigation:* wait on signals or fixed frame counts instead of seconds. Where timing can't be avoided, use `test -Retry` and record the test in `quarantine.json`. `Test-Flaky.ps1` covers this path.

3. **Missing display or audio.** Rendering, `shot` and `bench` need a display, and `audio` needs ffmpeg. Without Xvfb, results vary or tests crash. *Mitigation:* start `Xvfb :99 &` and set `DISPLAY=:99` before the run. Don't use `xvfb-run`, because it breaks `-Json` output.

4. **Leaked state between tests.** Autoloads, orphan nodes, static variables and saved files under `user://` carry over from one test to the next, so results depend on test order. *Mitigation:* free nodes with `autofree` or `add_child_autofree`, reset autoloads in `before_each`, and clean `user://` in `after_each`. Check for orphans in the GUT output.

5. **Nondeterministic randomness and import state.** Unseeded `randf` makes results differ between runs. A stale `.godot` import cache, or a crashed first import, also fails some runs. *Mitigation:* call `seed(n)` in `before_each`. For the import problem, rely on the kit's repeat of a crashed import or export (`Test-CrashRetry.ps1`) and keep the GUT version pinned (v9.7.1).

To tell which cause you have, use `status`'s `recurringErrors` and the failure delta from the previous run. Both show whether a failure is stable or intermittent.
