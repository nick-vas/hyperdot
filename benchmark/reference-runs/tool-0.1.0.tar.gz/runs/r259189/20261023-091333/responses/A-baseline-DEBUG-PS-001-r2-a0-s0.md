Ranked by likelihood. The guards come from a grep of `ci/godot`. I didn't open the files.

1. **Godot or a child process never exits.** Examples are a game that doesn't quit, or an import that stalls.
   - Guard: `Get-ProcessTimeout` and the wrapper in `lib/Common.ps1:173-228`. It kills the process tree and returns 124 after the limit.
   - Mitigation: set `HYPERDOT_TIMEOUT` to a sensible value. Raise it only for slow jobs.

2. **gdUnit4Net rebuilds or hangs mid-session.**
   - Guard: the runsettings in `lib/Runners.ps1:35-44`. They set `TestSessionTimeout` to 1800000 ms and `CompileProcessTimeout` to 180000 ms.
   - Mitigation: lower `TestSessionTimeout` in CI so a stuck session fails sooner.

3. **A flow step waits forever.** An example is a `flows.gd` step waiting for a signal or state that never arrives.
   - Guard: the per-step `timeout`, which defaults to 300 s (`tools/flows.gd:176`).
   - Mitigation: set a short `timeout` on every waiting step in the flow JSON.

4. **Server or network fixtures ignore termination.** Examples are `soak` ENet or C# servers that catch SIGTERM, and downloads.
   - Guard: the same process-tree kill. `Test-Soak.ps1` covers a server that catches SIGTERM, and `Test-DownloadFailed.ps1` covers the `download-failed` code.
   - Mitigation: give servers a hard-kill fallback. Keep downloads on bounded retries.

5. **Missing display or browser stalls the run.** `bench`, `shot` and `audio -Mix` block or crash without a display. Web `export -Run` can wait on a browser page.
   - Guards: `web-smoke.mjs` has `--timeout`, which defaults to 60000 ms. The process limit covers the rest.
   - Mitigation: start `Xvfb :99 &` and set `DISPLAY=:99`. Don't use `xvfb-run`. Pass a smaller `--timeout` for Web smoke tests.

A crashed import or export is a related case. `Test-CrashRetry.ps1` covers the repeat of a crashed import or export, so a crash there shouldn't hang the run.
