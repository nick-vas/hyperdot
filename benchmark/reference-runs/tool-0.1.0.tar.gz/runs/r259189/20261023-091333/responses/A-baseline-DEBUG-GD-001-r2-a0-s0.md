1. **Frame-timing races in scenes.** Tests assert before `_ready` or deferred calls have run. Mitigation: `await process_frame` after `add_child`, as the AGENTS.md rule says for `tools/*.gd`. Do the same in the GUT tests.

2. **Headless CI has no display.** Rendering, viewport and input tests behave differently on Linux runners. Mitigation: start `Xvfb :99 &` and set `DISPLAY=:99`. Don't use `xvfb-run`, which merges stderr into stdout and breaks `-Json`. Keep display-free logic tests separate from the ones that need a display.

3. **Wall-clock and physics-time dependence.** Timers, tweens and `physics_frame` counts vary with runner load. Mitigation: drive time by frame count or by injected delta instead of real seconds. Rely on the kit's process time limit (`Test-ProcessTimeout.ps1`) to catch hangs, not to pace tests.

4. **Leaked state between tests.** Autoloads, singletons, orphan nodes, saved files in `user://` and RNG seeds persist across tests. Mitigation: free nodes in `after_each`, reset autoloads, and seed RNG explicitly. Check GUT's orphan report.

5. **Transient engine or import failures.** Crashes in first-time import, a stale `.godot` cache, or a slow Godot download can look like test failures. Mitigations:
   - Use `test -Retry`, which re-runs failures.
   - List known-flaky tests in `quarantine.json`. `Test-Flaky.ps1` covers this with `flaky-fixture`.
   - Cache the Godot binary and the import.
   - Read `status`'s `recurringErrors` and the failure delta to separate real regressions from flakes.
