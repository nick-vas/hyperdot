`test` runs three steps in sequence: `Invoke-Setup; Invoke-Build; Invoke-Tests`. The dispatch is at `ci/godot/hyperdot.ps1:575`.

**Entry and detection**
- `hyperdot.ps1` calls `Get-ProjectInfo` (`lib/Detect.ps1:116`) for the project and runners.
- That function finds the `project.godot` directory with `Find-GodotProject`, the solution or csproj with `Find-Solution`, the Godot version, the GoDotTest scene, and GUT test files.
- It works out the `Runners` list from those. You can override the list with `-Runners`, which is split on commas.
- Setup downloads or finds Godot and sets `$env:GODOT_BIN`. Build runs `--headless --path … --import`, through `Invoke-GodotRetried` so a Godot crash is repeated.

**Running the tests**
- `Invoke-Tests` (`hyperdot.ps1:317`) loads `quarantine.json` and clears the results folder, except `hyperdot.log`.
- It then calls `Invoke-TestRunnerWithRetry` for each runner. That wraps `Invoke-TestRunner` (`lib/Runners.ps1:90`) and reruns a failing runner up to `-Retry` more times.
- `Invoke-TestRunner` switches on the runner:
  - `dotnet` and `gdunit4` run `dotnet test` with a generated `godot.runsettings` and a TRX logger. The runsettings pass `GODOT_BIN` and `--headless`.
  - `godottest` runs `godot --headless --path P [scene] --run-tests[=filter] --quit-on-finish`. Its log is converted to JUnit. With coverage it runs under `coverlet`.
  - `gut` runs `godot --headless -s addons/gut/gut_cmdln.gd -gexit -gjunit_xml_file=…`.
  - `validate` and `flows` run `-s tools/validate.gd` or `tools/flows.gd`. Their markers in the log are parsed into JUnit.
  - `smoke` runs `--quit-after N` and scans the log for errors.
  - `juice`, `playthrough`, `architecture`, `l10n`, `data`, `layout` and `textsize` call their own `lib/*.ps1` runners.

**Outputs**
- Each runner writes `<Results>/<runner>/` with its TRX or JUnit XML, its log, and optionally `findings.json`, `glyphs.json`, `coverage/*.cobertura.xml`, and `<runner>.attemptN` folders from retries.
- `Write-TestSummary` and `Write-RunSummary` write the run summary.
- A run-history entry is written for the failure delta.
- `-Json` adds `runnerResults`, `flaky`, `quarantined`, `failureDelta` and `coverage` fields.
- If any runner failed, the run stops with `tests-failed`.
