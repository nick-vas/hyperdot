**Organization:** `examples/gdscript/` holds the game code (`score.gd`, `main.gd`) and a `test/` folder. `test/` has a single GUT suite, `test_score.gd`, and `test/flows/startup.flow.json`, which is a flow definition run by `flows.gd`. I didn't open the flow file.

**Naming:** Suite files are named `test_*.gd`. Each one starts with `extends GutTest`. Test methods are named `test_<behaviour>`, for example `test_every_fifth_hit_raises_the_multiplier` and `test_miss_resets_combo`. They use GUT assertions such as `assert_eq`.

**Discovery:** `Get-GutTestFiles` in `ci/godot/lib/Detect.ps1` scans the project's `*.gd` files for a line matching `^extends\s+GutTest`. The file name doesn't matter to this scan. The `test_*.gd` convention is only documented in the header comment of `Runners.ps1`. The kit picks the `gut` runner when it finds such files, or a `.gutconfig.json`.

**Running:** `ci/godot/lib/Runners.ps1`, in the `'gut'` case, does the following:
- It requires `addons/gut/gut_cmdln.gd` and fails with "addons/gut is missing" if the file is absent.
- It runs Godot with `--headless --path <project> -s addons/gut/gut_cmdln.gd -gexit -gdisable_colors`.
- It adds `-gjunit_xml_file=<ResultsDir>/gut.junit.xml`.
- Without a `.gutconfig.json`, it passes one `-gdir=res://…` for every folder that holds a GutTest script. If the file exists, GUT uses that config instead.
- `-Filter` becomes `-gunit_test_name=`.
- The output goes to `gut.log`, and the JUnit XML is what the kit reports on.

You start it with `pwsh ci/godot/hyperdot.ps1 test -Project examples/gdscript`.
