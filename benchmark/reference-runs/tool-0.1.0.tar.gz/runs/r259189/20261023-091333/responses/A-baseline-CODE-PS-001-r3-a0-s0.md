```powershell
function Invoke-TestRunner {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Project,
        [Parameter(Mandatory)][scriptblock]$Command,
        [int]$TimeoutSec = 600
    )

    Set-StrictMode -Version 3.0
    $ErrorActionPreference = 'Stop'

    if (-not (Test-Path -LiteralPath $Project -PathType Container)) {
        Stop-GodotCi "Project folder not found: $Project" 'project-not-found'
    }

    Write-Host "Running $Name tests in $Project"   # log to host/stderr, never Write-Output

    $watch = [System.Diagnostics.Stopwatch]::StartNew()
    $lines = @()
    $exit  = 0
    try {
        Push-Location -LiteralPath $Project
        try {
            $lines = @(& $Command 2>&1 | ForEach-Object { "$_" })
            $exit  = $LASTEXITCODE
        }
        finally {
            Pop-Location
        }
    }
    catch {
        Stop-GodotCi "Runner $Name crashed: $($_.Exception.Message)" 'runner-crashed'
    }
    $watch.Stop()

    if ($null -eq $exit) { $exit = 0 }

    $result = [pscustomobject]@{
        runner     = $Name
        passed     = ($exit -eq 0)
        exitCode   = $exit
        durationMs = [int]$watch.ElapsedMilliseconds
        output     = $lines
    }

    Set-JsonField -Name "runner_$Name" -Value $result
    return $result
}
```

Notes:
- `Stop-GodotCi` reports failures with stable codes. Add `project-not-found` and `runner-crashed` to `docs/json.md`, since codes are API.
- The helper returns its value as the pipeline output, with no `Write-Output`.
- `$TimeoutSec` is declared but not enforced. Drop it, or wire it to the process time limit helper, before using this.
- I haven't run this, and I assumed `Set-JsonField`'s signature is `-Name`/`-Value`. Check that against `Common.ps1` first.
