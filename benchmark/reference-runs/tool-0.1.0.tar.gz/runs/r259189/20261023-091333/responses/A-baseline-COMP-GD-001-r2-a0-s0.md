**Organization:** `examples/gdscript` is a small game (`score.gd`, `main.gd`, `main.tscn`). Its tests live in one `test/` folder. That folder holds `test_score.gd` and `flows/startup.flow.json`. The JSON file is a flow scenario for the `flows` runner, not a GUT test.

**Naming:** Test files are named `test_*.gd`. Each one `extends GutTest`. Test functions are named `test_<behaviour>`, for example `test_miss_resets_combo`. The three tests in `test_score.gd` cover:
- the combo multiplier
- the combo reset on a miss
- the main scene scoring on ready (it loads `res://main.tscn` with `add_child_autofree`)

**Discovery:** The `gut` runner in `ci/godot/lib/Runners.ps1` handles discovery.
- If `.gutconfig.json` exists, GUT uses it.
- Otherwise `Get-GutTestFiles` finds every script that extends `GutTest`. The kit passes each containing folder as a `-gdir=res://…` argument.

**Execution:** The kit runs Godot headless with `--path <project> -s addons/gut/gut_cmdln.gd -gexit -gdisable_colors`. It adds `-gjunit_xml_file=<ResultsDir>/gut.junit.xml`. The output goes to `gut.log`. `-Filter` becomes `-gunit_test_name=`. The runner stops with an error if `addons/gut/gut_cmdln.gd` is missing. The `test` command is `pwsh ci/godot/hyperdot.ps1 test -Project examples/gdscript`. The results are the JUnit XML and the log.
