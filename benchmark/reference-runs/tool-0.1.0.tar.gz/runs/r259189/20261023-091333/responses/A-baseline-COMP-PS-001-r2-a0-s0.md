The `test` command runs through `ci/godot/hyperdot.ps1`. I read `hyperdot.ps1`, `lib/Runners.ps1` and the function list in `lib/Detect.ps1`. I didn't run it, and I didn't read the body of `Get-ProjectInfo`, so how it picks each runner is unconfirmed.

**Entry.** `-Command` defaults to `test`. The script dot-sources every `lib/*.ps1` (line 189), then the dispatch at line 575 runs `Invoke-Setup; Invoke-Build; Invoke-Tests`. Before that, line 544 calls `Assert-SafeToClear $Results`, which refuses a results folder that would delete the project or the current folder (`unsafe-results-dir`).

**Detection.** `Get-ProjectInfo` in `Detect.ps1` uses `Find-GodotProject`, `Find-Solution`, `Find-GoDotTestScene` and `Get-GutTestFiles`. It returns `ProjectDir`, `Solution`, the Godot version and `Runners`. If you pass `-Runners`, it uses your list. Setup then finds or downloads Godot and exposes it as `$env:GODOT_BIN`, and Build imports the project.

**Invoking runners.** `Invoke-Tests` does the following:
1. It loads `quarantine.json`.
2. It wipes the results folder, except `hyperdot.log`.
3. It calls `Invoke-TestRunnerWithRetry` for each runner, which wraps `Invoke-TestRunner`.

The `switch` in `Invoke-TestRunner` handles each runner differently:
- **`dotnet` and `gdunit4`** run `dotnet test` with generated run settings. `gdunit4` first checks the `.csproj` references `gdUnit4.test.adapter`.
- **`godottest`** runs Godot with `--headless --run-tests`. With coverage it goes through `coverlet`.
- **`gut`** runs Godot with `-s addons/gut/gut_cmdln.gd` and `-gjunit_xml_file`.
- **`validate` and `flows`** run Godot with `-s tools/validate.gd` or `tools/flows.gd`.
- **`smoke`** runs `--quit-after <Frames>`.
- **The other runners** (`juice`, `playthrough`, `architecture`, `l10n`, `data`, `layout`, `textsize`) call their own `Invoke-*Runner` functions.

**Outputs.** In `<Results>/<runner>/` a run writes:
- a log file such as `gut.log` or `smoke.log`
- `*.junit.xml`
- `coverage/*.cobertura.xml` when coverage is on
- `findings.json` and `glyphs.json` for some runners
- `<runner>.attempt<N>` folders for failed retries

After the runners finish, `Write-RunSummary` writes the summary and `Set-TestRunHistory` records the run for the failure delta. The `-Json` fields include `resultsDir`, `runnerResults`, `coverage`, `failureDelta`, `flaky` and `quarantined`. A failed runner stops the run with `tests-failed`.
