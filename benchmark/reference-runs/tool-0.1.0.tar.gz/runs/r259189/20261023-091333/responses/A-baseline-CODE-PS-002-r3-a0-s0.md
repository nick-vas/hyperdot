```diff
--- a/ci/godot/hyperdot.ps1
+++ b/ci/godot/hyperdot.ps1
@@ -58,6 +58,7 @@
     # Collect coverage (dotnet, gdunit4, godottest) into one report.
     [switch]$Coverage,
     # Fail when line coverage is below this percentage (implies -Coverage).
+    [ValidateRange(0, 100)]
     [double]$MinCoverage = 0,
```

I haven't run this. `-MinCoverage` is a percentage, so a value outside 0–100 makes no sense. A negative value never fails the check, and a value over 100 always fails it. With `ValidateRange(0, 100)`, PowerShell rejects those values when it binds the parameter. The default of 0 stays valid.
