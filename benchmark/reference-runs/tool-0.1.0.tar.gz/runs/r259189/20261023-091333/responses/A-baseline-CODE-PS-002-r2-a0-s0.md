```diff
--- a/ci/godot/hyperdot.ps1
+++ b/ci/godot/hyperdot.ps1
@@ -73,5 +73,6 @@
     [string]$Results = 'test-results',
     [string]$Output = 'build',
     # Frames the smoke runner plays, launched exports play, and shot waits before each screenshot.
+    [ValidateRange(1, 1000000)]
     [int]$Frames = 120,
```

`-Frames` is an `[int]` with no validation, so `0` or a negative value reaches the smoke runner, the launched exports and `shot`. `ValidateRange(1, 1000000)` rejects those at parameter binding. The default of 120 is unchanged.

I haven't run this or checked whether any caller or test passes `-Frames 0`.
