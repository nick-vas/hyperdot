The GDScript example keeps its tests in `examples/gdscript/test/`. I read `test_score.gd` and the runner code; I didn't run anything.

- **Organization:** `test/test_score.gd` holds the unit tests for `score.gd` and `main.gd`. `test/flows/startup.flow.json` is a separate flow definition for the `flows` runner, not a GUT test.
- **Naming:** The files are `test_*.gd`. Each starts with `extends GutTest`. Test methods are named `test_<behavior>`, for example `test_miss_resets_combo`.
- **Discovery:** Detection works on file content, not names. `Get-GutTestFiles` (`ci/godot/lib/Detect.ps1:56`) scans the project's `.gd` files for a line matching `^extends\s+GutTest`. `Find-ProjectFiles` does the scan and skips folders that contain a `.gdignore`.
- **Execution:** The `gut` runner in `ci/godot/lib/Runners.ps1:135` requires `addons/gut/gut_cmdln.gd`, and fails with "addons/gut is missing" otherwise. It then runs Godot with these arguments:
  - `--headless --path <project> -s addons/gut/gut_cmdln.gd -gexit -gdisable_colors`
  - `-gjunit_xml_file=<ResultsDir>/gut.junit.xml`
- **Directories:** If the project has a `.gutconfig.json`, GUT reads it. Otherwise the runner adds a `-gdir=res://…` argument for every folder that holds a GutTest script.
- **Filter:** `-Filter` becomes `-gunit_test_name`.
- **Output:** The log goes to `gut.log`, and the results are JUnit XML.
- **Entry point:** `pwsh ci/godot/hyperdot.ps1 test -Project examples/gdscript`.
