**Rules before pushing** (`.github/workflows/self-test.yml` runs them all, so this is the local subset):

**If you change a file under `ci/godot/lib/`:**
- Run `pwsh tests/Test-LibNames.ps1` (function names must be unique and must not clash with aliases).
- Run the self-test for the concern you touched, using the "Self-tests" table. For example, Juice → `Test-JuiceLog.ps1`, Plan → `Test-Plan.ps1`, Credits → `Test-Credits.ps1`. Check the table's "Needs" column. Godot-based tests need Godot, and display-based ones need `Xvfb :99 &` with `DISPLAY=:99`.
- Run `pwsh ci/godot/hyperdot.ps1 test -Project examples/csharp/game` and `test -Project examples/gdscript`. Both must be green. Also run `doctor` on both, and it must be green.
- If you add a `Stop-GodotCi` code, add it to `docs/json.md`. Never rename existing codes.
- If you change plan behavior, check `plan` as the Plan step of `self-test.yml` does. Copy `examples/gdscript` to a temp folder, run `git init`, run `plan -Do init -Project <copy>`, then run `plan -Json -Project <copy>`. Expect phase `concept` and at least one next action.

**If you change a skill under `.agents/skills/*/SKILL.md`:**
- Run `pwsh ci/godot/tools/Test-Skills.ps1`.
- Run `pwsh tests/Test-SkillFixtures.ps1`.
- If the skill quotes a shader, run `pwsh tests/Test-SkillShaders.ps1` (needs Godot).
- Run `pwsh tests/Test-DocLinks.ps1` for links and quoted paths.
- Check that the description says only when to use the skill, never how. Check that every quoted command, flag, code or version matches the script, `docs/json.md` and `examples/csharp`.
- If the skill mentions agent instructions or flags, also run `pwsh tests/Test-Context.ps1`.

**If you change a page under `docs/`:**
- Run `pwsh tests/Test-DocLinks.ps1`.
- If it is `docs/json.md` (the output contract), check it against the error codes and fields in the code.
- If it is agent-instruction docs, also run `pwsh tests/Test-Context.ps1`.
