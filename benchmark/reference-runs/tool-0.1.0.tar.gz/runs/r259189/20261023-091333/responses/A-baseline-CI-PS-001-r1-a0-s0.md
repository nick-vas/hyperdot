- **Scope context with a short map:** Keep `AGENTS.md` to layout and rules only, and move the self-test table and Targets into `docs/`. Add per-folder notes (`ci/godot/lib/`, `tests/`) so agents read one concern file instead of scanning all 30+ `lib/*.ps1` files.

- **Template the prompts:** Ship fixed task prompts, such as "fix failing `test`", "add a self-test" and "bump a version matrix entry". Each names the exact command, the fixture folder and the done-check. That cuts exploration turns and keeps the stable prefix cacheable.

- **Cache the stable prefix and the downloads:** Put `AGENTS.md`, the skills and the command reference first in every prompt and keep them byte-stable, so prompt caching hits. In CI, cache the Godot download, the .NET restore and the Playwright browser keyed on the version pins, which saves time.

- **Cap output size:** Default agents to `-Json` and have the verifier subagent return only `ok`, the error `code` and the first N failures. Write full logs to a file and read them on demand. Truncate GUT, dotnet and Godot logs to the failing section, and use the failure delta in place of full reports.

- **Run only what changed:** Map changed paths to the matching `tests/Test-*.ps1` script, using the existing table as data. Run the full `self-test.yml` only before merge. Skip `bench`, `shot` and Web jobs, which need a display or browser, unless the diff touches them.
