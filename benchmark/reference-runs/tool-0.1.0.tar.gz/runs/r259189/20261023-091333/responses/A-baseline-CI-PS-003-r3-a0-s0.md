Rules drawn from AGENTS.md (I didn't run anything).

**Change under `ci/godot/lib/*.ps1`**
- Always run `pwsh tests/Test-LibNames.ps1`. It checks that function names are unique and don't clash with aliases.
- Always run `pwsh ci/godot/hyperdot.ps1 test -Project examples/csharp/game` and `... test -Project examples/gdscript`. Both must be green, and `doctor` must be green on both.
- Then run the self-test for the concern you changed, using the table. Examples: `Audio.ps1` → `Test-Audio.ps1`; `Soak.ps1` → `Test-Soak.ps1`; `Credits.ps1` → `Test-Credits.ps1`.
- If you changed `Plan.ps1`, also check `plan` the way the Plan step of `self-test.yml` does. Copy `examples/gdscript` to a temporary folder, run `git init` on it, run `plan -Do init -Project <copy>`, then `plan -Json -Project <copy>`. Expect phase `concept` and at least one next action.
- If the script needs a display (`bench`, `shot`, `audio -Mix`), start `Xvfb :99 &` and set `DISPLAY=:99`. Don't use `xvfb-run`.
- If you added or changed a `Stop-GodotCi` code, update `docs/json.md`. Never rename a code.
- If you changed a version matrix entry, re-run both example projects on that Godot.

**Change to a skill (`.agents/skills/*/SKILL.md`)**
- Run `pwsh ci/godot/tools/Test-Skills.ps1` and `pwsh tests/Test-SkillFixtures.ps1`. Both must pass.
- Check that any commands, flags, error codes or versions quoted in the skill match the real script, `docs/json.md` and `examples/csharp`.
- The description must say only when to use the skill, not how.
- If the skill quotes shaders, run `Test-SkillShaders.ps1`.
- Also run `Test-Context.ps1` and `Test-DocLinks.ps1`, since they check skills against the kit's real flags and links.

**Change to a page under `docs/`**
- Run `pwsh tests/Test-DocLinks.ps1`.
- Run `Test-Context.ps1` if the page names kit flags.
- If you edited `docs/json.md`, check that it still matches the error codes in the scripts.
