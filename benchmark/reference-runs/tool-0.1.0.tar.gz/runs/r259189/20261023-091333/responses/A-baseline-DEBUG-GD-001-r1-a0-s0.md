Five likely causes of flaky GDScript tests in this kit's CI, each with a mitigation. I answered from the repo guidance in AGENTS.md and did not inspect the code.

1. **Scene `_ready` timing.** Scripts run inside Godot with `-s` can't see what a scene sets up until the first frame. A test that reads state straight after `add_child` passes or fails depending on timing.
   *Mitigation:* `await process_frame` after `add_child`, as AGENTS.md says. Do the same in GUT tests, with `await wait_frames(1)`.

2. **Missing display on Linux runners.** Tests that touch rendering, viewports or input behave differently, or crash, without a display.
   *Mitigation:* Start `Xvfb :99 &` and set `DISPLAY=:99`. Don't use `xvfb-run`, which merges stderr into stdout and breaks `-Json`.

3. **Stale import cache or `.tres` keys.** Resources imported on a cold runner can differ from a warm one, and stale `.tres` keys load inconsistently.
   *Mitigation:* Run `validate` first, since it flags stale `.tres` keys. Run the import step before `test`. The kit already repeats crashed imports and exports, which helps.

4. **Real-time waits, randomness and shared state.** Timers, `randf()`, wall-clock delays and singletons or autoloads that carry state between tests behave differently on slow shared runners.
   *Mitigation:* Seed the RNG, drive time by frames or a fake clock, and reset autoloads in GUT's `before_each`/`after_each`.

5. **Runner load and process time limits.** Slow runners push tests over the time limit or past a hang.
   *Mitigation:* Use `test -Retry` with `quarantine.json` (covered by `Test-Flaky.ps1`) to contain known flakes. Use the failure delta against the previous run to separate new breakage from flakes. Check `status` for test duration trends. Fix the root cause of each quarantined test rather than leaving it there.
