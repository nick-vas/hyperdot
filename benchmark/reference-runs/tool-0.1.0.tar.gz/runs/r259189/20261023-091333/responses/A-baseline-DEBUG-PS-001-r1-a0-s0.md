Only the process time limit is confirmed in the code. I read `Get-ProcessTimeout` in `ci/godot/lib/Common.ps1`. For the other four, the guards come from `AGENTS.md` and its self-test table, and I didn't open those files.

1. **Deadlocked or never-resuming Godot process.** This covers a hung await, a deadlock, or a headless process that never quits. Guard: `Get-ProcessTimeout` and `Invoke-Logged` in `Common.ps1`. The default limit is 1800 s. The process tree is killed and the run returns 124. Mitigation: set `HYPERDOT_TIMEOUT` lower, for example 300. `0` disables the limit, so don't use it. `Test-ProcessTimeout.ps1` covers this.

2. **Godot crashing or stalling during import or export.** Mitigation: the crash-retry logic repeats a crashed import or export. `Test-CrashRetry.ps1` covers it. Cap the retries and keep the timeout from cause 1 active.

3. **Flaky or order-dependent tests that stall.** Guard: `test -Retry` plus `quarantine.json`. Mitigation: quarantine the offending test id and fix its await or signal.

4. **Missing display for `bench`, `shot` and `audio -Mix`.** These wait or fail without a display. Mitigation: start `Xvfb :99 &` and set `DISPLAY=:99`. Don't use `xvfb-run`, which merges stderr into stdout and breaks `-Json`.

5. **Network and long-lived child servers.** This covers the Godot download in setup and `soak` servers that ignore SIGTERM. Guard: the `download-failed` code, covered by `Test-DownloadFailed.ps1`, which takes about 15 s. `Test-Soak.ps1` uses a C# server that catches SIGTERM. Mitigation: make the server shut down on SIGTERM, and rely on the timeout's process-tree kill. For downloads, use a cached Godot install.
