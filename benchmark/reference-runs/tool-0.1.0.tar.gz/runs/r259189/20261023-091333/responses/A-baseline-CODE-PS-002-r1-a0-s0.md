```diff
--- a/ci/godot/hyperdot.ps1
+++ b/ci/godot/hyperdot.ps1
@@ -58,5 +58,6 @@
     [switch]$Coverage,
     # Fail when line coverage is below this percentage (implies -Coverage).
+    [ValidateRange(0, 100)]
     [double]$MinCoverage = 0,
```
