- **Scope context with a short root index.** Trim `AGENTS.md` to layout and rules only, and move the 45-row self-test table to `docs/self-tests.md`. Agents then load it only when they change something that needs a self-test.

- **Run only the relevant self-test.** Have a "changed path → test script" map (for example `lib/Audio.ps1` → `Test-Audio.ps1`). Agents then skip the whole suite, and CI can gate jobs with path filters.

- **Use fixed prompt templates.** Give the `godot-verifier` and `godot-architect` subagents a fixed prompt with a JSON-only reply (status, codes, failing files). That stops free-form re-explaining and long retellings of logs.

- **Cache the expensive setup.** Cache the downloaded Godot, export templates, NuGet packages and Playwright browsers, keyed on the pinned versions. Put the stable instructions (AGENTS.md, skills) first in the prompt so the prompt cache hits, and keep volatile output such as logs and diffs last.

- **Cap output size.** Always pass `-Json` and add a `-Summary` or `-Limit` mode that returns only the failure delta and the first N errors, with the full log written to a file path. Have the PR comment and Stop hook read that summary rather than raw Godot output. The page-limited PR comment already does this for the comment.
