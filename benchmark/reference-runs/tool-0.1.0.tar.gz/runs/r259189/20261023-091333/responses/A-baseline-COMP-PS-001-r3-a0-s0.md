`hyperdot.ps1 test` runs setup, then build, then the tests.

**Entry.** `ci/godot/hyperdot.ps1` defaults `-Command` to `test`. The dispatch at line 575 is `Invoke-Setup; Invoke-Build; Invoke-Tests`. Setup finds or downloads Godot and exports `GODOT_BIN`. Build imports the project. Before the tests, `Assert-SafeToClear` refuses a `-Results` folder that would delete the working directory or the project.

**Detection.** `Get-ProjectInfo` in `lib/Detect.ps1` resolves the project directory (`-Project` or `Find-GodotProject`), the `.sln`/`.csproj` and the Godot version. Unless `-Runners` is given, it picks runners from what is in the project:
- `validate` and `architecture` are always selected.
- `dotnet` is added when a csproj references `Microsoft.NET.Test.Sdk` or `gdUnit4.test.adapter`.
- `godottest` is added when the game csproj references Chickensoft.GoDotTest.
- `gut` is added when a script extends GutTest.
- `flows` is added for `*.flow.json` files.
- `smoke` is added when `run/main_scene` is set.
- `juice`, `playthrough`, `data`, `textsize` and `layout` are added when their `<name>.json` file exists.
- `l10n` is added when the project has translation sources.

`-Runners none` selects nothing, and an unknown runner name fails with `invalid-arguments`.

**Execution.** `Invoke-Tests` in `hyperdot.ps1` reads `quarantine.json` and wipes the results folder. It then calls `Invoke-TestRunnerWithRetry`, which calls `Invoke-TestRunner` in `lib/Runners.ps1` once per runner. Each runner works differently:
- `dotnet` and `gdunit4` run `dotnet test`.
- `godottest` runs `godot --headless --path <project> --run-tests`, or the same command wrapped in coverlet when coverage is on.
- `gut` runs `godot --headless -s addons/gut/gut_cmdln.gd`.
- `validate` and `flows` run `godot --headless -s tools/validate.gd` and `tools/flows.gd`.
- `smoke` runs `godot --headless --quit-after <Frames>`.
- `juice`, `playthrough`, `architecture`, `l10n`, `data`, `layout` and `textsize` call their own `Invoke-*Runner` functions.

**Outputs.** Each runner gets `<Results>/<runner>/` holding its log (for example `gut.log` or `smoke.log`) and a `*.junit.xml`. It may also hold `findings.json` and `glyphs.json`. Failed retry attempts are kept as `<runner>.attempt<N>`. Coverage goes to `coverage/*.cobertura.xml`. At the top level there is `hyperdot.log` and a run summary. The run history is updated, and `-Json` fields such as `runnerResults` and `failureDelta` are set. If any runner fails, the script stops with `tests-failed`.
