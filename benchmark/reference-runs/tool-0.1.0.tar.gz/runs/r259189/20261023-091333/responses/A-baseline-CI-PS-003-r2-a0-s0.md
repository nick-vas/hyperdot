**Rules before pushing** (CI runs all of them via `.github/workflows/self-test.yml`, but run what you touched first):

**If you change a file in `ci/godot/lib/`:**
- Always run `pwsh tests/Test-LibNames.ps1`, which checks that function names are unique and don't clash with aliases.
- Then run the self-test for the concern you changed, using the table in AGENTS.md. Examples: `Audio.ps1` → `Test-Audio.ps1`. `Soak.ps1` → `Test-Soak.ps1`. `Plan.ps1` → `Test-Plan.ps1`. `Credits.ps1` → `Test-Credits.ps1`. Check "Needs" first: Godot, a display (start `Xvfb :99 &` and set `DISPLAY=:99`), or ffmpeg.
- If the change affects `test`, `doctor` or the other core flow, run `pwsh ci/godot/hyperdot.ps1 test -Project examples/csharp/game` and `... test -Project examples/gdscript`. Both must be green, and `doctor` must be green on both.
- If you add a `Stop-GodotCi` code, add it to `docs/json.md`.

**If you change a skill (`.agents/skills/*/SKILL.md`):**
- Run `pwsh ci/godot/tools/Test-Skills.ps1` and `pwsh tests/Test-SkillFixtures.ps1`. Both must pass.
- Run `pwsh tests/Test-DocLinks.ps1`.
- Run `pwsh tests/Test-Context.ps1` if the skill quotes kit flags.
- Run `pwsh tests/Test-SkillShaders.ps1` (needs Godot) if the skill quotes shaders.
- Check that any commands, flags, error codes or versions quoted in the skill match the real script, `docs/json.md` and `examples/csharp`.
- The description says only when to use the skill, never how.

**If you change a page under `docs/`:**
- Run `pwsh tests/Test-DocLinks.ps1` for links and quoted paths.
- Run `pwsh tests/Test-Context.ps1`, which holds the docs to the kit's real flags.
- If you edit `docs/json.md`, it is the output contract. Keep error codes stable and never rename them.
