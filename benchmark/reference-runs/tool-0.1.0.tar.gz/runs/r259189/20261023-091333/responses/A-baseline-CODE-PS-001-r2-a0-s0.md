```powershell
function Invoke-TestRunner {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Project,
        [Parameter(Mandatory)][scriptblock]$Command,
        [int]$TimeoutSeconds = 600
    )
    Set-StrictMode -Version 3.0
    $ErrorActionPreference = 'Stop'

    if (-not (Test-Path -LiteralPath $Project -PathType Container)) {
        Stop-GodotCi "Project folder not found: $Project" 'project-not-found'
    }

    Write-CiLog "Running $Name runner in $Project"   # Write-Host/stderr, safe under -Json

    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $lines = @()
    $exit = 0
    try {
        Push-Location -LiteralPath $Project
        $job = Start-Job -ScriptBlock $Command
        if (-not (Wait-Job $job -Timeout $TimeoutSeconds)) {
            Stop-Job $job
            Remove-Job $job -Force
            Stop-GodotCi "$Name runner exceeded $TimeoutSeconds s" 'process-timeout'
        }
        $lines = @(Receive-Job $job 2>&1 | ForEach-Object { "$_" })
        $exit = if ($job.State -eq 'Completed') { 0 } else { 1 }
        Remove-Job $job -Force
    }
    finally {
        Pop-Location
        $sw.Stop()
    }

    foreach ($line in $lines) { Write-Host $line }

    $result = [pscustomobject]@{
        runner   = $Name
        passed   = ($exit -eq 0)
        exitCode = $exit
        seconds  = [math]::Round($sw.Elapsed.TotalSeconds, 2)
        lines    = $lines.Count
    }
    return $result
}
```

Notes on conventions followed:
- Strict mode 3.0 and `$ErrorActionPreference = 'Stop'`.
- Failures go through `Stop-GodotCi "message" 'stable-code'`. Any new codes (`project-not-found`, and `process-timeout` if it isn't already in use) must be added to `docs/json.md`, and never renamed.
- Output is logged with `Write-Host`/`Write-CiLog` only, with no `Write-Output`. The result is returned as the single pipeline value.
- Results that may be empty or single are wrapped in `@(...)`.
- The function name uses Verb-Noun form, so it avoids the short-alias collisions. Check that it's unique with `Test-LibNames.ps1`.
- A caller would attach the result with `Set-JsonField` for the `-Json` output.
