# Token benchmark 20261023-091335

Model claude-haiku-5-5, 3 run(s) per task and profile, 24 session(s), CLI 2.1.309 (Claude Code), without the plugin.
Tokens include cache reads and writes; cost is Claude Code's own figure. Medians leave out sessions stopped at the time limit, whose spend is unknown (the "Unknown" column).

| Profile | Runs | Success % | Median tokens | P90 tokens | Median output | Median turns | Median cost | Total cost | Successes per $ | Median time (s) | Retries | Unknown |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| A-baseline | 24 | 91.7 | 59,310 | 224,864 | 2,026 | 3.5 | $0.0031 | $0.0966 | 227.63 | 11.4 | 0 | 0 |

| Task | Profile | Successes | Median tokens | Median cost | Failures |
|---|---|---:|---:|---:|---|
| COMP-PS-001 | A-baseline | 3/3 | 224,864 | $0.0091 |  |
| COMP-GD-001 | A-baseline | 3/3 | 72,739 | $0.0029 |  |
| CODE-PS-001 | A-baseline | 3/3 | 22,290 | $0.0029 |  |
| CODE-PS-002 | A-baseline | 3/3 | 94,906 | $0.0045 |  |
| DEBUG-PS-001 | A-baseline | 3/3 | 67,498 | $0.0039 |  |
| DEBUG-GD-001 | A-baseline | 2/3 | 44,384 | $0.0021 | 272 words, limit 260 |
| CI-PS-001 | A-baseline | 2/3 | 21,486 | $0.0010 | missing 're:\bscop(e/ed)\b' |
| CI-PS-003 | A-baseline | 3/3 | 22,474 | $0.0016 |  |
