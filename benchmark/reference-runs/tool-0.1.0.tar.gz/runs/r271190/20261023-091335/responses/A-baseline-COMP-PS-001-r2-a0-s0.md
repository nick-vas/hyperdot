**Entry point:** `ci/godot/hyperdot.ps1` takes `-Command` (default `test`). It loads the `lib/*.ps1` files, then calls `Get-ProjectInfo` (`lib/Detect.ps1`) and logs the project, Godot version and runners. `Assert-SafeToClear` refuses to wipe `-Results`, and `Start-RunLog` opens `hyperdot.log`. The `test` case runs `Invoke-Setup`, then `Invoke-Build`, then `Invoke-Tests`.

**Detection:** Without `-Runners`, `Get-ProjectInfo` always adds `validate` and `architecture`. It then adds `dotnet` (a solution referencing a test SDK or gdUnit4), `godottest` (`Chickensoft.GoDotTest` in the game's csproj), `gut` (GutTest scripts), `flows` (`*.flow.json`), `smoke` (a `run/main_scene`), and `juice`, `playthrough`, `l10n`, `data`, `textsize` or `layout` when their JSON config exists. `none` selects nothing.

**Build step:** `Invoke-Build` installs GUT if needed, runs `dotnet build` for C# projects, then `godot --headless --import`, retrying only on crashes.

**Per-runner Godot calls** (`Invoke-TestRunner`, `lib/Runners.ps1`):
- `dotnet`/`gdunit4`: `dotnet test` with a generated `godot.runsettings`.
- `godottest`: `godot --headless --path P <scene> --run-tests --quit-on-finish`.
- `gut`: `godot --headless -s addons/gut/gut_cmdln.gd -gexit`, with `-gdir` for each test folder.
- `validate`, `flows`: `godot --headless -s tools/*.gd`, parsed from markers.
- `smoke`: `--quit-after <frames>`.

**Output:** Each runner writes to `<Results>/<runner>/`, usually a JUnit XML file. The run writes `summary.json` and `summary.md`, merges coverage if collected, and records a run history. Results are wiped at the start, except `hyperdot.log`. A failing runner stops the run with `tests-failed`.
