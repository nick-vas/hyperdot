```powershell
function Invoke-TestRunner {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$FilePath,
        [string[]]$ArgumentList = @(),
        [string]$WorkingDirectory = (Get-Location).Path
    )

    if (-not (Get-Command $FilePath -ErrorAction SilentlyContinue)) {
        Stop-GodotCi "Test runner '$Name' not found: $FilePath" 'runner-not-found'
    }

    Write-CiLog "Running $Name: $FilePath $($ArgumentList -join ' ')"
    $started = Get-Date

    Push-Location $WorkingDirectory
    try {
        $output = @(& $FilePath @ArgumentList 2>&1 | ForEach-Object { "$_" })
        $exitCode = $LASTEXITCODE
    }
    finally {
        Pop-Location
    }

    [pscustomobject]@{
        name     = $Name
        exitCode = $exitCode
        passed   = ($exitCode -eq 0)
        seconds  = [math]::Round(((Get-Date) - $started).TotalSeconds, 1)
        output   = $output
    }
}
```

Add `runner-not-found` to `docs/json.md` before merging, since stable codes are API. The caller decides whether to pass the result to `Set-JsonField`.
