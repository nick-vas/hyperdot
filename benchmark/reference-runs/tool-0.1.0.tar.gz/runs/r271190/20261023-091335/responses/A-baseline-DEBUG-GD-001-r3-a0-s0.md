1. **Frame-timing races.** A test reads scene state before `_ready` has run, or awaits a fixed frame count, so it passes on a fast machine and fails on a slow runner. *Mitigation:* `await get_tree().process_frame` after every `add_child`, as AGENTS.md requires, and wait on signals with a timeout instead of fixed frame counts.

2. **Unseeded randomness.** Spawns, drops or AI choices differ run to run. *Mitigation:* seed `RandomNumberGenerator` in `before_each` and print the seed in failure messages so a red run can be replayed.

3. **State leaking between tests.** GUT runs every test in one Godot process, so autoloads, singletons or nodes left over from an earlier test change the next one's result. *Mitigation:* reset autoload state and `queue_free` nodes in `after_each`. `-Retry` will hide this, so it is not a fix.

4. **Shared network ports and timeouts.** ENet or multiplayer tests (the `soak-fixture` pattern) collide when jobs share a port or time out on a loaded runner. *Mitigation:* bind port 0 or a per-test port, and scale timeouts for CI rather than hard-coding local values.

5. **Frame-rate-dependent physics or float asserts.** Assertions on `_process` deltas, physics positions or exact floats differ with the runner's frame rate. *Mitigation:* step physics for a fixed number of ticks and compare with a tolerance, such as `assert_almost_eq`.

Triage with `test -Retry 2`: anything listed in `flaky[]` or in `status -Json` `flakyTests` is a real signal. Quarantine it in `quarantine.json` with an owner and a `yyyy-MM-dd` `until` date, and fix it before that date.

These causes come from the repository's docs and code, not from a failing run I observed; I did not run the test suite.
