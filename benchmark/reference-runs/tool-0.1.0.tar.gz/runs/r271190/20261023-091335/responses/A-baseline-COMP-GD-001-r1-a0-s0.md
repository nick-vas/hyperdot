The GDScript example has one GUT test file, `examples/gdscript/test/test_score.gd`, which `extends GutTest`. It has three tests, all named `test_*`: two unit tests of `Score` (`test_every_fifth_hit_raises_the_multiplier`, `test_miss_resets_combo`) and one scene test that loads `res://main.tscn` and checks the score is above zero on ready.

Discovery is by content, not location. `Get-GutTestFiles` (`ci/godot/lib/Detect.ps1:56`) finds any `.gd` file with a line starting `extends GutTest`. The example has no `.gutconfig.json`, so the GUT runner (`ci/godot/lib/Runners.ps1:135`) passes each folder containing such a file as `-gdir=`, and runs `addons/gut/gut_cmdln.gd` headless with `-gexit` and a JUnit XML report. `-Filter` maps to `-gunit_test_name`. The `addons/gut` folder isn't in the example; the kit installs it.

Doctor warns about GUT test files not named `test_*.gd`, since GUT skips them. The `test/flows/startup.flow.json` file is not a GUT input.
