**Five likely causes of a hanging test run, with mitigations** (from reading the code; I did not run anything)

1. **A test awaits a signal that never fires.** Guard: `Invoke-Logged` in `ci/godot/lib/Common.ps1` stops the process and its children after `Get-ProcessTimeout` (1800 s default, exit 124). Mitigation: set `HYPERDOT_TIMEOUT` to 120–300 locally so an agent isn't stuck for 30 minutes.

2. **gdUnit4Net's in-Godot rebuild or `dotnet build` stalls.** Guard: `ci/godot/lib/Runners.ps1` sets `CompileProcessTimeout` to 180000 ms and `TestSessionTimeout` to 1800000 ms. The adapter's own first-run build limit is a fixed 30 s that the kit cannot change. Mitigation: rerun once; `docs/godot-pipelines.md` reports that the second run usually passes.

3. **No display for scene tools.** Godot opens a window and stalls or fails when there is no display. Guard: none beyond the process timeout. Mitigation: start `Xvfb :99 &` and set `DISPLAY=:99`, as `AGENTS.md` says for `bench`, `shot` and `audio -Mix`.

4. **A web export test waits on a page that never settles.** Guard: `ci/godot/tools/web-smoke.mjs` uses `--timeout` (60000 ms default) for navigation and `waitForFunction`. Mitigation: raise `--timeout` for slow runners, and keep `HYPERDOT_TIMEOUT` above it.

5. **A child process keeps stdout or stderr open after the parent should finish.** Guard: `Invoke-Logged` reads both streams asynchronously, which avoids the pipe-buffer deadlock, and breaks out when the process has exited (`Common.ps1`:214–216). Mitigation: if a run stays open after Godot exits, look for a leftover `dotnet` build-server process holding the pipes.
