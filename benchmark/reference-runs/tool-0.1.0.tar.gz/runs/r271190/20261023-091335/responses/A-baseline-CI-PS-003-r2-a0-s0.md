**Every change:** `pwsh ci/godot/hyperdot.ps1 test -Project examples/csharp/game` and `test -Project examples/gdscript` must be green, and `doctor` must be green on both.

**If you change `ci/godot/lib/<Concern>.ps1`:**
- Run that concern's row from the self-test table, for example Audio → `Test-Audio.ps1`, Juice → `Test-JuiceLog.ps1`, Plan → `Test-Plan.ps1`, Web → `Test-Web.ps1`, Sfx → `Test-Sfx.ps1`, Context → `Test-Context.ps1`. Doctor's checks map to `Test-Addons.ps1`, `Test-Platforms.ps1`, `Test-RepoHygiene.ps1` and `Test-Context.ps1`.
- If you add, rename or remove a function: `Test-LibNames.ps1`.
- If you touch state paths or the old names: `Test-OldState.ps1`.
- If the test needs Godot or a display, provide them (Xvfb on `:99`, `DISPLAY=:99`).

**If you change a skill (`.agents/skills/*/SKILL.md`):**
- `pwsh ci/godot/tools/Test-Skills.ps1` and `pwsh tests/Test-SkillFixtures.ps1` must pass.
- If it quotes commands, flags, error codes or versions: `Test-Context.ps1`.
- If it quotes paths or links: `Test-DocLinks.ps1`.
- If it contains shaders: `Test-SkillShaders.ps1`. If it describes capture mode: `Test-Capture.ps1`.

**If you change a page under `docs/`:**
- `Test-DocLinks.ps1`, always.
- If it names flags or commands: `Test-Context.ps1`.
- If it covers the plan template or release timeline: `Test-Plan.ps1`.
