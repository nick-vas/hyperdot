```diff
--- a/ci/godot/hyperdot.ps1
+++ b/ci/godot/hyperdot.ps1
@@ -86,3 +86,4 @@
     [double]$Seconds = 10,
-    [double]$Warmup = 3,
+    [ValidateScript({ $_ -ge 0 })]
+    [double]$Warmup = 3,
     # bench: fail when the 99th-percentile frame time is above this many milliseconds (16.7 for 60 fps). 0: no budget.
```
