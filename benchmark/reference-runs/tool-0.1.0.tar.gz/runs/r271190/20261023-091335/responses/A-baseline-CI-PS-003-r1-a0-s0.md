**Before pushing, run these checks by what you changed:**

- **If you change `ci/godot/lib/<X>.ps1`:**
  - Run the self-test whose "Covers" row matches the file, e.g. `Plan.ps1` → `tests/Test-Plan.ps1`, `Store.ps1` → `tests/Test-Store.ps1`. Install what the "Needs" column lists.
  - If you add or rename a function, run `tests/Test-LibNames.ps1`.
  - If you add a stable error code, add it to `docs/json.md` (never rename one), then run `tests/Test-DocLinks.ps1`.
  - Run `pwsh ci/godot/hyperdot.ps1 test -Project examples/csharp/game`, the same with `examples/gdscript`, and `doctor` on both. All must be green.
  - If you change `plan`, also run its Plan step from `.github/workflows/self-test.yml` (copy the example, `git init`, `plan -Do init`, `plan -Json`).
  - If the self-test needs a display, run `Xvfb :99 &` with `DISPLAY=:99`.

- **If you change a skill (`.agents/skills/*/SKILL.md`):**
  - `pwsh ci/godot/tools/Test-Skills.ps1` and `pwsh tests/Test-SkillFixtures.ps1` must pass.
  - If it quotes shaders, run `tests/Test-SkillShaders.ps1`.
  - If it quotes commands, flags, codes or versions, run `tests/Test-Context.ps1`.
  - Run `tests/Test-DocLinks.ps1` for its links and paths.

- **If you change a page under `docs/`:**
  - Run `tests/Test-DocLinks.ps1`.
  - If it quotes flags, codes or versions, run `tests/Test-Context.ps1`.
  - If it documents a feature, also run that feature's self-test.

I did not run any of these here. This is taken from the repository's AGENTS.md, and the repository is not a git checkout.
