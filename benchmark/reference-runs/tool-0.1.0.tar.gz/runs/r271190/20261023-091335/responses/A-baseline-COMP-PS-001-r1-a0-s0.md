**Entry:** `ci/godot/hyperdot.ps1` dot-sources the `lib/*.ps1` files, then `Get-ProjectInfo` (`lib/Detect.ps1:116`) finds the project (shallowest `project.godot`), the nearest `.sln`, the Godot version, and whether a `.csproj` exists (C#).

**Runner detection:** with no `-Runners`, it always adds `validate` and `architecture`, then adds `dotnet` (a test SDK or gdUnit4 adapter in a csproj), `godottest` (Chickensoft in the game csproj), `gut` (`*.gd` extending GutTest), `flows`, `smoke` (`run/main_scene` set), `juice`, `playthrough`, `l10n`, `data`, `textsize`, `layout`, each from its config file. `-Runners none` runs none.

**Command flow:** `test` calls `Invoke-Setup`, then `Invoke-Build` (installs GUT if needed, `dotnet build` for C#, `godot --headless --import`), then `Invoke-Tests`. Tests run in order through `Invoke-TestRunnerWithRetry` → `Invoke-TestRunner` (`lib/Runners.ps1:90`). Godot is `$env:GODOT_BIN`:
- `gut`: `--headless --path … -s addons/gut/gut_cmdln.gd -gexit`
- `validate`/`flows`: `-s tools/validate.gd` or `flows.gd`
- `smoke`: `--headless --quit-after <Frames>`
- `godottest`: `--run-tests --quit-on-finish`
- `dotnet`/`gdunit4`: `dotnet test` with TRX output

**Outputs:** `test-results/<runner>/` (JUnit XML, logs, `findings.json`), merged coverage in `coverage/`, and `summary.json` / `summary.md` at the top. `-Results` is wiped each run except `hyperdot.log`. The run appends to `.godot/hyperdot-history.jsonl`, which drives the failure delta and `status`. Failures end with `tests-failed` and the result is printed via `-Json`.
