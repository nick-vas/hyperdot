```diff
--- a/ci/godot/hyperdot.ps1
+++ b/ci/godot/hyperdot.ps1
@@ -74,7 +74,8 @@
     [string]$Output = 'build',
     # Frames the smoke runner plays, launched exports play, and shot waits before each screenshot.
-    [int]$Frames = 120,
+    [ValidateRange(1, 2147483647)]
+    [int]$Frames = 120,
     # smoke: run at this fixed rate of game time (--fixed-fps), so -Frames is game time and a bot's run is the same on
     # every machine and as fast as the CPU allows. 0 (default): real time, as before.
     [int]$FixedFps = 0,
```
