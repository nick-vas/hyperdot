Five likely causes, most likely first. I read the guards in `ci/godot/lib/Common.ps1`, `Runners.ps1`, `Soak.ps1`, `ci/godot/tools/flows.gd` and `docs/godot-pipelines.md`. I did not reproduce any hang.

1. **Godot process stalls (deadlock, or headless loop that never exits).** Guard: `Get-ProcessTimeout` (`Common.ps1:173`) stops the process tree with `Kill($true)` after 1800 s by default and returns 124. Mitigation: set `HYPERDOT_TIMEOUT` lower in CI (0 disables it, so don't in CI).

2. **An `await` that never resumes** (a signal that is never emitted). Guard: the process timeout above turns the stall into a failed run, as `docs/godot-pipelines.md:97` notes. Mitigation: race each test's `await` against a timer, so the test fails in seconds with a message.

3. **C# build or test session hangs** (gdUnit4 recompiling, or a session that never ends). Guard: `CompileProcessTimeout` 180000 ms and `TestSessionTimeout` 1800000 ms in the generated config (`Runners.ps1:35,44`). Mitigation: lower `TestSessionTimeout` for the project's own test runs, since 30 minutes is long for a unit suite.

4. **A `flows` step waits for a condition that never becomes true.** Guard: each step's `timeout` key, default 300 (`flows.gd:176`). Mitigation: set a short explicit `timeout` on steps that wait for UI or network state.

5. **A soak server or flood client won't exit.** Guard: `Soak.ps1:124-150` waits for `-StopGraceSeconds`, then kills the tree and waits 5 s. On Windows there is no SIGTERM, so it kills at once. Mitigation: make the game server exit on a stop request, and keep the grace period short enough to bound the run.

Browser-side Web smoke has its own bound: `web-smoke.mjs` uses `--timeout` (default 60000 ms).
