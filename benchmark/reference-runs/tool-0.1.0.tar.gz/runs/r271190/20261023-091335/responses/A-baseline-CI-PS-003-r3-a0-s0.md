**Before pushing a change under `ci/godot/lib/`:**
- Always: `pwsh tests/Test-LibNames.ps1` (function names unique, no alias clashes).
- Always: `pwsh ci/godot/hyperdot.ps1 test -Project examples/csharp/game`, `test -Project examples/gdscript`, and `doctor` on both, all green.
- If you touched `plan`: copy `examples/gdscript` to a temp folder, `git init` it, run `plan -Do init`, then `plan -Json`. Expect phase `concept` and at least one next action.
- If you touched a subsystem with its own self-test, run it. Examples: `Test-Plan.ps1`, `Test-GameVersion.ps1`, `Test-Context.ps1`, `Test-Addons.ps1`, `Test-RepoHygiene.ps1`, `Test-Platforms.ps1`, `Test-Sfx.ps1`, `Test-Playtest.ps1`.
- If you added a `Stop-GodotCi` code: add it to `docs/json.md`, and never rename an existing code.
- If the change needs Godot or a display, run that test's row too. Start `Xvfb :99` and set `DISPLAY=:99` for display tests.

**Before pushing a change to a skill (`.agents/skills/*/SKILL.md`):**
- Always: `pwsh ci/godot/tools/Test-Skills.ps1` and `pwsh tests/Test-SkillFixtures.ps1`.
- Always: check that the description says only when to use the skill, not how.
- If it quotes commands, flags, error codes or versions: `pwsh tests/Test-Context.ps1`.
- If it quotes paths or links: `pwsh tests/Test-DocLinks.ps1`.
- If it quotes shaders: `pwsh tests/Test-SkillShaders.ps1` (needs Godot).
- If it covers capture mode: `pwsh tests/Test-Capture.ps1` (needs Godot and a display).

**Before pushing a change to a page under `docs/`:**
- Always: `pwsh tests/Test-DocLinks.ps1`.
- If it quotes flags, commands or the output contract: `pwsh tests/Test-Context.ps1`, and check `docs/json.md` against the script.

I have not run these checks. This answer is taken from `AGENTS.md`.
