The GDScript example has one GUT test file, `examples/gdscript/test/test_score.gd`, plus one flow file.

**Organization and naming:** `test_score.gd` extends `GutTest` and holds three `func test_*` methods: two unit tests on `Score` (the every-fifth-hit multiplier and the miss reset) and one scene test that loads `res://main.tscn` and checks points after ready. The example has no `.gutconfig.json`.

**Discovery:** `Get-GutTestFiles` (`ci/godot/lib/Detect.ps1:56`) finds any `.gd` file with `extends GutTest`. Detection adds the `gut` runner when such files exist, and adds `flows` when a `*.flow.json` exists. The flow file `test/flows/startup.flow.json` waits 2 seconds, then asserts `score:points > 0` on the main scene.

**Running:** The `gut` runner (`ci/godot/lib/Runners.ps1:135`) requires `addons/gut`, then runs headless Godot with `gut_cmdln.gd -gexit`. Without `.gutconfig.json`, it passes each test directory as `-gdir`. `-Filter` maps to `-gunit_test_name`, and results go to `gut.junit.xml`.
