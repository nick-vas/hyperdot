1. **Godot test awaits a signal that never fires (deadlock).** Guard: `Get-ProcessTimeout` in `ci/godot/lib/Common.ps1:173` stops any run after `HYPERDOT_TIMEOUT` seconds (default 1800) and returns 124. Mitigation: set a shorter `HYPERDOT_TIMEOUT` in CI. Avoid `0`, which disables the limit.

2. **gdUnit4Net session or compile hangs.** Guard: `ci/godot/lib/Runners.ps1:35` sets `<TestSessionTimeout>1800000</TestSessionTimeout>` and line 44 sets `<CompileProcessTimeout>180000</CompileProcessTimeout>`. Mitigation: lower these to match your slowest real run, so a stuck session fails sooner.

3. **Soak server ignores the stop request.** Guard: `ci/godot/lib/Soak.ps1:140-150` waits `StopGraceSeconds`, then calls `Kill($true)` to take the process tree down. Windows has no SIGTERM, so it always kills. Mitigation: keep the server's SIGTERM handler covered by `Test-Soak.ps1` (`soak-fixture-cs`).

4. **A flow step waits for a condition that never becomes true.** Guard: `ci/godot/tools/flows.gd:176` gives each step a `timeout` of 300 s by default. Mitigation: set an explicit `timeout` on steps that wait for slow content.

5. **Web export test hangs on page load or readiness.** Guard: `ci/godot/tools/web-smoke.mjs:17` uses `--timeout` (default 60000 ms) for `page.goto` and the ready check. Mitigation: raise `--timeout` only for slow CI runners, and check the browser console output first.

Not verified: whether `Invoke-Logged` drains both redirected pipes concurrently. If it does not, a child that fills stderr could block, and that would be a sixth cause.
