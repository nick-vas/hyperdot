```powershell
function Invoke-GodotTestRunner {
    param([Parameter(Mandatory)][string]$Runner, [Parameter(Mandatory)][string]$ProjectDir,
        [Parameter(Mandatory)][string]$ResultsDir, [Parameter(Mandatory)][string[]]$GodotArgs)

    if (-not (Test-Path -LiteralPath $ProjectDir -PathType Container)) {
        Stop-GodotCi "${Runner} runner: project folder not found: $ProjectDir"
    }
    if (Test-Path -LiteralPath $ResultsDir) { Remove-Item -Recurse -Force $ResultsDir }
    New-Item -ItemType Directory -Force $ResultsDir | Out-Null

    $log = Join-Path $ResultsDir "$Runner.log"
    Start-LogGroup $Runner
    $code = [int](Invoke-Logged $env:GODOT_BIN $GodotArgs $log)
    Stop-LogGroup

    [pscustomobject]@{
        Runner     = $Runner
        ExitCode   = $code
        Passed     = ($code -eq 0)
        Log        = $log
        ResultsDir = $ResultsDir
    }
}
```

Notes:
- The caller builds the runner-specific `$GodotArgs`, including `--headless --path <project>`, as the `gut` and `validate` cases in `ci/godot/lib/Runners.ps1` do.
- Failures use `Stop-GodotCi` with no stable code, so no new code is added to `docs/json.md`. If you add one, record it there; codes are API.
- `Invoke-Logged` and `Start-LogGroup`/`Stop-LogGroup` are the existing helpers in the repo. I took their signatures from their call sites and did not read their definitions.
- I did not run this. Add it to `ci/godot/lib/Runners.ps1` and run `pwsh tests/Test-LibNames.ps1` to check for name clashes.
