**Entry point:** `ci/godot/hyperdot.ps1` with `-Command test` (the default). It runs `Invoke-Setup`, then `Invoke-Build`, then `Invoke-Tests`. Before any of that, `Assert-SafeToClear` rejects an unsafe `-Results` folder, and `Start-RunLog` writes `hyperdot.log` into the results folder.

**Detection:** `Get-ProjectInfo` (`lib/Detect.ps1`) finds the shallowest `project.godot` (or uses `-Project`) and the nearest `.sln` that includes the `.csproj`. The Godot version comes from the csproj's `Godot.NET.Sdk`, then `GODOT_VERSION`, then 4.7.2. With no `-Runners`, it always adds `validate` and `architecture`, then adds `dotnet`, `godottest`, `gut`, `flows`, `smoke`, `juice`, `playthrough` and `l10n`/`data`/`textsize`/`layout` as the project's files call for.

**Setup and build:** `Invoke-Setup` uses `GODOT_BIN` if set, otherwise downloads Godot. `Invoke-Build` installs GUT if needed, runs `dotnet build` for C#, and runs `godot --headless --import`.

**Godot per runner:** `Invoke-TestRunner` (`lib/Runners.ps1`) switches on the runner:
- `dotnet`, `gdunit4`: `dotnet test` with a generated `godot.runsettings`, TRX output.
- `godottest`: `godot --headless --run-tests`, or coverlet around it.
- `gut`: `godot -s addons/gut/gut_cmdln.gd -gexit`, JUnit XML.
- `validate`, `flows`: `-s tools/validate.gd` or `flows.gd`, parsed from log markers.
- `smoke`: `--quit-after <frames>`.
- Others call their own `Invoke-*Runner`.

`Invoke-TestRunnerWithRetry` reruns a failing runner up to `-Retry` times and keeps earlier attempts as `<runner>.attempt<N>`.

**Outputs:** `test-results/<runner>/` (JUnit/TRX, logs, `findings.json`), `summary.json` and `summary.md`, `hyperdot.log`, and `.godot/hyperdot-history.jsonl`, which feeds failure deltas and `status`.
