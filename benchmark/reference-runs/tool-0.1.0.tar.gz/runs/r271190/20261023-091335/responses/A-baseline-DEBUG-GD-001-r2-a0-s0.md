**Five likely causes of flaky GDScript (GUT) tests in this kit's CI, each with one mitigation:**

1. **Frame-timed asserts.** Headless frame rate varies on GitHub runners, so tests that `await` a fixed number of frames or sleep for a set time pass or fail at random. *Mitigation:* await the signal the code emits, or set the runner's fixed-FPS option (`FixedFps` in `Invoke-TestRunnerWithRetry`, `ci/godot/lib/Runners.ps1`).

2. **Reading the scene before it is ready.** Scripts run through `gut_cmdln.gd` cannot see `_ready` until the first frame. *Mitigation:* `await get_tree().process_frame` after `add_child`, as the repo's AGENTS.md requires for `-s` scripts.

3. **State leaking between tests.** GUT runs every `test_*.gd` in the folders named by `-gdir`, in one process. Autoloads, singletons and files in `user://` survive from one test to the next. *Mitigation:* reset that state in `before_each`/`after_each` and give each test its own `user://` path.

4. **Unseeded randomness.** A `RandomNumberGenerator` or `randi()` without a seed gives different values on each run. *Mitigation:* call `seed()` with a fixed value in `before_each`, or assert on properties rather than exact outputs.

5. **Fixed network ports.** Soak and multiplayer tests use ENet. A busy port, or a server still shutting down from the previous test, fails the connection. *Mitigation:* bind to port 0 for an ephemeral port, and wait for the peer to disconnect before the next test.

**Triage with the kit's tools:** `test -Retry 1` tells you which tests pass only on a retry (`flaky[]`). `status -Json` lists repeat offenders in `flakyTests`. A `quarantine.json` entry (with `owner` and `until`) buys time but is not a fix.
