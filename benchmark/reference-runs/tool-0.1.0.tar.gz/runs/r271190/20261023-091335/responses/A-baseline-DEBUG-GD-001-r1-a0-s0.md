Five likely causes, each with a mitigation that uses this repo's existing tools. I didn't run anything; these come from reading `ci/godot/lib/Runners.ps1` and AGENTS.md.

1. **Frame-timing dependence.** Tests that wait on real time (`create_timer`, `delta` sums) pass on fast machines and fail on loaded runners. Mitigation: use signals and `await process_frame`, and keep the `-FixedFps` path that `Runners.ps1` already passes to the runner.

2. **Reading scene state before `_ready`.** Scripts run through GUT see nothing the scene sets up until the first frame. Mitigation: `await process_frame` after `add_child`, before any assertion.

3. **State leaking between tests.** Autoloads, singletons, and files in `user://` survive from one GUT test to the next, so results depend on order. Mitigation: reset that state in `before_each` and `after_each`, and check that the failing test passes alone with `-Filter`.

4. **Display and rendering differences.** Headless and Xvfb rendering vary between runs, and `shot` and `bench` depend on the display. Mitigation: keep the `DISPLAY=:99` Xvfb setup consistent, and keep pixel-exact checks out of unit tests.

5. **Unseeded randomness and fixed network ports.** Unseeded RNG and ENet tests (`soak`) that reuse ports collide or diverge between runs. Mitigation: seed the RNG per test and bind to a free ephemeral port.

Triage: `test -Retry N` reruns the whole runner, so it hides flakiness rather than fixing it. Use it only as a bridge. Put a test in `quarantine.json` only with an owner and an issue, and check `status`'s `recurringErrors` and `Test-Flaky.ps1` to confirm the fix.
