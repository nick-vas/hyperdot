```powershell
function Invoke-TestRunner {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$FilePath,
        [string[]]$Arguments = @(),
        [string]$WorkingDirectory = $PWD.Path
    )

    # 'runner-not-found' must exist in docs/json.md
    $exe = Get-Command -Name $FilePath -CommandType Application, ExternalScript -ErrorAction SilentlyContinue
    if (-not $exe) {
        Stop-GodotCi "Test runner '$Name' not found: $FilePath" 'runner-not-found'
    }

    Write-CiLog "Running $Name"
    $clock = [System.Diagnostics.Stopwatch]::StartNew()
    Push-Location -LiteralPath $WorkingDirectory
    try {
        $lines = @(& $exe.Source @Arguments 2>&1 | ForEach-Object { "$_" })
        $code = $LASTEXITCODE
    }
    finally {
        Pop-Location
    }

    [pscustomobject]@{
        Name     = $Name
        Passed   = ($code -eq 0)
        ExitCode = $code
        Seconds  = [math]::Round($clock.Elapsed.TotalSeconds, 1)
        Output   = $lines
    }
}
```
