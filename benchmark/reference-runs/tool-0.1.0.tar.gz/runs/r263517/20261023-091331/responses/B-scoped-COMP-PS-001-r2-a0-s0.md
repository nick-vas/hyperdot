**Entry.** `ci/godot/hyperdot.ps1` defaults `-Command` to `test`. It dot-sources every `lib/*.ps1` and calls `Get-ProjectInfo` (`Detect.ps1:116`) to build `$info`. The `test` branch (`hyperdot.ps1:575`) runs `Invoke-Setup; Invoke-Build; Invoke-Tests`. Setup finds or downloads Godot and sets `GODOT_BIN`. Build imports the project and compiles C#. Before the run, `Assert-SafeToClear` guards `-Results`, which is wiped except for `hyperdot.log`.

**Detection.** `Get-ProjectInfo` resolves `project.godot`, the `.sln`, the Godot version and whether the project is C#. Without `-Runners` it always selects `validate` and `architecture`. It adds the others when it finds their markers:
- `dotnet`: the test SDK or gdUnit4 adapter in a csproj.
- `godottest`: Chickensoft.GoDotTest in the game csproj.
- `gut`: scripts that extend GutTest.
- `flows`: `*.flow.json` files.
- `smoke`: `run/main_scene` set.
- `juice`, `playthrough`, `data`, `textsize` and `layout`: a `<name>.json` file of the same name.
- `l10n`: translation CSV, PO or remap files.

Unknown runner names fail with `invalid-arguments`.

**Invocation.** `Invoke-Tests` loops over the runners through `Invoke-TestRunnerWithRetry`, which wraps `Invoke-TestRunner` (`Runners.ps1:90`). Each runner gets `<results>/<runner>/`.
- `dotnet` and `gdunit4`: `dotnet test` with a TRX logger and run settings.
- `godottest`: `godot --headless --path … --run-tests --quit-on-finish`, wrapped in coverlet when coverage is on.
- `gut`: `godot --headless -s addons/gut/gut_cmdln.gd -gexit -gjunit_xml_file=…`.
- `validate` and `flows`: `godot --headless -s tools/validate.gd` or `flows.gd`.
- `smoke`: `godot --headless --quit-after <frames>`.
- Other runners (`juice`, `playthrough`, `architecture`, `l10n`, `data`, `layout`, `textsize`) call their own `Invoke-*Runner` functions.

**Output files.**
- Per runner:
  - logs (`*.log`);
  - JUnit XML (`*.junit.xml`) or TRX;
  - `findings.json` and `glyphs.json` where the runner writes them;
  - `coverage/*.cobertura.xml`;
  - `<runner>.attempt<N>` folders when `-Retry` reruns a failed runner.
- Per run:
  - `summary.json` and `summary.md`;
  - an appended line in `.godot/hyperdot-history.jsonl`.
- With `-Json`, `resultsDir`, `runnerResults`, `failureDelta`, `flaky`, `quarantined` and `coverage` (documented in `docs/json.md`).

Failed runners stop the run with the code `tests-failed`.
