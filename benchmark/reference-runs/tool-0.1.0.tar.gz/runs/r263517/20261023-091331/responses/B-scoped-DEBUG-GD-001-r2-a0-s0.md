Five likely causes, drawn from AGENTS.md. I didn't open the other files, so none of this comes from reading the test code.

1. **Frame-timing races.** Tests read scene state before `_ready` has run. Scripts run with `-s` can't see `_ready` until the first frame. Mitigation: `await process_frame` (or GUT's `await wait_frames`) after `add_child`, and never use fixed sleeps.

2. **Display and Xvfb differences.** Rendering, `shot` and `bench` tests need a display. Linux runners have none unless Xvfb is started, so results differ between local Windows and CI. Mitigation: start `Xvfb :99 &` with `DISPLAY=:99`, not `xvfb-run`. Keep display-dependent tests separate from headless logic tests.

3. **Wall-clock and frame-rate dependence.** Timers, tweens and physics assertions on a slow shared runner see different delta times. Mitigation: drive time deterministically. Use `flows.gd` steps such as `hold`, `release` and `resize` with explicit frame counts, and assert on state, not elapsed seconds.

4. **Shared state and test order.** Autoloads, saved files, RNG seeds and leftover nodes leak between tests. Mitigation: free nodes in GUT's `after_each` (`autoqfree`), seed RNG explicitly, and reset autoloads. Use `Test-Flaky.ps1`'s `flaky-fixture` as the model for what leaks.

5. **Engine crashes, import races and timeouts.** A first-run import or an editor crash fails a test that has no bug. Mitigation: rely on the kit's crash retry and process time limit, with a `.godot` import step before `test`. Use `test -Retry` to detect flakiness. List known-flaky tests in `quarantine.json` so they're reported but don't block, and fix them rather than leaving them there.
