Retry is already validated. I'll use MinCoverage, which is a percentage.

```diff
--- a/ci/godot/hyperdot.ps1
+++ b/ci/godot/hyperdot.ps1
@@ -58,5 +58,6 @@
     # Collect coverage (dotnet, gdunit4, godottest) into one report.
     [switch]$Coverage,
     # Fail when line coverage is below this percentage (implies -Coverage).
+    [ValidateRange(0, 100)]
     [double]$MinCoverage = 0,
```
