1. **Godot or the test host stalls with no output.** Guard: `Get-ProcessTimeout` and `Invoke-Process` in `Common.ps1:172-235`. The default is 1800 s, then `Kill($true)` stops the whole process tree and the run exits 124. Mitigation: set `HYPERDOT_TIMEOUT` lower, for example 300, for fast suites. `0` turns the guard off, so don't use it.

2. **gdUnit4Net rebuild or test session never finishes.** Guard: `Runners.ps1:35,44` sets `TestSessionTimeout` to 1800000 ms and `CompileProcessTimeout` to 180000 ms. Mitigation: lower `TestSessionTimeout` to below `HYPERDOT_TIMEOUT`. The runner then reports which test hung, not just an exit 124.

3. **Missing display for `bench`, `shot` or `audio -Mix`.** Nothing in `Common.ps1` or `Runners.ps1` guards against this. Mitigation: run `Xvfb :99 &` and set `DISPLAY=:99`. Don't use `xvfb-run`, which merges stderr into stdout and breaks `-Json`.

4. **Godot crashes or deadlocks during import or export.** Guard: the crash retry in `Common.ps1:253` ("retry n of 2"), covered by `Test-CrashRetry.ps1`. Mitigation: run `import` once before the tests so the first test run doesn't pay for it. A deadlocked import is still caught by the timeout in cause 1.

5. **Retries multiply the wait for a flaky or hanging test.** `Invoke-TestRunnerWithRetry` (`Runners.ps1:236`) reruns the whole runner up to `-Retry` more times. If each attempt hits the timeout, the total is (Retry+1) × timeout. Mitigation: keep `-Retry` at 0 or 1 in CI, quarantine the flaky test in `quarantine.json`, and set the job-level `timeout-minutes` in the workflow. I didn't open `self-test.yml`, so I haven't confirmed it sets one.

I also didn't check whether a child process that outlives its parent, such as the soak fixture's server, is covered. `Test-Soak.ps1` is the place to look for that.
