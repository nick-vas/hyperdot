**Change under `ci/godot/lib/*.ps1`:**
- Always run `pwsh tests/Test-LibNames.ps1`, because function names must be unique and must not clash with aliases.
- Always run `pwsh ci/godot/hyperdot.ps1 test -Project examples/csharp/game` and `... test -Project examples/gdscript`. Both must be green, and `doctor` must be green on both.
- Then run the self-test for the concern you touched, using the table in AGENTS.md. For example:
  - Audio.ps1: `Test-Audio.ps1`
  - Plan.ps1: `Test-Plan.ps1`
  - Credits.ps1: `Test-Credits.ps1`
  - Soak.ps1: `Test-Soak.ps1`
  - Doctor.ps1: the doctor-related tests (`Test-Store.ps1`, `Test-Platforms.ps1`, `Test-Addons.ps1`, `Test-RepoHygiene.ps1`, `Test-Context.ps1`)
- If you changed Plan.ps1, also run the plan check the way the Plan step of `self-test.yml` does:
  1. Copy `examples/gdscript` to a temporary folder and `git init` it.
  2. Run `plan -Do init -Project <copy>`.
  3. Run `plan -Json -Project <copy>`. It must report phase `concept` and at least one next action.
- If you added a stable error code, add it to `docs/json.md`.
- If you changed a version matrix entry, re-run both example projects on that Godot version.

**Change to a skill (`.agents/skills/*/SKILL.md`):**
- Run `pwsh ci/godot/tools/Test-Skills.ps1` and `pwsh tests/Test-SkillFixtures.ps1`.
- If the skill quotes a shader, run `Test-SkillShaders.ps1`.
- If it quotes paths or links, run `Test-DocLinks.ps1`.
- If it quotes commands or flags, run `Test-Context.ps1`. Also check them by hand against the real script, `docs/json.md` and `examples/csharp`.
- The skill description must say only when to use the skill, never how.

**Change to `docs/`:**
- Run `pwsh tests/Test-DocLinks.ps1` for links and quoted paths.
- If the page quotes kit flags or commands, also run `Test-Context.ps1`.
- If you changed `docs/json.md`, make sure the codes match the script. Codes are API, so never rename them.

Before pushing, check `.github/workflows/self-test.yml`, which runs every self-test. I did not read it. These rules come only from AGENTS.md.
