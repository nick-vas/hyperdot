**Layout and naming**
- `examples/gdscript/test/` has one GUT suite, `test_score.gd`, plus its `.uid` file.
- The suite starts with `extends GutTest`.
- Test methods are named `test_<behaviour>`, for example `test_every_fifth_hit_raises_the_multiplier` and `test_miss_resets_combo`.
- `test/flows/startup.flow.json` is a separate input for the `flows` runner, not a GUT test.
- `project.godot` has no GUT or test settings.

**Discovery** (`Detect.ps1`)
- `Get-GutTestFiles` scans the project's `*.gd` files. It uses `Find-ProjectFiles`, which skips folders that contain a `.gdignore`.
- It keeps files that match `^extends\s+GutTest\b`. The file name and folder don't matter.
- If at least one file matches, the `gut` runner is selected automatically. A name can also be passed explicitly. `gut` is in the list of valid runner names.

**Running** (`Runners.ps1`, `'gut'` case)
- The runner stops with an error if `addons/gut/gut_cmdln.gd` is missing.
- It runs Godot headless: `--headless --path <project> -s addons/gut/gut_cmdln.gd -gexit -gdisable_colors -gjunit_xml_file=<ResultsDir>/gut.junit.xml`.
- If there is no `.gutconfig.json`, it adds a `-gdir=res://…` argument for each distinct folder that holds a GutTest script. If `.gutconfig.json` exists, GUT reads its settings from that file.
- `-Filter` becomes `-gunit_test_name=<Filter>`.
- Output goes to `gut.log`, and the results are in the JUnit XML.
