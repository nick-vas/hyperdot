```diff
--- a/ci/godot/hyperdot.ps1
+++ b/ci/godot/hyperdot.ps1
@@ -58,5 +58,6 @@
     [switch]$Coverage,
     # Fail when line coverage is below this percentage (implies -Coverage).
+    [ValidateRange(0, 100)]
     [double]$MinCoverage = 0,
```

I haven't run this. `-MinCoverage` is a percentage but accepts any number today, so `-MinCoverage 150` can never pass and `-MinCoverage -5` always does. The default of 0 is within the range.
