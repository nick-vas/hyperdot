**Change under `ci/godot/lib/*.ps1`:**
- Run `pwsh ci/godot/hyperdot.ps1 test -Project examples/csharp/game` and `... test -Project examples/gdscript`. Both must be green.
- Run `doctor` on both examples. Both must be green.
- Run `pwsh tests/Test-LibNames.ps1` whenever you add or rename a function. It checks that names are unique and don't clash with aliases.
- Run the self-test for the concern you touched, using the table in AGENTS.md:
  - `Plan.ps1` → `Test-Plan.ps1`
  - `Audio.ps1` → `Test-Audio.ps1`
  - `Credits.ps1` → `Test-Credits.ps1`
  - `Soak.ps1` → `Test-Soak.ps1`
  - `Context.ps1` → `Test-Context.ps1`
  - and so on for the others.
- If you added or changed an error code, update `docs/json.md`. Codes are API, so never rename one. Then run `Test-DocLinks.ps1`.
- If the change touches `plan`, copy `examples/gdscript` to a temporary folder, run `git init` there, then run `plan -Do init -Project <copy>` and `plan -Json -Project <copy>`. Expect phase `concept` and at least one next action.
- If you changed a version matrix entry, re-run both example `test` and `doctor` commands on that Godot version.

**Change to a skill (`.agents/skills/*/SKILL.md`):**
- Run `pwsh ci/godot/tools/Test-Skills.ps1` and `pwsh tests/Test-SkillFixtures.ps1`.
- Run `Test-Context.ps1`, because it holds skills to the kit's real flags.
- Run `Test-DocLinks.ps1`.
- If the skill quotes a shader, also run `Test-SkillShaders.ps1`.
- Check that every command, flag, error code and version quoted in the skill matches the script, `docs/json.md` and `examples/csharp`.
- The description must say only when to use the skill, never how.

**Change under `docs/`:**
- Run `pwsh tests/Test-DocLinks.ps1`.
- Run `Test-Context.ps1` if the page quotes kit flags.
- If you edited `docs/json.md`, check that it still matches the script's codes and fields.

**Before pushing any of these:**
- `.github/workflows/self-test.yml` runs every self-test, so run the ones that cover your change locally first.
- Tests that need a display need `Xvfb :99 &` and `DISPLAY=:99`. Don't use `xvfb-run`.
