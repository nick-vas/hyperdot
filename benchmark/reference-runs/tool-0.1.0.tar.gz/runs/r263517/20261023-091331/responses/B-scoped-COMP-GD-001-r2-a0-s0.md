**Organization and naming**
- `examples/gdscript/test/` has one test script, `test_score.gd`, plus its `.uid` file.
- It also has `flows/startup.flow.json`, which is not a GUT test. The `flows` runner uses it.
- Test files are named `test_*.gd`.
- `project.godot` has no GUT, enabled-plugin or autoload entries (my grep found none). Discovery doesn't depend on it.

**Discovery**
- `Get-GutTestFiles` (`Detect.ps1:56`) scans the project's `.gd` files with `Find-ProjectFiles`. It keeps any file whose text matches `^extends\s+GutTest\b`. The file name and folder don't matter.
- `Detect.ps1:141` selects the `gut` runner when at least one such file exists.

**How the kit runs them** (`Runners.ps1:135`)
- It fails with `Stop-GodotCi` if `addons/gut/gut_cmdln.gd` is missing.
- It launches Godot with `--headless --path <project> -s addons/gut/gut_cmdln.gd -gexit -gdisable_colors -gjunit_xml_file=<ResultsDir>/gut.junit.xml`.
- If `.gutconfig.json` exists, GUT uses it. Otherwise the kit adds a `-gdir=res://…` argument for every folder that holds a GutTest script.
- `-Filter` becomes `-gunit_test_name=<Filter>`.
- Output goes to `gut.log` via `Invoke-Logged`, inside a 'GUT' log group. The JUnit XML is what gets summarized.
