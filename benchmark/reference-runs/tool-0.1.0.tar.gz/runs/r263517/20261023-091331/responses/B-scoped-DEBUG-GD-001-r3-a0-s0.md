1. **Frame-timing races in scene setup.** Scripts run inside Godot can't see a scene's `_ready` until the first frame, so tests that read state right after `add_child` get stale values. Mitigation: `await process_frame` after `add_child`, the pattern `flows.gd` and the other `tools/*.gd` scripts use. Do the same in `examples/gdscript/test`.

2. **Timing-based waits on slow Linux runners.** Fixed `wait_seconds` or physics-tick counts pass locally on Windows but miss on shared GitHub runners. Mitigation: wait on signals or a state condition (GUT `wait_for_signal`, `wait_until`) with generous timeouts, not durations.

3. **Shared state between tests.** Autoloads, static variables, saved files and RNG carry over between tests, so results depend on order. Mitigation: free nodes in `after_each`, reset autoloads, and seed the RNG explicitly. Pass `-Retry` to `test` to expose order-dependent failures.

4. **Unstable first-run import and cache.** On a clean runner, `.godot` is empty. A first import that is incomplete or crashes causes missing resources and class names. Mitigation: run the kit's import step before `test`, which already repeats a crashed import (`Test-CrashRetry.ps1`). Cache `.godot` in `self-test.yml`.

5. **Headless and display differences.** Tests touching rendering, viewport size, input or audio behave differently without a display, since `bench` and `shot` need Xvfb. Mitigation: start `Xvfb :99 &` and set `DISPLAY=:99` (not `xvfb-run`, which breaks `-Json`) for display-dependent tests, and fix the window size via the `flows.gd` `resize` step.

Quarantine confirmed flaky tests in `quarantine.json` (covered by `Test-Flaky.ps1`) so they don't block the build. Track them until fixed.
