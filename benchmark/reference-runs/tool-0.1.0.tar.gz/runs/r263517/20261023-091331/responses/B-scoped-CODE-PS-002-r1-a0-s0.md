```diff
--- a/ci/godot/hyperdot.ps1
+++ b/ci/godot/hyperdot.ps1
@@ -112,7 +112,9 @@
     [double]$MaxOffPalettePercent = -1,
     [double]$PaletteTolerance = 3,
     # soak: how many headless clients to start next to the one server.
+    [ValidateRange(1, 1000)]
     [int]$Clients = 4,
     # sfx: which sounds (coin, laser, explosion, powerup, hit, jump, blip; default all), how many of each from consecutive
     # seeds, and the first seed (a number or text). -Vary <file.bfxr> makes -Count variations of one sound instead,
     # each parameter moved by up to -Amount of its range. Every sound is scaled to a peak of -PeakDb dBFS.
     [string[]]$Sound,
+    [ValidateRange(1, 1000)]
     [int]$Count = 1,
```

I haven't run this or checked how `Clients` and `Count` are used downstream. The 1000 cap is my guess at a sane upper bound.
