**Flow of `hyperdot.ps1 test`** (`test` is the default `-Command`):

1. **Entry.** `hyperdot.ps1:575` runs `Invoke-Setup; Invoke-Build; Invoke-Tests`. Before that, `Assert-SafeToClear $Results` checks the results folder. Setup finds or downloads Godot and sets `GODOT_BIN`. Build compiles the project.

2. **Detection.** `Get-ProjectInfo` (`lib/Detect.ps1:116`) locates `project.godot`, the `.sln`, the Godot version and the C# status. It picks runners from `-Runners` or auto-detects them:
   - `validate` and `architecture` always run.
   - `dotnet` if a test csproj references Microsoft.NET.Test.Sdk or gdUnit4.test.adapter.
   - `godottest` for Chickensoft.GoDotTest.
   - `gut` if GUT test files exist.
   - `flows` for `*.flow.json`.
   - `smoke` if a main scene is set.
   - `juice`, `playthrough`, `data`, `textsize` and `layout`, each when its `<name>.json` exists.
   - `l10n` if translations exist.
   - Unknown names fail with `invalid-arguments`.

3. **Running.** `Invoke-Tests` (`hyperdot.ps1:317`) reads `quarantine.json`, clears the results folder, then calls `Invoke-TestRunnerWithRetry` for each runner. That wraps `Invoke-TestRunner` (`lib/Runners.ps1:90`):
   - `dotnet` and `gdunit4`: `dotnet test` with run settings.
   - `godottest`: `godot --headless --path <p> [scene] --run-tests --quit-on-finish`, optionally wrapped in coverlet.
   - `gut`: `godot --headless -s addons/gut/gut_cmdln.gd -gexit`.
   - `validate` and `flows`: `godot --headless -s tools/validate.gd` and `tools/flows.gd`.
   - `smoke`: `godot --headless --quit-after <Frames>`.
   - The rest call their own `Invoke-*Runner` functions.

4. **Reporting.** `Write-TestSummary` parses the JUnit or TRX output (`lib/Report.ps1`). Then `Write-RunSummary`, `Get-FailureDelta` and `Set-TestRunHistory` run, and `Set-JsonField` fills in the `-Json` result. A failed runner stops the run with `tests-failed`.

**Files produced**, under `<Results>/<runner>/`:
- Logs: `hyperdot.log`, `<runner>.log`.
- JUnit XML: `gut.junit.xml`, `validate.junit.xml`, `flows.junit.xml`, `smoke.junit.xml`, `godottest.junit.xml`. The dotnet runners produce TRX.
- `findings.json` and `glyphs.json`, from some runners.
- `coverage/*.cobertura.xml`.
- Top level: `summary.json` and `summary.md`.
- In the project: `.godot/hyperdot-history.jsonl`.
