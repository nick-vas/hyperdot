```powershell
function Invoke-GutRunner([string]$Project, [string]$ResultsDir, [string]$Filter) {
    $gut = Join-Path $Project 'addons/gut/gut_cmdln.gd'
    if (-not (Test-Path -LiteralPath $gut)) { Stop-GodotCi "gut runner: addons/gut is missing" 'gut-missing' }

    $junit = Join-Path $ResultsDir 'gut.junit.xml'
    $gutArgs = @('--headless', '--path', $Project, '-s', 'addons/gut/gut_cmdln.gd', '-gexit', '-gdisable_colors',
        "-gjunit_xml_file=$junit")
    if ($Filter) { $gutArgs += "-gunit_test_name=$Filter" }

    Start-LogGroup 'GUT'
    $code = Invoke-Logged $env:GODOT_BIN $gutArgs (Join-Path $ResultsDir 'gut.log')
    Stop-LogGroup

    Write-CiLog "GUT exited with $code"
    return [pscustomobject]@{
        Runner  = 'gut'
        Code    = $code
        Passed  = ($code -eq 0)
        Results = $junit
    }
}
```

I modelled it on the `gut` branch of `Invoke-TestRunner` in `Runners.ps1`. I didn't run it. Two things to check: the `gut-missing` code is a new one, so per AGENTS.md it needs an entry in `docs/json.md` (the existing code there fails with the default `failed` code). I also assumed `$env:GODOT_BIN` is set, as `Invoke-GodotRetried` does by default.

- **Failures:** a missing runner calls `Stop-GodotCi` with a stable code. It does not throw.
- **Output:** the function has no `Write-Output`. Logging goes through `Write-CiLog`, and the single `return` is the only pipeline output.
- **Strict mode:** every variable is assigned before use. `$Filter` is only read in an `if`, so an empty value is safe.
