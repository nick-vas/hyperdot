**Flow of `test`** (`ci/godot/hyperdot.ps1`; `test` is the default `-Command`)

1. **Entry:** the script dot-sources every `lib/*.ps1`. It builds `$info` with `Get-ProjectInfo` (`Detect.ps1:116`). For `test` it clears the results folder (`Assert-SafeToClear`) and then runs `Invoke-Setup; Invoke-Build; Invoke-Tests` (line 575). Setup is the Godot download or lookup, which sets `$env:GODOT_BIN`.

2. **Detection:** `Get-ProjectInfo` resolves the project dir, which must contain `project.godot`. It also finds the `.sln`, the Godot version and whether the project is C#. If `-Runners` is not given, it picks:
   - `validate` and `architecture` for every project.
   - `dotnet` if a csproj references Test.Sdk or the gdUnit4 adapter.
   - `godottest` if the game csproj references Chickensoft.GoDotTest.
   - `gut` if GutTest scripts exist.
   - `flows` if `*.flow.json` files exist.
   - `smoke` if `run/main_scene` is set.
   - `juice`, `playthrough`, `data`, `textsize` and `layout` if the matching `<name>.json` exists.
   - `l10n` if translation sources exist.

   `none` selects nothing, and unknown names fail with `invalid-arguments`.

3. **Execution:** `Invoke-Tests` reads `quarantine.json` and runs each runner through `Invoke-TestRunnerWithRetry`, which calls `Invoke-TestRunner` (`Runners.ps1:90`):
   - `dotnet` and `gdunit4` run `dotnet test` with run settings, and Godot is not launched directly.
   - `godottest` runs `godot --headless --path <p> [scene] --run-tests --quit-on-finish`, wrapped in coverlet when coverage is on.
   - `gut` runs `godot --headless -s addons/gut/gut_cmdln.gd -gexit -gjunit_xml_file=…`.
   - `validate` and `flows` run `godot --headless -s tools/validate.gd` or `tools/flows.gd`.
   - `smoke` runs `godot --headless --quit-after <frames>`.
   - `architecture`, `juice`, `playthrough`, `l10n`, `data`, `layout` and `textsize` have their own `Invoke-*Runner` functions.

4. **Reporting:** `Write-TestSummary` (`Report.ps1`) parses the JUnit and TRX files. Then `Write-RunSummary`, the failure delta, run history, `Set-JsonField` and `-Json` output follow. A failing runner stops the run with `tests-failed`.

**Files produced** (under `<Results>/<runner>/`):
- logs: `godottest.log`, `gut.log`, `validate.log`, `flows.log`, `smoke.log`
- results: `*.junit.xml`, `.trx`, `findings.json`, `glyphs.json`
- coverage: `coverage/*.cobertura.xml`
- retry attempts: `<runner>.attempt<N>`
- top level: `summary.json`, `summary.md`, `hyperdot.log`, and the run history
