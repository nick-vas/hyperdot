```powershell
function Invoke-SingleTestRunner {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$FilePath,
        [string[]]$ArgumentList = @(),
        [Parameter(Mandatory)][string]$LogFile
    )
    Set-StrictMode -Version 3.0

    if (-not (Test-Path -LiteralPath $FilePath)) {
        Stop-GodotCi "$Name runner: $FilePath not found" 'runner-missing'
    }

    Write-CiLog "Running $Name tests"
    $watch = [System.Diagnostics.Stopwatch]::StartNew()
    $code = Invoke-Logged $FilePath $ArgumentList $LogFile
    $watch.Stop()

    $result = [pscustomobject]@{
        Runner   = $Name
        ExitCode = $code
        Passed   = ($code -eq 0)
        Seconds  = [math]::Round($watch.Elapsed.TotalSeconds, 1)
        Log      = $LogFile
    }
    Set-JsonField $Name ([ordered]@{
        exitCode = $result.ExitCode
        passed   = $result.Passed
        seconds  = $result.Seconds
    })
    return $result
}
```

Notes:
- A missing runner calls `Stop-GodotCi` with a stable code (`runner-missing`). If you use that code, add it to `docs/json.md`, because codes are API.
- A failing test is not fatal here. The result carries `Passed` and `ExitCode`, and the caller decides what to do.
- The function never calls `Write-Output`. It logs with `Write-CiLog` and returns one object.
- I used `Invoke-Logged` and `Set-JsonField` as they appear in `Common.ps1`. I didn't open `Invoke-Logged`, so I haven't confirmed its signature. I only saw it called as `Invoke-Logged $FilePath $ArgumentList $LogFile`.
- I did not run the function.
