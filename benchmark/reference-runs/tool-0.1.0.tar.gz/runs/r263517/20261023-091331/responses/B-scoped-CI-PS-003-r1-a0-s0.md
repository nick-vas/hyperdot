**Change under `ci/godot/lib/`**
- Always run `pwsh ci/godot/hyperdot.ps1 test -Project examples/csharp/game` and `test -Project examples/gdscript`. Both must be green.
- Also run `doctor` on both examples. Both must be green.
- If you add or rename a function, run `pwsh tests/Test-LibNames.ps1`.
- Run the self-test for the concern you changed, picked from the AGENTS.md table. Examples: `Plan.ps1` → `Test-Plan.ps1`, `Audio.ps1` → `Test-Audio.ps1`, `Soak.ps1` → `Test-Soak.ps1`. Use `-NoGodot` where offered if there's no Godot.
- If you changed `Plan.ps1`, also run the CI plan check. Copy `examples/gdscript` to a temp folder, run `git init`, run `plan -Do init -Project <copy>`, then `plan -Json -Project <copy>`. Expect phase `concept` and at least one next action.
- If you added an error code (`Stop-GodotCi`), add it to `docs/json.md`.
- If you changed a version matrix entry, re-run both example tests on that Godot.
- If a command needs a display (`bench`, `shot`, `audio -Mix`), start `Xvfb :99 &` and set `DISPLAY=:99`.

**Change to a skill (`.agents/skills/*/SKILL.md`)**
- Run `pwsh ci/godot/tools/Test-Skills.ps1` and `pwsh tests/Test-SkillFixtures.ps1`.
- Run `Test-Context.ps1` (it holds skills to the kit's real flags) and `Test-DocLinks.ps1`.
- If the skill quotes a shader, run `Test-SkillShaders.ps1`.
- Check every command, flag, error code and version the skill quotes against the script, `docs/json.md` and `examples/csharp`.
- The description must say only when to use the skill, not how.

**Change under `docs/`**
- Run `Test-DocLinks.ps1` for links and quoted paths.
- Run `Test-Context.ps1` if the page names kit flags.
- If you changed error codes in `docs/json.md`, make sure they match the script. Codes are never renamed.

I didn't open `.github/workflows/self-test.yml`. It runs the full set in CI, so these rules come from `AGENTS.md`.
