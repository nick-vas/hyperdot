```powershell
function Invoke-SingleRunner {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Executable,
        [string[]]$Arguments = @(),
        [string]$WorkingDirectory = $PWD.Path
    )

    if (-not (Get-Command $Executable -ErrorAction SilentlyContinue)) {
        Stop-GodotCi "$Name runner: $Executable was not found" 'runner-missing'
    }

    Write-CiLog "$Name runner: $Executable $($Arguments -join ' ')"
    $started = [DateTime]::UtcNow
    Push-Location -LiteralPath $WorkingDirectory
    try {
        $output = @(& $Executable @Arguments 2>&1 | ForEach-Object { "$_" })
        $exit = $LASTEXITCODE
    }
    finally {
        Pop-Location
    }

    foreach ($line in $output) { Write-Host $line }

    $result = [ordered]@{
        name       = $Name
        ok         = ($exit -eq 0)
        exitCode   = $exit
        durationMs = [int]([DateTime]::UtcNow - $started).TotalMilliseconds
        lines      = $output.Count
    }
    Set-JsonField $Name $result
    return [pscustomobject]$result
}
```

Notes on conventions:
- Failures go through `Stop-GodotCi "message" 'stable-code'`. The code `runner-missing` is new, so add it to `docs/json.md` and never rename it later.
- The function never calls `Write-Output`. Logs use `Write-Host` and `Write-CiLog`, and the only pipeline value is the returned object.
- Output is wrapped in `@(...)` so a single line still counts as an array.
- The result is also recorded with `Set-JsonField`, which does nothing outside `-Json` mode.
- A failing test run returns `ok = $false` and leaves the caller to decide what to do. Only a missing runner stops the script.
- I didn't run it. The strict-mode and `$ErrorActionPreference` settings are assumed to come from the entry script.
