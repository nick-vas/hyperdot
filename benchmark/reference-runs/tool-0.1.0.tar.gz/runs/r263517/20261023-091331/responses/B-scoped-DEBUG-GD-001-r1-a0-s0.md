Five likely causes, each with a mitigation. I answered from AGENTS.md alone and did not open the other listed files, so none of this is checked against them.

1. **Frame-timing races.** A test reads scene state before `_ready` has run. Scripts run with `-s` can't see the scene's `_ready` until the first frame.
   Mitigation: `await process_frame` (or GUT's `await_signal`/`wait_frames`) after every `add_child`, in tests and in `tools/flows.gd` steps.

2. **Display or headless differences.** Tests that need rendering, such as viewport size or shaders, behave differently under Xvfb than locally. Using `xvfb-run` also merges stderr into stdout, which corrupts `-Json` parsing and can look like a failure.
   Mitigation: start `Xvfb :99 &` with `DISPLAY=:99`, as the self-test workflow does. Keep rendering-dependent assertions out of unit tests.

3. **Wall-clock timing and slow runners.** Tests using timers, `await get_tree().create_timer(...)`, or fixed sleeps are tight on shared Linux runners. A hung process then hits the kit's process time limit.
   Mitigation: drive time deterministically with frame counts or manual `_process(delta)` calls. Set generous per-test timeouts, and cover this path with `Test-ProcessTimeout.ps1`.

4. **Randomness and shared state.** Unseeded RNG, autoload singletons, leftover nodes, or files written to `user://` leak between tests. Test order then changes the result.
   Mitigation: call `seed()` in `before_each`, `free` or `queue_free` everything created, and reset autoloads. Use GUT's `autofree` helpers.

5. **Engine and import flakiness.** The Godot import or export step crashes intermittently, or a stale `.godot` cache or `.tres` key breaks a load.
   Mitigation: rely on the kit's crash retry (`Test-CrashRetry.ps1`) and run `validate` for stale `.tres` keys. For tests that are still flaky, use `test -Retry` and list them in `quarantine.json` (covered by `Test-Flaky.ps1`) so they're tracked rather than ignored.
