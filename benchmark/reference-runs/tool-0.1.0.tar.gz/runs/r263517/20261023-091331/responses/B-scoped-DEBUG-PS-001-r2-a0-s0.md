Five likely causes of a hanging test run, each with a mitigation:

1. **Godot or a test process never exits.** Examples are a missing `--quit-on-finish`, `-gexit` or `--quit-after`, or a scene that loops forever.
   - Existing guard: `Invoke-Logged` in `Common.ps1:183-235` kills the whole process tree after `Get-ProcessTimeout` (default 1800 s) and returns 124.
   - Mitigation: set `HYPERDOT_TIMEOUT` to a smaller value for local runs. Setting it to 0 turns the guard off, so don't.

2. **gdUnit4Net recompiles or the test session stalls.**
   - Existing guard: the generated runsettings in `Runners.ps1:35-44` set `TestSessionTimeout` to 1800000 ms and `CompileProcessTimeout` to 180000 ms.
   - Mitigation: lower these values for quick feedback, and keep `--headless` set so no window waits for input.

3. **A display-dependent step blocks (`bench`, `shot`, `audio -Mix`).** No display is available, so the process waits or fails to start.
   - Existing guard: none specific beyond the process timeout.
   - Mitigation: start `Xvfb :99 &` and set `DISPLAY=:99`. Don't use `xvfb-run`, which merges stderr into stdout and breaks `-Json`.

4. **Godot crashes at shutdown or import and leaves child processes.**
   - Existing guard: the crash-retry logic in `Common.ps1:242-253` retries up to 2 times. The `Kill($true)` call also removes child processes.
   - Mitigation: check the settings the file sets for known shutdown crashes (Android export plugin, audio stream). `Test-CrashRetry.ps1` covers this.

5. **A flaky test blocks or repeats the run, or a network wait stalls it (download of Godot or templates, ENet or `soak` servers).**
   - Existing guard: `Invoke-TestRunnerWithRetry` (`Runners.ps1:236`) with `-Retry` and `quarantine.json`. Each attempt is also bounded by the process timeout.
   - Mitigation: quarantine the flaky test and keep `-Retry` small. The retries multiply the worst case: with `-Retry 2` and the default timeout, a stuck runner can take 3 × 1800 s.
   - For downloads, the `download-failed` code is covered by `Test-DownloadFailed.ps1`. I did not read the download code, so I can't say which timeout it uses.

I only grepped `Common.ps1` and `Runners.ps1`. I did not read `self-test.yml`, so I can't say what job-level timeouts it sets.
