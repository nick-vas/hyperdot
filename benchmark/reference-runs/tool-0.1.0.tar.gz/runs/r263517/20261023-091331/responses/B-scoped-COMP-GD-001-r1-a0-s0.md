**Organization and naming**
- `examples/gdscript/test/` has one GUT suite, `test_score.gd`. It starts with `extends GutTest` and has `test_*` methods: `test_every_fifth_hit_raises_the_multiplier`, `test_miss_resets_combo` and `test_main_scene_scores_on_ready`.
- Besides it there is a `.uid` file and `test/flows/startup.flow.json`, a UI flow for the `flows` runner, not a GUT test.
- `project.godot` has no test settings.

**Discovery** (`Detect.ps1`)
- `Get-GutTestFiles` scans the project's `*.gd` files with `Find-ProjectFiles`. A file counts if a line matches `^extends\s+GutTest\b`.
- The file name and folder don't matter. The `test_` prefix is only the GUT convention.
- If at least one such file exists, `gut` joins the selected runners (`Detect.ps1:141`).

**Running** (`Runners.ps1`, `'gut'` case)
- The runner fails with `gut runner: addons/gut is missing` if `addons/gut/gut_cmdln.gd` is absent.
- It runs Godot with `--headless --path <project> -s addons/gut/gut_cmdln.gd -gexit -gdisable_colors -gjunit_xml_file=<ResultsDir>/gut.junit.xml`.
- If `.gutconfig.json` exists, GUT uses it. If not, the runner adds one `-gdir=res://…` for every folder that holds a GutTest script.
- `-Filter` becomes `-gunit_test_name=<Filter>`.
- Output goes to `gut.log` and the results to the JUnit XML in `ResultsDir`.
