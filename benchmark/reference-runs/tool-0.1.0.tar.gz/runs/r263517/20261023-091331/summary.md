# Token benchmark 20261023-091331

Model claude-sonnet-5-5, 3 run(s) per task and profile, 24 session(s), CLI 2.1.309 (Claude Code), without the plugin.
Tokens include cache reads and writes; cost is Claude Code's own figure. Medians leave out sessions stopped at the time limit, whose spend is unknown (the "Unknown" column).

| Profile | Runs | Success % | Median tokens | P90 tokens | Median output | Median turns | Median cost | Total cost | Successes per $ | Median time (s) | Retries | Unknown |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| B-scoped | 24 | 41.7 | 42,060 | 76,495 | 1,054 | 3 | $0.0269 | $0.9318 | 10.73 | 11.5 | 0 | 0 |

| Task | Profile | Successes | Median tokens | Median cost | Failures |
|---|---|---:|---:|---:|---|
| COMP-PS-001 | B-scoped | 0/3 | 76,583 | $0.0816 | 304 words, limit 240 / 296 words, limit 240 / 266 words, limit 240 |
| COMP-GD-001 | B-scoped | 3/3 | 63,871 | $0.0333 |  |
| CODE-PS-001 | B-scoped | 2/3 | 41,786 | $0.0230 | missing 'param(' |
| CODE-PS-002 | B-scoped | 3/3 | 61,440 | $0.0196 |  |
| DEBUG-PS-001 | B-scoped | 0/3 | 41,617 | $0.0256 | 301 words, limit 260 / 338 words, limit 260 / 272 words, limit 260 |
| DEBUG-GD-001 | B-scoped | 2/3 | 20,177 | $0.0105 | 280 words, limit 260 |
| CI-PS-001 | B-scoped | 0/3 | 41,155 | $0.0191 | 243 words, limit 220 / 244 words, limit 220 / 272 words, limit 220 |
| CI-PS-003 | B-scoped | 0/3 | 20,343 | $0.0122 | 278 words, limit 240 / 305 words, limit 240 / 291 words, limit 240 |
