# Token benchmark 20261023-091344

Model claude-sonnet-5-5, 3 run(s) per task and profile, 24 session(s), CLI 2.1.309 (Claude Code), with this repository loaded as a plugin (its skills).
Tokens include cache reads and writes; cost is Claude Code's own figure. Medians leave out sessions stopped at the time limit, whose spend is unknown (the "Unknown" column).

| Profile | Runs | Success % | Median tokens | P90 tokens | Median output | Median turns | Median cost | Total cost | Successes per $ | Median time (s) | Retries | Unknown |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| A-baseline | 24 | 54.2 | 59,834 | 79,701 | 874 | 2.5 | $0.0297 | $0.9501 | 13.68 | 10.0 | 0 | 0 |

| Task | Profile | Successes | Median tokens | Median cost | Failures |
|---|---|---:|---:|---:|---|
| COMP-PS-001 | A-baseline | 0/3 | 79,967 | $0.0553 | 304 words, limit 240 / 261 words, limit 240 / 312 words, limit 240 |
| COMP-GD-001 | A-baseline | 3/3 | 73,800 | $0.0300 |  |
| CODE-PS-001 | A-baseline | 2/3 | 24,052 | $0.0268 | missing 'param(' |
| CODE-PS-002 | A-baseline | 3/3 | 72,147 | $0.0200 |  |
| DEBUG-PS-001 | A-baseline | 0/3 | 74,478 | $0.0357 | 320 words, limit 260 / 314 words, limit 260 / 291 words, limit 260 |
| DEBUG-GD-001 | A-baseline | 3/3 | 23,610 | $0.0086 |  |
| CI-PS-001 | A-baseline | 1/3 | 23,488 | $0.0073 | 233 words, limit 220 / 223 words, limit 220 |
| CI-PS-003 | A-baseline | 1/3 | 23,807 | $0.0104 | 288 words, limit 240 / 261 words, limit 240 |
