Five likely causes of flaky GDScript tests (GUT) in this kit's CI, each with a mitigation. I answered from the repo guidance and did not inspect the code.

1. **First-frame races.** Scripts run with `-s` can't see a scene's `_ready` setup until the first frame. Tests that read state right after `add_child` pass or fail depending on timing.
   *Mitigation:* `await process_frame` after `add_child`. Use GUT's `await_signal` instead of fixed waits.

2. **Frame-rate and timer dependence.** Under Xvfb or a loaded Linux runner, frame times differ from a local Windows machine. Tests that use real-time timeouts or physics deltas then drift.
   *Mitigation:* Step with fixed deltas (`_physics_process(1.0/60)`). Follow the `godot-determinism` skill.

3. **Unseeded randomness.** RNG-driven procgen, loot or AI gives different results on each run.
   *Mitigation:* Seed every generator with its own stream. Print the seed on failure so the failing run can be reproduced.

4. **Leaked state between tests.** Autoloads, static variables, save files in `user://` and orphan nodes carry over from one test to the next.
   *Mitigation:* Free nodes with `autofree` or `add_child_autofree`, and reset autoloads in `before_each`. Point saves at a temp directory.

5. **Environment and display gaps.** Missing import caches, a missing `DISPLAY` or imports that crash intermittently make a run fail without any test being wrong.
   *Mitigation:* Run `hyperdot.ps1 test -Retry` and list known-flaky tests in `quarantine.json`. `Test-Flaky.ps1` covers this. Check `doctor` and the `status` `recurringErrors` field to separate real failures from environmental ones.
