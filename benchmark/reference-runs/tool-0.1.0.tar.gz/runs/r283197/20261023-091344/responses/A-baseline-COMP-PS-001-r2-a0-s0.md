Detection (`Detect.ps1`) wasn't read, so that step is described from the call sites only.

**Entry.** `ci/godot/hyperdot.ps1` defaults `-Command` to `test`. It dot-sources every `lib/*.ps1`, then runs `Invoke-Setup; Invoke-Build; Invoke-Tests` (line 575). `Assert-SafeToClear` first refuses a `-Results` folder that would delete the working directory or the project.

**Detection.** `Detect.ps1` fills `$info` with `ProjectDir`, `Solution`, `GoDotTestScene` and `Runners`. I did not read it, so I can't say how it picks them. Setup finds or downloads Godot and sets `GODOT_BIN`.

**Invoke-Tests.** If `$info.Runners` is empty, it builds only. Otherwise it:
- reads `quarantine.json`, and a broken file stops the run (`invalid-quarantine`);
- clears the results folder except `hyperdot.log`;
- calls `Invoke-TestRunnerWithRetry` for each runner, which wraps `Invoke-TestRunner` in `Runners.ps1`.

**Per runner.** Each gets `<results>/<runner>/`:
- `dotnet` and `gdunit4` run `dotnet test` on the solution or csproj, with a TRX and optional coverage.
- `godottest` runs `Godot --headless --path <proj> [scene] --run-tests --quit-on-finish`, wrapped in coverlet when coverage is on. Its log is converted to `godottest.junit.xml`.
- `gut` runs `Godot --headless -s addons/gut/gut_cmdln.gd -gexit -gjunit_xml_file=…`, writing `gut.junit.xml` and `gut.log`.
- `validate` and `flows` run `tools/validate.gd` or `tools/flows.gd` with `-s`. The log becomes `*.junit.xml` through `Write-JUnitCases`.
- Other runners are `juice`, `playthrough`, `architecture`, `l10n`, `data`, `layout` and `textsize`.

**After the runners.** The script:
- merges coverage (cobertura);
- writes the run summary and the test history;
- computes the failure delta against the previous run;
- fills `$script:JsonDoc` fields (`runnerResults`, `flaky`, `quarantined`, `failureDelta`, `coverage`, `resultsDir`);
- fails with `tests-failed`, `no-coverage` or `coverage-below-minimum`.

**Files produced.** `test-results/hyperdot.log`, `<runner>/*.log`, `*.junit.xml` or TRX, `coverage/*.cobertura.xml`, plus the summary and run history.
