```diff
--- a/ci/godot/hyperdot.ps1
+++ b/ci/godot/hyperdot.ps1
@@ -73,9 +73,11 @@
     [string]$Results = 'test-results',
     [string]$Output = 'build',
     # Frames the smoke runner plays, launched exports play, and shot waits before each screenshot.
+    [ValidateRange(1, 1000000)]
     [int]$Frames = 120,
     # smoke: run at this fixed rate of game time (--fixed-fps), so -Frames is game time and a bot's run is the same on
     # every machine and as fast as the CPU allows. 0 (default): real time, as before.
+    [ValidateRange(0, 1000)]
     [int]$FixedFps = 0,
```

I didn't run this, and I haven't checked how `Frames` and `FixedFps` are used downstream. `-Frames` currently accepts 0 or a negative number, which makes a smoke run or screenshot wait meaningless. The new range rejects those at binding time. `-FixedFps` keeps 0 meaning real time and now rejects negatives and absurd rates.
