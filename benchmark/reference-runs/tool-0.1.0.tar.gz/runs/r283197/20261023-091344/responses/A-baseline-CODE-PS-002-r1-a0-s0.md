```diff
--- a/ci/godot/hyperdot.ps1
+++ b/ci/godot/hyperdot.ps1
@@ -73,7 +73,8 @@
     [string]$Results = 'test-results',
     [string]$Output = 'build',
     # Frames the smoke runner plays, launched exports play, and shot waits before each screenshot.
-    [int]$Frames = 120,
+    [ValidateRange(1, 1000000)]
+    [int]$Frames = 120,
     # smoke: run at this fixed rate of game time (--fixed-fps), so -Frames is game time and a bot's run is the same on
     # every machine and as fast as the CPU allows. 0 (default): real time, as before.
     [int]$FixedFps = 0,
```

This rejects zero and negative `-Frames` values at parameter binding. Those values currently reach the smoke runner, `shot` and `export -Run` unchecked. The upper bound is a sanity cap. I did not run the self-tests, and I did not check whether any caller passes `-Frames 0` on purpose.
