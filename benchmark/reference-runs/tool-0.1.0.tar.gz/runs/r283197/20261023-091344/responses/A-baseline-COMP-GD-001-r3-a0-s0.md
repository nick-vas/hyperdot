**Organization and naming:** The GDScript example (`examples/gdscript`) is a single GUT suite at `test/test_score.gd`.
- It `extends GutTest`.
- Each test is a `test_*` method, for example `test_every_fifth_hit_raises_the_multiplier`.
- It uses GUT asserts such as `assert_eq` and `assert_gt`.
- `add_child_autofree` loads `main.tscn` and frees it after the test.
- UI flows are kept apart in `test/flows/startup.flow.json`, which the `flows` runner reads.

**Discovery:** The kit detects the `gut` runner by `.gutconfig.json` or by `test_*.gd` files next to a script that extends `GutTest` (`Runners.ps1:7`).
- If `.gutconfig.json` exists, GUT uses it.
- If not, `Get-GutTestFiles` finds every folder holding a `GutTest` script. Each folder is passed to GUT as a `-gdir=res://…` argument.

**Running:** `hyperdot.ps1 test -Project examples/gdscript` goes to the `gut` branch (`Runners.ps1:135-150`).
- It fails with `Stop-GodotCi` if `addons/gut/gut_cmdln.gd` is missing.
- It runs `godot --headless --path <project> -s addons/gut/gut_cmdln.gd -gexit -gdisable_colors -gjunit_xml_file=<ResultsDir>/gut.junit.xml`.
- `-Filter` becomes `-gunit_test_name=`.
- The output goes to `gut.log`, and the JUnit XML feeds the kit's report and `-Json` result.
- Separate `validate` and `flows` runners also run in the same `test` command.

I didn't check whether `addons/gut` is vendored in the example.
