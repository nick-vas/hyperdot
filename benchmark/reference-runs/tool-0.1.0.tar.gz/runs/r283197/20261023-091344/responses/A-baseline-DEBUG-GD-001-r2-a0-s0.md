Five likely causes of flaky GDScript tests under this kit's CI runs, each with one mitigation. I answered from the kit's layout in AGENTS.md and didn't open the code, so check the file names below against the repo.

1. **Scene not ready.** A test reads state before `_ready` has run. `_ready` only runs after the first frame in scripts run with `-s`. Mitigation: `await process_frame` after `add_child`, as AGENTS.md says. Use `await get_tree().process_frame` inside GUT tests.

2. **Timing and frame-rate dependence.** Tests that use timers, `wait_seconds` or real delta behave differently on slow Linux runners. Mitigation: drive time with fixed steps or `wait_frames`, never wall-clock sleeps. Raise the process time limit only as a last resort.

3. **Unseeded randomness.** Procedural or loot code gives different results on each run. Mitigation: seed every RandomNumberGenerator explicitly. The `godot-determinism` and `godot-procgen` skills cover this.

4. **Shared state between tests.** Autoloads, static variables, saved files in `user://` and leftover nodes leak from one test to the next. Mitigation: free nodes in `after_each` and reset autoloads. Use a temporary save directory, then run with `test -Retry`.

5. **Missing display or audio.** Rendering, screenshots and audio tests fail without a display. The failure depends on Xvfb start-up timing, and the runner may have no audio device. Mitigation: start `Xvfb :99 &` with `DISPLAY=:99` (not `xvfb-run`) and wait for it to be ready. Keep logic tests headless.

For confirmed flaky tests, list them in `quarantine.json` so they are tracked and don't block the run. Use `status`'s `recurringErrors` to find the repeat offenders.
