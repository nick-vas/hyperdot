The `test` command runs from `ci/godot/hyperdot.ps1`, where `-Command` defaults to `test`. The dispatch (`hyperdot.ps1:575`) is `Invoke-Setup; Invoke-Build; Invoke-Tests`. I read the dispatch, `Invoke-Tests` and `Invoke-TestRunner`. I did not open the detection code, so that part is from the `Detect` entry in the layout notes.

**Setup and detection**
- `Invoke-Setup` finds or downloads Godot and sets `GODOT_BIN`.
- Detection fills `$info` with `ProjectDir`, `Solution`, the GoDotTest scene and `Runners`. I did not confirm the detection rules.
- Before any runner starts, `Assert-SafeToClear` (line 544) refuses a `-Results` folder that would delete the working directory or the project (`unsafe-results-dir`).

**Orchestration** (`Invoke-Tests`, line 317)
- With no runners it only builds.
- It reads `quarantine.json` and stops on a broken file (`invalid-quarantine`).
- It clears the results folder except `hyperdot.log`.
- It runs each runner through `Invoke-TestRunnerWithRetry`, which handles `-Retry` and quarantine, and collects coverage if requested.
- It then writes the run summary, the failure delta against the last run, and the run history, and sets the `-Json` fields.
- It stops with `tests-failed` if any runner failed.

**Runners** (`Invoke-TestRunner`, `lib/Runners.ps1:90`). Each runner gets its own `<results>/<runner>` folder.
- `dotnet` and `gdunit4` run `dotnet test` on the solution or csproj.
- `godottest` runs Godot with `--headless --path … --run-tests --quit-on-finish`, wrapped in coverlet when coverage is on.
- `gut` runs Godot with `-s addons/gut/gut_cmdln.gd -gexit`.
- `validate` and `flows` run Godot headless with `-s tools/validate.gd` or `tools/flows.gd`.
- `smoke` runs Godot with `--quit-after <Frames>`.
- `juice`, `playthrough`, `architecture`, `l10n`, `data`, `layout` and `textsize` call their own `Invoke-*Runner` functions.

**Files produced**
- `hyperdot.log` in the results folder.
- Per-runner logs: `godottest.log`, `gut.log`, `validate.log`, `flows.log` and `smoke.log`.
- JUnit XML: `gut.junit.xml`, `validate.junit.xml`, `flows.junit.xml`, `godottest.junit.xml` and `smoke.junit.xml`. The dotnet runners write TRX.
- `coverage/*.cobertura.xml` when coverage is on.
- `findings.json` and `glyphs.json` from some runners.
- A run summary, plus the run history kept under the project.
