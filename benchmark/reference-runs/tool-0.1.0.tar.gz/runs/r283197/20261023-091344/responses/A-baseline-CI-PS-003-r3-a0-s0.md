**Rules before pushing**

**Change under `ci/godot/lib/*.ps1`**
- Run the self-test for the concern you touched, from the table: `pwsh tests/<script>`. For example, `Detect` or `Doctor` changes go to the matching `Test-*.ps1`, such as `Test-Platforms.ps1` or `Test-Store.ps1`.
- Always run `pwsh tests/Test-LibNames.ps1`. Function names must be unique across `ci/godot` and must not clash with aliases.
- Run `pwsh ci/godot/hyperdot.ps1 test -Project examples/csharp/game` and `test -Project examples/gdscript`. Both must be green, and `doctor` must be green on both.
- If you change `plan`, run `Test-Plan.ps1`. Also do the self-test.yml Plan step: copy `examples/gdscript` to a temp folder, `git init`, run `plan -Do init -Project <copy>`, then `plan -Json`. Expect phase `concept` and at least one next action.
- If you add a `Stop-GodotCi` code, add it to `docs/json.md`. Never rename one.
- If you need a display (`bench`, `shot`, `audio -Mix`), start `Xvfb :99 &` and set `DISPLAY=:99`. Don't use `xvfb-run`.

**Change to a skill (`.agents/skills/*/SKILL.md`)**
- Run `pwsh ci/godot/tools/Test-Skills.ps1` and `pwsh tests/Test-SkillFixtures.ps1`.
- Check that any command, flag, error code or version quoted in the skill matches the real script, `docs/json.md` and `examples/csharp`.
- If the skill quotes shaders, run `Test-SkillShaders.ps1`.
- Run `Test-DocLinks.ps1` and `Test-Context.ps1`.
- The description must say only when to use the skill, never how.

**Change under `docs/`**
- Run `pwsh tests/Test-DocLinks.ps1`. It checks links and quoted paths.
- Run `Test-Context.ps1`, which holds docs to the kit's real flags.
- If you change `docs/json.md`, keep it in step with the codes in the scripts.

Finally, `.github/workflows/self-test.yml` runs every self-test, so you can use it as the full list.
