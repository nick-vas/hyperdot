- **Scope context:** Keep `AGENTS.md` short and point to `docs/` and `.agents/skills/*/SKILL.md` for detail. Agents then read only the skill that matches the task, not all of the layout and the self-test table. Move the 50-row self-test table into `docs/` and tell agents to open it only when changing a runner.

- **Always use `-Json` and a narrow `-Project`:** Parse the few fields that matter (status, error code, failure delta) instead of reading full logs. Run only the self-test for the file you changed, not the whole `self-test.yml` set.

- **Prompt templates:** Give `godot-verifier` and `godot-architect` fixed, short prompts with the same prefix. Each prompt would state the goal, the allowed commands, and a required output shape of verdict, failing step and code. Keep the stable text first and the variable task last so the prompt cache hits.

- **Caching:** Cache the Godot download, the NuGet packages and the `.godot/imported` folder in CI, keyed on the pinned versions in the `Targets` section. Cache Xvfb-dependent outputs such as shot baselines too. This removes minutes of setup and the log chatter that comes with it.

- **Output size:** Cap logs at the first failure plus the last N lines. Have `test`, `doctor` and the PR comment report only deltas against the previous run, using the existing failure delta and `recurringErrors`. Page long output, and have the Stop hook print one line when everything is green.
