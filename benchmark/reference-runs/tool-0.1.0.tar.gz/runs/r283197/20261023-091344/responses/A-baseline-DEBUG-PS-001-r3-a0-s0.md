Five likely causes of a hanging test run, each with a mitigation. I read `Common.ps1` and grepped for timeouts. I didn't open the other files, so the guards named for causes 2 to 5 come from the grep output, not from reading them.

1. **Godot or the test host never exits.** An example is a scene that never quits, or a headless crash that leaves the process alive. The guard is `Get-ProcessTimeout` in `ci/godot/lib/Common.ps1`, checked in the read loop of the process runner. It kills the process tree and returns exit code 124. Mitigation: set `HYPERDOT_TIMEOUT` for a slow-but-healthy run, and make test scenes quit explicitly.

2. **A child process keeps the output pipes open.** A build server can do this after the program itself has exited. The runner already breaks out of the loop when `$process.HasExited` is true. Mitigation: `dotnet build-server shutdown` or `-nodeReuse:false` for C# runs.

3. **The final `$process.WaitForExit()` blocks.** It has no timeout, so a descendant that survives the kill could stall it. Mitigation: use a bounded `WaitForExit(ms)`, as `Soak.ps1` does. That file also uses `Kill($true)` for the whole tree.

4. **A flaky or crashing test is retried repeatedly.** `test -Retry` multiplies the run time, since each retry runs the full suite again. Mitigation: keep `-Retry` low and put known flaky tests in `quarantine.json`. `Invoke-TestRunnerWithRetry` in `Runners.ps1` reruns only failures, and the import and export crash repeat stops after three runs.

5. **Waiting on a display or network.** `bench`, `shot` and `audio -Mix` need a display, and downloads can stall. Mitigation: start `Xvfb :99 &` with `DISPLAY=:99`, not `xvfb-run`. Cache Godot downloads. The `download-failed` code from `Test-DownloadFailed.ps1` covers download failures.

The last backstop is the CI job limit: `timeout-minutes` is 60 in `godot.yml` and 45 in `self-test.yml`.
