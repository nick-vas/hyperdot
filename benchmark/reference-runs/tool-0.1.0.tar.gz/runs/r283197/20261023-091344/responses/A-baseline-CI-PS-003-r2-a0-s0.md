Rules, from AGENTS.md:

**Change under `ci/godot/lib/*.ps1`**
- If you changed any lib file, run the self-test for that concern from the table. Examples: `Audio.ps1` → `tests/Test-Audio.ps1`, `Soak.ps1` → `tests/Test-Soak.ps1`, `Credits.ps1` → `tests/Test-Credits.ps1`, `Plan.ps1` → `tests/Test-Plan.ps1`.
- If you added, renamed or removed a function, also run `tests/Test-LibNames.ps1`.
- If you added an error code, document it in `docs/json.md`. Then run `tests/Test-DocLinks.ps1`.
- Always run `pwsh ci/godot/hyperdot.ps1 test -Project examples/csharp/game` and `-Project examples/gdscript`. Both must be green, and `doctor` must be green on both.
- If you changed `Plan.ps1`, run the Plan step from `self-test.yml`. Copy `examples/gdscript` to a temp folder, run `git init`, then `plan -Do init -Project <copy>` and `plan -Json -Project <copy>`. Expect phase `concept` and at least one next action.
- If the test needs Godot or a display, start `Xvfb :99 &` and set `DISPLAY=:99`. Don't use `xvfb-run`.

**Change to a skill (`.agents/skills/*/SKILL.md`)**
- Run `pwsh ci/godot/tools/Test-Skills.ps1` and `pwsh tests/Test-SkillFixtures.ps1`. Both must pass.
- Check that every command, flag, error code and version quoted in the skill matches the real script, `docs/json.md` and `examples/csharp`.
- Keep the description to when to use the skill, never how.
- If the skill quotes shaders, run `tests/Test-SkillShaders.ps1`.
- Also run `tests/Test-Context.ps1` (it holds skills to the kit's real flags) and `tests/Test-DocLinks.ps1`.

**Change to `docs/`**
- Run `tests/Test-DocLinks.ps1` for links and quoted paths.
- If the page quotes flags or commands, or you changed `docs/json.md`, also run `tests/Test-Context.ps1`.
