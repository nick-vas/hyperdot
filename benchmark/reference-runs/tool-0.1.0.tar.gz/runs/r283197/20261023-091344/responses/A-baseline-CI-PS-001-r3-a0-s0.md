- **Scope context with layout-aware reads:** Point agents at `AGENTS.md` and one `ci/godot/lib/*.ps1` file per concern, not the whole tree. Tell them to read `docs/json.md` by section, since it's the output contract.

- **Run only the matching self-test:** Use the "Self-tests" table to pick the one `tests/Test-*.ps1` script for the change. Run the full `self-test.yml` set only in CI. Use `-NoGodot` variants where they exist to skip Godot downloads.

- **Always pass `-Json` and read specific fields:** Have agents parse `status`, `failures` and `nextActions` instead of reading raw logs. Cap Godot and dotnet log tails to the failing section.

- **Cache the heavy downloads:** Cache the Godot binary, export templates, NuGet packages and the Playwright browser in the composite action (`.github/actions/godot`), keyed on the pinned versions. This avoids repeat setup time.

- **Load skills on demand with short prompt templates:** Keep skill descriptions to "when to use" only, so the listing stays small. Keep `plan`, `AGENTS.md` and `GDD` templates terse. Give subagents (`godot-verifier`, `godot-architect`) fixed, minimal prompts. Run `test` and `doctor` on the examples once, then reuse the result. Use `bench -DryRun` and the benchmark's `-DryRun` for cost checks.
