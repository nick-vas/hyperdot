**Rules before pushing**

1. **If you change a file under `ci/godot/lib/`:**
   - Run the self-test for the concern you touched, as `pwsh tests/<script>`. Use the table. For example, `Audio.ps1` maps to `Test-Audio.ps1`, `Soak.ps1` to `Test-Soak.ps1`, and `Credits.ps1` to `Test-Credits.ps1`.
   - Always run `pwsh tests/Test-LibNames.ps1`. It checks that function names are unique and don't clash with aliases.
   - Run `pwsh ci/godot/hyperdot.ps1 test -Project examples/csharp/game` and `test -Project examples/gdscript`. Both must be green, and so must `doctor` on both.
   - If the change touches `plan`, copy `examples/gdscript` to a temporary folder and run `git init` there. Then run `plan -Do init -Project <copy>` and `plan -Json -Project <copy>`. Expect phase `concept` and at least one next action. You can also run `Test-Plan.ps1`.
   - If you add an error code, add it to `docs/json.md`. Never rename existing codes.
   - If the test needs Godot or a display, start `Xvfb :99 &` and set `DISPLAY=:99`. Don't use `xvfb-run`.
   - If you change a version matrix entry, re-run both example `test` and `doctor` checks on that Godot.

2. **If you change a skill (`.agents/skills/*/SKILL.md`):**
   - Run `pwsh ci/godot/tools/Test-Skills.ps1` and `pwsh tests/Test-SkillFixtures.ps1`. Both must pass.
   - Check that any command, flag, error code or version quoted in the skill matches the real script, `docs/json.md` and `examples/csharp`.
   - Keep the description to when to use the skill, never how.
   - Run `pwsh tests/Test-Context.ps1`, which holds skills to the kit's real flags.
   - If the skill quotes a shader, run `pwsh tests/Test-SkillShaders.ps1`.
   - Run `pwsh tests/Test-DocLinks.ps1` for links and paths.

3. **If you change a page under `docs/`:**
   - Run `pwsh tests/Test-DocLinks.ps1`.
   - Run `pwsh tests/Test-Context.ps1` if the page quotes kit flags.
   - If you changed `docs/json.md`, check that it matches the codes in the script.
