```powershell
function Invoke-ExampleRunner($Info, [string]$ResultsDir) {
    if (-not $env:GODOT_BIN) { Stop-GodotCi 'example runner: GODOT_BIN is not set' 'godot-not-found' }
    $log = Join-Path $ResultsDir 'example.log'
    Start-LogGroup "Example runner on $($Info.ProjectDir)"
    $code = Invoke-Logged $env:GODOT_BIN @('--headless', '--path', $Info.ProjectDir, '--quit') $log
    Stop-LogGroup

    $problems = @(Get-GodotLogErrors $log)
    if ($code -ne 0) { $problems = @("Godot exited with $code") + $problems }

    $cases = @()
    if ($problems) { $cases += @{ Name = 'run'; Failure = ($problems -join "`n") } }
    else { $cases += @{ Name = 'run'; Failure = '' } }

    Write-JUnitCases (Join-Path $ResultsDir 'example.junit.xml') 'example' $cases
    Set-JsonField 'exampleProblems' $problems.Count
    return [pscustomobject]@{ Cases = $cases; Problems = $problems; ExitCode = $code }
}
```

I modelled it on `Invoke-LayoutRunner` in `ci/godot/lib/Layout.ps1`. I haven't run it. I also didn't check the `godot-not-found` code against `docs/json.md`, and the AGENTS.md rule that codes are API means it has to be listed there.

- **Failures:** the function calls `Stop-GodotCi 'message' 'stable-code'` for setup errors. Test failures become JUnit cases, not exceptions.
- **No `Write-Output`:** the only pipeline value is the final `return`. Logs go through `Start-LogGroup` and `Stop-LogGroup`, which write with `Write-Host`.
- **Arrays:** `@(...)` wraps the results that may be empty or a single item, which avoids PowerShell's unrolling of one-item arrays.
- **Result:** the function returns a structured object (`Cases`, `Problems`, `ExitCode`) and records the problem count with `Set-JsonField`.
- **Strict mode:** I didn't set it, because the entry script already does. The function doesn't read any unset variable.
- **Name:** it follows the `Verb-Noun` rule, so it can't collide with the short built-in aliases.
