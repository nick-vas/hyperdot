```powershell
function Invoke-TestRunner {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Project,
        [string[]]$Arguments = @(),
        [int]$TimeoutSeconds = 600
    )
    Set-StrictMode -Version 3.0
    $ErrorActionPreference = 'Stop'

    if (-not (Test-Path -LiteralPath $Project -PathType Container)) {
        Stop-GodotCi "Project folder not found: $Project" 'project-not-found'
    }

    $exe = (Get-Command $Name -ErrorAction SilentlyContinue)
    if (-not $exe) {
        Stop-GodotCi "Test runner not found: $Name" 'runner-not-found'
    }

    Write-Host "Running $Name in $Project"

    $started = Get-Date
    $stdout = New-TemporaryFile
    $stderr = New-TemporaryFile
    try {
        $proc = Start-Process -FilePath $exe.Source -ArgumentList $Arguments `
            -WorkingDirectory $Project -NoNewWindow -PassThru `
            -RedirectStandardOutput $stdout -RedirectStandardError $stderr
        if (-not $proc.WaitForExit($TimeoutSeconds * 1000)) {
            $proc.Kill($true)
            Stop-GodotCi "$Name exceeded ${TimeoutSeconds}s" 'process-timeout'
        }
        $exitCode = $proc.ExitCode
        $output = @(Get-Content -LiteralPath $stdout)
        $errors = @(Get-Content -LiteralPath $stderr)
    }
    finally {
        Remove-Item -LiteralPath $stdout, $stderr -Force -ErrorAction SilentlyContinue
    }

    foreach ($line in $output) { Write-Host $line }

    [pscustomobject]@{
        runner   = $Name
        passed   = ($exitCode -eq 0)
        exitCode = $exitCode
        seconds  = [math]::Round(((Get-Date) - $started).TotalSeconds, 2)
        output   = $output
        errors   = $errors
    }
}
```

Notes on conventions followed:
- Failures go through `Stop-GodotCi "message" 'stable-code'`. The codes (`project-not-found`, `runner-not-found`, `process-timeout`) would need adding to `docs/json.md`. `process-timeout` may already exist, so check before adding.
- Logs use `Write-Host` (stderr in `-Json` mode via the kit's own handling), and nothing calls `Write-Output`. The single object at the end is the pipeline's return value.
- Results that may be empty or single are wrapped in `@(...)`.
- The name is Verb-Noun, so it avoids built-in alias clashes. Check it with `Test-LibNames.ps1`.

I haven't run this or checked it against the real lib files.
