- **Scope context with `-Json` and targeted reads:** Tell agents to run `hyperdot.ps1 <cmd> -Json -Project <path>` and read only the fields they need. They should never read the whole `lib/*.ps1` set. Point them to `docs/json.md` and the one relevant `lib` file.

- **Slim the always-loaded context:** Keep `AGENTS.md` to the layout and rules, and move the self-test table into `tests/README.md`. Agents then load it only when they change something. Load skills on demand from their one-line descriptions instead of preloading them.

- **Use fixed prompt templates with a stable prefix:** Put static instructions first (rules, command list, output contract), then the task-specific part. Cached prefixes then hit reliably. Reuse `ci/godot/templates/` and the `godot-verifier` and `godot-architect` subagents instead of free-form prompts.

- **Cache the slow, deterministic work:** Cache the Godot download, the `.godot/` import folder and NuGet in the workflow. Skip unchanged steps by keying on file hashes. Run only the self-test for the area changed, not the whole matrix.

- **Cap output size:** Have `test`, `build` and `export` print only a failure summary and the failure delta. They should truncate logs (for example, the last 50 lines per failure) and write full logs to a file the agent reads only on demand. Make the Stop hook and PR comment paging emit a compact diff against the previous run, not a full report.
