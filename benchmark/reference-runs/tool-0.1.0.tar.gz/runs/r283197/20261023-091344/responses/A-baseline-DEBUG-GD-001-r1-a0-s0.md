Five likely causes of flaky GDScript tests in this kit's CI, each with a mitigation. I answered from the kit description in AGENTS.md and didn't inspect the code.

1. **Frame timing.** Tests read scene state before `_ready` has run. Mitigation: `await process_frame` after `add_child`, the same rule the kit's in-Godot scripts follow, and never assert in the same frame as setup.

2. **Wall-clock waits.** Fixed `await get_tree().create_timer(...)` calls are slow on loaded Linux runners. Mitigation: wait on signals or conditions (GUT's `wait_for_signal` or `wait_until`), or step physics manually, instead of sleeping.

3. **Unseeded randomness.** `randi()` and `randf()` give different results on each run. Mitigation: call `seed()` or use a per-test `RandomNumberGenerator`, as the godot-determinism and godot-procgen skills advise.

4. **Leaked state between tests.** Autoloads, saved files in `user://`, orphan nodes and changed Input or Engine settings carry over. Mitigation: free nodes with `autofree` or `add_child_autofree`, reset autoloads in `before_each`, and use temporary save paths.

5. **Environment differences.** Examples are a missing display (`bench` and `shot` need Xvfb), an unimported project (an uncached `.godot/` directory), and a different Godot or GUT version. Mitigation: run `hyperdot.ps1 doctor` and the import step first, pin GUT v9.7.1 and Godot 4.7.2, and set `DISPLAY=:99` with `Xvfb`.

Mitigation for all five: run `test -Retry` with `quarantine.json`. The kit uses it to flag flaky tests and quarantine them instead of letting them go unnoticed. `Test-Flaky.ps1` covers it. Use `status` to see recurring error keys and the failure delta against the previous run, so you can tell a real regression from noise.
