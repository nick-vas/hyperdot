**Organization and naming.** The GDScript example (`examples/gdscript`) keeps its tests in `test/`. There is one suite, `test/test_score.gd`, which tests `score.gd` and `main.tscn`. It extends `GutTest`, and each test is a function named `test_<behaviour>`, such as `test_miss_resets_combo`. The tests use GUT assertions (`assert_eq`, `assert_gt`) and `add_child_autofree` for scene tests. `test/flows/startup.flow.json` is a UI-flow definition for the separate `flows` runner, not a GUT test.

**Discovery.** `ci/godot/lib/Detect.ps1:141` selects the `gut` runner when `Get-GutTestFiles` finds scripts that extend `GutTest`. If a `.gutconfig.json` exists, GUT uses it. Otherwise the kit passes `-gdir=<res:// path>` for every folder that holds such a script.

**Running.** The `gut` case in `ci/godot/lib/Runners.ps1:135` does the following:
- It fails with `Stop-GodotCi` if `addons/gut/gut_cmdln.gd` is missing.
- It runs Godot with `--headless --path <project> -s addons/gut/gut_cmdln.gd -gexit -gdisable_colors`.
- It writes JUnit XML to `gut.junit.xml` and the log to `gut.log` in the results directory.
- It maps `-Filter` to `-gunit_test_name=`.

`gut` is also one of the runners eligible for retry and quarantine (`Report.ps1:412`). The command is `pwsh ci/godot/hyperdot.ps1 test -Project examples/gdscript`.

I did not check whether `addons/gut` is present in the example. The Glob listing showed no `addons` folder, so the kit probably installs it on setup.
