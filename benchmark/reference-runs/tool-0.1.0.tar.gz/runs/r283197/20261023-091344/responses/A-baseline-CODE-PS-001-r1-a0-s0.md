```powershell
function Invoke-TestRunner {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Project,
        [string[]]$Arguments = @(),
        [int]$TimeoutSeconds = 300
    )
    Set-StrictMode -Version 3.0
    $ErrorActionPreference = 'Stop'

    if (-not (Test-Path -LiteralPath $Project -PathType Container)) {
        Stop-GodotCi "Project folder not found: $Project" 'project-not-found'
    }

    $exe = Get-Command -Name $Name -CommandType Application -ErrorAction SilentlyContinue
    if (-not $exe) {
        Stop-GodotCi "Test runner not found: $Name" 'runner-not-found'
    }

    Write-CiLog "Running $Name in $Project"

    $started = Get-Date
    $lines = @(& $exe.Source @Arguments 2>&1 | ForEach-Object { "$_" })
    $exitCode = $LASTEXITCODE
    $duration = ((Get-Date) - $started).TotalSeconds

    foreach ($line in $lines) { Write-Host $line }

    if ($duration -gt $TimeoutSeconds) {
        Stop-GodotCi "$Name exceeded ${TimeoutSeconds}s" 'process-timeout'
    }

    return [pscustomobject]@{
        Runner   = $Name
        Project  = $Project
        ExitCode = $exitCode
        Passed   = ($exitCode -eq 0)
        Seconds  = [math]::Round($duration, 2)
        Output   = $lines
    }
}
```

Notes on conventions applied:
- Strict mode 3.0 and `$ErrorActionPreference = 'Stop'`.
- Failures go through `Stop-GodotCi "message" 'stable-code'`. The codes are new, so add `project-not-found` and `runner-not-found` to `docs/json.md`. `process-timeout` is already in use (see `Test-ProcessTimeout.ps1`). I haven't checked that.
- No `Write-Output`. Logs use `Write-Host`/`Write-CiLog`, and the result is returned as the only pipeline value.
- `@(...)` wraps the captured output, so an empty or single-line result stays an array.
- The timeout here is checked after the run, so it doesn't stop a hung process. The repo's real process helper in `Runners`/`Common` enforces the limit and should replace the direct call.
