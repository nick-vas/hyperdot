I picked `-Frames` (line 76). It has no validation today, so zero or negative values get through.

```diff
--- a/ci/godot/hyperdot.ps1
+++ b/ci/godot/hyperdot.ps1
@@ -76,1 +76,2 @@
-    [int]$Frames = 120,
+    [ValidateRange(1, 100000)]
+    [int]$Frames = 120,
```

I haven't read the surrounding lines or checked how `$Frames` is used. The upper bound of 100000 is my guess. Before applying this, check that no caller passes a value outside 1–100000.
