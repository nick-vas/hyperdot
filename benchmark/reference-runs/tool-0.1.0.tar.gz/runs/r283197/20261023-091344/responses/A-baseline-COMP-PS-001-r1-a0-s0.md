`test` runs in `ci/godot/hyperdot.ps1`, where `Command` defaults to `test`. It runs `Invoke-Setup; Invoke-Build; Invoke-Tests`.

**Detection**
- `Get-ProjectInfo` (`lib/Detect.ps1:116`) finds `project.godot`, the solution, the Godot version (default 4.7.2) and the runners.
- Without `-Runners`, `validate` and `architecture` always run.
- Other runners are added by what the project contains:
  - `dotnet`: a test SDK or the gdUnit4 adapter in a csproj.
  - `godottest`: Chickensoft.GoDotTest in a game csproj.
  - `gut`: scripts that extend `GutTest`.
  - `flows`: any `*.flow.json` file.
  - `smoke`: a main scene set in `project.godot`.
  - `juice`, `playthrough`, `data`, `textsize`, `layout`: a `juice.json`, `playthrough.json`, `data.json`, `textsize.json` or `layout.json`.
  - `l10n`: translation tables or remaps.
- `gdunit4` is never auto-detected; you select it with `-Runners`.
- `Assert-SafeToClear` runs first and refuses a `-Results` folder whose wiping would delete the current folder or the project.

**Invocation** (`Invoke-TestRunner`, `lib/Runners.ps1:90`)
`Invoke-Tests` wipes the results folder, keeping `hyperdot.log`. It then calls `Invoke-TestRunnerWithRetry` for each runner. Each runner clears and recreates its own `<Results>/<runner>`.
- **dotnet and gdunit4:** `dotnet test` with generated run settings.
- **godottest:** `godot --headless --path <project> [scene] --run-tests --quit-on-finish`, wrapped in coverlet when coverage is on. The log is converted to JUnit XML.
- **gut:** `godot --headless -s addons/gut/gut_cmdln.gd -gexit`, with a JUnit XML option.
- **validate and flows:** `godot --headless -s tools/validate.gd` or `tools/flows.gd`. The logs are parsed into JUnit XML.
- **smoke:** `godot --headless --quit-after <Frames>`.
- **The rest:** dedicated PowerShell functions such as `Invoke-JuiceRunner`.

**Outputs** (under `test-results/`)
- `hyperdot.log`.
- Per runner: `<runner>.log` and `*.junit.xml`, plus TRX files from `dotnet test`.
- `findings.json` and `glyphs.json` for some runners.
- `coverage/*.cobertura.xml` when coverage is on.
- `<runner>.attempt<N>` folders from retries.
- A run summary.
- The run history, which feeds the failure delta.

With `-Json`, the result also carries `runnerResults`, `failureDelta`, `flaky` and `coverage`. If any runner fails, the run stops with `tests-failed`.
