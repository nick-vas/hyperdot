Five likely causes of a hanging test run. Two guards come from code I read (`Invoke-Logged` and `Invoke-GodotRetried` in `ci/godot/lib/Common.ps1`). The other guards are from the repo notes only. I didn't open `Soak.ps1`, `Runners.ps1` or the quarantine code, so check those names before relying on them.

1. **The Godot or test process never exits** (a scene waiting for input, a missing `quit()`, a deadlocked test).
   - Guard: `Invoke-Logged` stops the process tree after `Get-ProcessTimeout` and returns exit code 124. `HYPERDOT_TIMEOUT` sets the limit.
   - Mitigation: set `HYPERDOT_TIMEOUT` lower in CI, and make tests call `quit` on every path.

2. **A child process keeps the output pipes open after the parent exits** (a dotnet build server, for example).
   - Guard: the read loop in `Invoke-Logged` breaks when `HasExited` is true and no output is pending.
   - Mitigation: pass `--disable-build-servers`, or `-nodeReuse:false`, to dotnet.

3. **Godot crashes or stalls at import or shutdown.** The code comments describe exit 134 with a stale import cache.
   - Guard: `Invoke-GodotRetried` repeats a crashed import or export up to twice.
   - Mitigation: run `setup` or `build` first to refresh the import cache, and keep the timeout in place so a stall can't hang the retry.

4. **A flaky or hanging test inside GUT, gdUnit4 or dotnet.**
   - Guard: `test -Retry` with `quarantine.json`, and the `dotnet` runner's check for gdUnit4 tests found but not run.
   - Mitigation: quarantine the known-bad test and give it its own timeout.

5. **No display, so `bench`, `shot` or `audio -Mix` blocks.**
   - Guard: none in code. AGENTS.md only says to start `Xvfb :99 &` and set `DISPLAY=:99`.
   - Mitigation: start Xvfb before the run. Don't use `xvfb-run`, because it merges stderr into stdout and breaks `-Json`.

A server or network game that ignores SIGTERM (`soak`) belongs on the list too. I didn't confirm what guards it, but `Test-Soak.ps1` covers a C# server that catches SIGTERM.
