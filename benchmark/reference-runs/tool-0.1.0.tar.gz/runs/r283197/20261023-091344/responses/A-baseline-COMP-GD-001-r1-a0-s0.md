The GDScript example uses GUT.

**Organization and naming**
- There is one suite, `examples/gdscript/test/test_score.gd`. It has a `.uid` sidecar.
- The file is named `test_*.gd` and extends `GutTest`.
- Test methods are named `test_<behaviour>`, for example `test_miss_resets_combo`.
- The tests cover the `Score` class and the `main.tscn` scene. The scene test uses `add_child_autofree`.
- `test/flows/startup.flow.json` holds a UI flow, which the separate `flows` runner uses.

**Discovery**
- `Detect.ps1:141` selects the `gut` runner when `Get-GutTestFiles` finds any script extending `GutTest`.
- It also selects `flows` for `*.flow.json` files, `smoke` when the project sets `run/main_scene`, and `validate`.

**How the kit runs them** (`Runners.ps1:135`)
- It fails with `addons/gut/gut_cmdln.gd` missing if the addon isn't installed.
- It runs Godot with `--headless --path <project> -s addons/gut/gut_cmdln.gd -gexit -gdisable_colors`. The JUnit output goes to `-gjunit_xml_file=<ResultsDir>/gut.junit.xml`.
- If there is no `.gutconfig.json`, it adds a `-gdir=res://…` argument for each folder that holds a GutTest script.
- `-Filter` maps to `-gunit_test_name`.
- The log goes to `gut.log`.

I didn't check whether `addons/gut` is installed in the example. The file listing showed no `addons` folder.
