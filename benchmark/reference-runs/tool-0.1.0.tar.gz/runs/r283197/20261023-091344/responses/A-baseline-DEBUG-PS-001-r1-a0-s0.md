Likely causes of a hanging test run, most likely first:

1. **Deadlock or an `await` that never resumes in Godot.** The guard is `Get-ProcessTimeout` and `Invoke-Logged` in `lib/Common.ps1:173-227`. A program that outlives the limit is killed with its child processes and returns 124. The default is 1800 s. Mitigation: set `HYPERDOT_TIMEOUT` to a shorter value (for example 300) for local and agent runs. `0` turns the guard off, so don't use it.

2. **gdUnit4Net rebuilding the project and stalling.** `lib/Runners.ps1:35-44` already sets `TestSessionTimeout` to 1800000 ms and `CompileProcessTimeout` to 180000 ms. Mitigation: lower `TestSessionTimeout` in the generated runsettings to match your `HYPERDOT_TIMEOUT`. Also run `dotnet build` first so compile errors show up before the test session starts.

3. **Flaky tests that fail and are retried again and again.** `Invoke-TestRunnerWithRetry` (`Runners.ps1:236`) reruns the whole runner up to `-Retry` more times. Each rerun can wait out the full timeout, so the run looks hung. Mitigation: keep `-Retry` at 0 or 1, and put known-bad tests in `quarantine.json` so they are set aside before any retry.

4. **A scene waiting on input or a display.** Headless runs can wait forever on a menu, a `flows` step or a missing frame. Scripts run with `-s` also can't see `_ready` until the first frame. Mitigation: `await process_frame` after `add_child`. For `bench`, `shot` and `audio -Mix`, start `Xvfb :99 &` and set `DISPLAY=:99`.

5. **Orphaned or unstoppable child processes, such as servers in `soak` or leftover Godot instances.** `Soak.ps1:125-149` sends SIGTERM and allows a grace period (`$StopGraceSeconds`). It then calls `Kill($true)` to kill the whole process tree. A server with no SIGTERM handler is caught as `soak-unclean-stop`. Mitigation: add a SIGTERM handler to the server, and check for stray `godot` processes before rerunning.

I didn't read the whole of `Invoke-Logged` or the `Runners.ps1` retry body, so the exact kill path and retry behaviour are from the comments and the lines above, not from tracing every branch.
